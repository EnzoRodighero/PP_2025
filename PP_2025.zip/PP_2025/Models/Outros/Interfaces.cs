﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_2025
{
    internal class Interfaces
    {
        // CLASSES 
        private FormaPagamento aFormaPagamento;
        private CondicaoPagamento aCondicaoPagamento;

        private Paises oPais;
        private Estados oEstado;
        private Cidades aCidade;

        //Cadastros
        FrmCadastroFormaPagamento ofrmCadFormaPagamento;
        FrmCadastroCondicaoPagamento ofrmCadCondPG;
        FrmCadastroPais ofrmCadPaises;
        FrmCadastroEstado ofrmCadEstados;
        FrmCadastroCidade ofrmCadCidades;


        //Consultas
        FrmConsultaFormaPagamento ofrmConFormaPagamento;
        FrmConsultaCondicaoPagamento ofrmConCondPG; 
        FrmConsultaPais ofrmConPaises;
        FrmConsultaEstado ofrmConEstados;
        FrmConsultaCidade ofrmConCidades;

        public Interfaces()
        {
            //Classes 
            aFormaPagamento = new FormaPagamento();
            aCondicaoPagamento = new CondicaoPagamento();
            oPais = new Paises();
            oEstado = new Estados();
            aCidade = new Cidades();

            //Cadastros
            ofrmCadFormaPagamento = new FrmCadastroFormaPagamento();
            ofrmCadCondPG = new FrmCadastroCondicaoPagamento();
            ofrmCadPaises = new FrmCadastroPais();
            ofrmCadEstados = new FrmCadastroEstado();
            ofrmCadCidades = new FrmCadastroCidade();


            //Consultas          
            ofrmConFormaPagamento = new FrmConsultaFormaPagamento();
            ofrmConCondPG = new FrmConsultaCondicaoPagamento();
            ofrmConPaises = new FrmConsultaPais();
            ofrmConEstados = new FrmConsultaEstado();
            ofrmConCidades = new FrmConsultaCidade();


            //Setar os metodos.
            ofrmConFormaPagamento.SetFrmCadastro(ofrmCadFormaPagamento);
            ofrmConCondPG.SetFrmCadastro(ofrmCadCondPG); 

            ofrmConPaises.SetFrmCadastro(ofrmCadPaises);
            ofrmConEstados.SetFrmCadastro(ofrmCadEstados); 
            ofrmConCidades.SetFrmCadastro(ofrmCadCidades); 
            ofrmCadEstados.SetConsultaPaises(ofrmConPaises);  
            ofrmCadCidades.SetConsultaEstados(ofrmConEstados); 
        }

        public void pecaForm(string tag)
        {
            void PecaFormulario(Form mostra, object consultado)
            {
                if (mostra is FrmConsulta consulta)
                {
                    consulta.ConhecaObj(consultado);
                    consulta.ShowDialog();
                }
            }

            switch (tag) // colocar todos os forms todos.
            {
                //FINANCEIRO
                case "FORMA DE PAGAMENTO": PecaFormulario(ofrmConFormaPagamento, aFormaPagamento); break;
                case "CONDIÇÃO DE PAGAMENTO": PecaFormulario(ofrmConCondPG, aCondicaoPagamento); break;

                //LOCAIS
                case "PAÍSES": PecaFormulario(ofrmConPaises, oPais); break;
                case "ESTADOS": PecaFormulario(ofrmConEstados, oEstado); break;
                case "CIDADES": PecaFormulario(ofrmConCidades, aCidade); break;
            }
        }

      
        private void Sair()
        {
            DialogResult result = MessageBox.Show("Deseja encerrar a aplicação ?", "confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else 
            {
            
            };
        }
    }
}
