﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace PP_2025
{
    public class CTLContasReceber
    {
        private DALContasReceber contasReceberDAL = new DALContasReceber();

        public string AdicionarContaReceber(ContasReceber contaReceber)
        {
            return contasReceberDAL.AdicionarContaReceber(contaReceber);
        }

        public string AtualizarContaReceber(ContasReceber contaReceber)
        {
            return contasReceberDAL.AtualizarContaReceber(contaReceber);
        }

        public string Quitar(ContasReceber contaReceber)
        {
            return contasReceberDAL.Quitar(contaReceber);
        }

        public bool CancelarParcela(ContasReceber contaReceber)
        {
            return contasReceberDAL.CancelarParcela(contaReceber);
        }
        public List<ContasReceber> ListarContasReceber(string status)
        {
            return contasReceberDAL.ListarContasReceber(status);
        }
        public List<ContasReceber> BuscarContas(int numNFC, int modeloNFC, int serieNFC, int ParcelaNFC)
        {
            return contasReceberDAL.BuscarContas(numNFC, modeloNFC, serieNFC, ParcelaNFC);
        }
        public ContasReceber BuscarContasReceber(int numNFC, int modeloNFC, int serieNFC, int ParcelaNFC)
        {
            return contasReceberDAL.BuscarContaReceber(numNFC, modeloNFC, serieNFC, ParcelaNFC);
        }
        public List<ContasReceber> ListarContasReceberComData(string status, DateTime DataInicio, DateTime DataFim, string TipoData)
        {
            return contasReceberDAL.ListarContasReceberComData(status, DataInicio, DataFim, TipoData);
        }
        public void Incluir()
        {
            //Tirar após fazer o form
            FrmCadastroContaReceber frmCadastroContasReceber = new FrmCadastroContaReceber();
            frmCadastroContasReceber.Text = "Contas a Receber";
            frmCadastroContasReceber.ShowDialog();
        }

        public void Alterar(ContasReceber contaReceber)
        {
            if (contaReceber != null)
            {
                //Tirar após fazer o form
                FrmCadastroContaReceber frmCadastroContasReceber = new FrmCadastroContaReceber();
                frmCadastroContasReceber.ConhecaObj(contaReceber);
                frmCadastroContasReceber.Text = "Contas a Receber";
                frmCadastroContasReceber.CarregarCampos();
                frmCadastroContasReceber.ShowDialog();
            }
        }
        public void AlterarDados(ContasReceber contaReceber)
        {
            if (contaReceber != null)
            {
                //Tirar após fazer o form
                FrmCadastroContaReceber frmCadastroContaReceber = new FrmCadastroContaReceber();
                frmCadastroContaReceber.ConhecaObj(contaReceber);
                frmCadastroContaReceber.CarregarCampos();
                frmCadastroContaReceber.Text = "Alteração de contas a receber";
                frmCadastroContaReceber.btnSalvar.BackColor = Color.BurlyWood;
                frmCadastroContaReceber.btnSalvar.Text = "ALTERAR";
                frmCadastroContaReceber.txtTotalPago.Enabled = false;
                frmCadastroContaReceber.dtBaixa.Enabled = false;
                frmCadastroContaReceber.ShowDialog();
            }
        }

        public void Excluir(ContasReceber contaReceber)
        {
            // Implemente a lógica para abrir o formulário de exclusão de contas a receber
        }

        public void Visualizar(ContasReceber contaReceber)
        {
            if (contaReceber != null)
            {
                //Tirar após fazer o form//Tirar após fazer o form
                FrmCadastroContaReceber frmCadastroContasReceber = new FrmCadastroContaReceber();
                frmCadastroContasReceber.ConhecaObj(contaReceber);
                frmCadastroContasReceber.Text = "Contas a Receber";
                frmCadastroContasReceber.CarregarCampos();
                frmCadastroContasReceber.BloquearCampos();
                frmCadastroContasReceber.ShowDialog();
            }
        }
    }
}
