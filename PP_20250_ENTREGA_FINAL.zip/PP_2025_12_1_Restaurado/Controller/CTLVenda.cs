﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace PP_2025
{
    public class CTLVenda
    {
        private DALVenda vendasDAL = new DALVenda();

        public bool AdicionarVenda(Venda venda)
        {
            return vendasDAL.AdicionarVenda(venda);
        }

        public bool CancelarVenda(Venda venda)
        {
            return vendasDAL.CancelarVenda(venda);
        }

        public Venda BuscarVendaPorChave(int numNF, int modeloNF, int serieNF, int idCliente)
        {
            return vendasDAL.BuscarVendaPorChave(numNF, modeloNF, serieNF, idCliente);
        }

        public bool VerificarSeVendaExiste(int numNF, int modeloNF, int serieNF, int idCliente)
        {
            try
            {
                return vendasDAL.ExisteVendaPorChave(numNF, modeloNF, serieNF, idCliente);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }
        }

        public List<Venda> BuscarListaVendaPorChave(int numNF, int modeloNF, int serieNF)
        {
            return vendasDAL.BuscarListaVendasPorChave(numNF, modeloNF, serieNF);
        }

        public List<Venda> ListarVendas(bool? statusCancelada)
        {
            return vendasDAL.ListarVendas(statusCancelada);
        }

        public List<Venda> ListarVendas(DateTime? dataInicio, DateTime? dataFim, bool? cancelada, string nomeCliente, string tipoData)
        {
            return vendasDAL.ListarVendas(dataInicio, dataFim, cancelada, nomeCliente, tipoData);
        }

        public int BuscarNFE(string tipo)
        {
            return vendasDAL.BuscarNFe(tipo);
        }
        public void Incluir()
        {
            FrmCadastroVenda frmCadastroVenda = new FrmCadastroVenda();
            frmCadastroVenda.Text = "Realizar nova venda";
            frmCadastroVenda.BuscarNFE();
            frmCadastroVenda.ShowDialog();
        }

        public void Visualizar(Venda venda)
        {
            if (venda != null)
            {
                FrmCadastroVenda frmCadastroVenda = new FrmCadastroVenda();
                frmCadastroVenda.Text = "Consultar uma Venda";
                frmCadastroVenda.pnCliente.Enabled = false;
                frmCadastroVenda.btnCancelarF5.Text = "SAIR";
                frmCadastroVenda.Popular(venda);
                frmCadastroVenda.DesabilitarBotoes();
                frmCadastroVenda.ShowDialog();
            }
        }

        public void CancelarNota(Venda venda)
        {
            if (venda != null)
            {
                FrmCadastroVenda frm = new FrmCadastroVenda();
                frm.Text = "Cancelar Nota";
                if (venda.DataCancelamento != null)
                {
                    frm.btnSalvar.Text = "CANCELAR VENDA";
                }
                  
                frm.btnSalvar.BackColor = Color.DarkRed;
                frm.btnSalvar.ForeColor = Color.White;
                frm.btnFinalizaCondicao.Enabled = false;
                frm.Popular(venda);
                frm.ShowDialog();
            }
        }
    }
}
