﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP_2025
{
    internal class CtlUnidadeMedida
    {

        private DALUnidadeMedida unidadeDAL = new DALUnidadeMedida();

        public string AdicionarUnidadeMedida(UnidadeMedida unidade)
        {
            return unidadeDAL.AdicionarUnidadeMedida(unidade);
        }

        public string AtualizarUnidadeMedida(UnidadeMedida unidade)
        {
            return unidadeDAL.AtualizarUnidadeMedida(unidade);
        }

        public bool ExcluirUnidadeMedida(int idUnidadeMedida)
        {
            return unidadeDAL.ExcluirUnidadeMedida(idUnidadeMedida);
        }

        public UnidadeMedida BuscarUnidadeMedidaPorId(int id)
        {
            return unidadeDAL.BuscarUnidadeMedidaPorId(id);
        }

        public List<UnidadeMedida> ListarUnidadesMedida()
        {
            return unidadeDAL.ListarUnidadesMedida();
        }

        public void Incluir()
        {
            FrmCadastroUnidadeMedida frm = new FrmCadastroUnidadeMedida();
            frm.Text = "Incluir Unidade de Medida";
            frm.toolTip1.SetToolTip(frm.btnSalvar, "Salvar dados.");
            frm.ShowDialog();
        }

        public void Alterar(UnidadeMedida unidade)
        {
            if (unidade != null)
            {
                FrmCadastroUnidadeMedida frm = new FrmCadastroUnidadeMedida();
                frm.ConhecaObj(unidade);
                frm.Text = "Alterar Unidade de Medida";
                frm.btnSalvar.Text = "ALTERAR";
                frm.btnSalvar.BackColor = Color.BurlyWood;
                frm.CarregarCampos();
                frm.toolTip1.SetToolTip(frm.btnSalvar, "Alterar dados.");
                frm.ShowDialog();
            }
        }

        public void Excluir(UnidadeMedida unidade)
        {
            if (unidade != null)
            {
                FrmCadastroUnidadeMedida frm = new FrmCadastroUnidadeMedida();
                frm.ConhecaObj(unidade);
                frm.Text = "Excluir Unidade de Medida";
                frm.btnSalvar.Text = "EXCLUIR";
                frm.toolTip1.SetToolTip(frm.btnSalvar, "Excluir Unidade de Medida.");
                frm.btnSalvar.ForeColor = Color.White;
                frm.btnSalvar.BackColor = Color.DarkRed;
                frm.CarregarCampos();
                frm.BloquearCampos();
                frm.ShowDialog();
            }
        }

        public void Visualizar(UnidadeMedida unidade)
        {
            if (unidade != null)
            {
                FrmCadastroUnidadeMedida frm = new FrmCadastroUnidadeMedida();
                frm.ConhecaObj(unidade);
                frm.Text = "Consultar Unidade de Medida";
                frm.CarregarCampos();
                frm.BloquearCampos();
                frm.btnSalvar.Enabled = false;
                frm.ShowDialog();
            }
        }
    }
}
