﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PP_2025
{
    internal class DALUnidadeMedida
    {
        private Banco banco = new Banco();

        public string AdicionarUnidadeMedida(UnidadeMedida unidade)
        {
            try
            {
                string sql = "INSERT INTO UnidadeMedida (Nome) VALUES (@Nome)";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Nome", unidade.UnidadeMedidaNome)
                };
                var result = banco.ExecutarComando(sql, parametros);
                return result ? "OK" : "NOT";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public string AtualizarUnidadeMedida(UnidadeMedida unidade)
        {
            try
            {
                string sql = "UPDATE UnidadeMedida SET Nome = @Nome WHERE IdUnidadeMedida = @Id";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Nome", unidade.UnidadeMedidaNome),
                    new SqlParameter("@Id", unidade.ID)
                };
                var result = banco.ExecutarComando(sql, parametros);
                return result ? "OK" : "NOT";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public bool ExcluirUnidadeMedida(int idUnidadeMedida)
        {
            try
            {
                string sql = "DELETE FROM UnidadeMedida WHERE IdUnidadeMedida = @Id";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Id", idUnidadeMedida)
                };
                var result = banco.ExecutarComando(sql, parametros);
                return result;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public UnidadeMedida BuscarUnidadeMedidaPorId(int id)
        {
            try
            {
                string sql = "SELECT * FROM UnidadeMedida WHERE IdUnidadeMedida = @Id";
                SqlParameter[] parametros =
                {
                    new SqlParameter("@Id", id)
                };
                DataTable dt = banco.ExecutarConsulta(sql, parametros);
                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    return CreateUnidadeMedidaFromDataRow(row);
                }
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<UnidadeMedida> ListarUnidadesMedida()
        {
            List<UnidadeMedida> lista = new List<UnidadeMedida>();
            try
            {
                string sql = "SELECT * FROM UnidadeMedida";
                DataTable dt = banco.ExecutarConsulta(sql, null);
                foreach (DataRow row in dt.Rows)
                {
                    lista.Add(CreateUnidadeMedidaFromDataRow(row));
                }
            }
            catch (Exception)
            {
                // Retorna lista vazia em caso de erro
            }
            return lista;
        }

        private UnidadeMedida CreateUnidadeMedidaFromDataRow(DataRow row)
        {
            int id = Convert.ToInt32(row["IdUnidadeMedida"]);
            string nome = row["Nome"].ToString();
            return new UnidadeMedida(nome, id);
        }
    }
}
