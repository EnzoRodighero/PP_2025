﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP_2025
{
    public class UnidadeMedida: Pai
    {
        private string _NomeUnidadeMedida;

        public UnidadeMedida (): base ()
        {
            _NomeUnidadeMedida = "";
        }

        public UnidadeMedida(string nomeUnidadeMedida, int id) : base(id)
        {
            _NomeUnidadeMedida = nomeUnidadeMedida;
        }

        public string UnidadeMedidaNome
        {
            get => _NomeUnidadeMedida;
            set => _NomeUnidadeMedida = value;
        }
    }
}
