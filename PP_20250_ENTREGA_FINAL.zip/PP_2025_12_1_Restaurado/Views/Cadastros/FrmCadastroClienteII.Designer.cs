﻿namespace PP_2025
{
    partial class FrmCadastroClienteII
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCodCondPag = new System.Windows.Forms.TextBox();
            this.lblCodCondPag = new System.Windows.Forms.Label();
            this.lblCondPag = new System.Windows.Forms.Label();
            this.txtCondPag = new System.Windows.Forms.TextBox();
            this.btnCondPag = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBuscaCep
            // 
            this.btnBuscaCep.Click += new System.EventHandler(this.btnBuscaCep_Click);
            // 
            // dtNascimento
            // 
            this.dtNascimento.Location = new System.Drawing.Point(331, 310);
            this.dtNascimento.Size = new System.Drawing.Size(370, 32);
            // 
            // btnBuscaCid
            // 
            this.btnBuscaCid.Click += new System.EventHandler(this.btnBuscaCid_Click);
            // 
            // btnBuscarCargo
            // 
            this.btnBuscarCargo.Location = new System.Drawing.Point(525, 455);
            this.btnBuscarCargo.Visible = false;
            // 
            // txtNome
            // 
            this.txtNome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtNome_KeyDown_1);
            //this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress_2);
            // 
            // lblTipo
            // 
            this.lblTipo.Size = new System.Drawing.Size(54, 18);
            this.lblTipo.Text = "Tipo *";
            // 
            // txtApelido
            // 
            this.txtApelido.TextChanged += new System.EventHandler(this.txtApelido_TextChanged);
            this.txtApelido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtApelido_KeyPress);
            // 
            // lblSexo
            // 
            this.lblSexo.Size = new System.Drawing.Size(56, 18);
            this.lblSexo.Text = "Sexo *";
            // 
            // txtLogradouro
            // 
            this.txtLogradouro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLogradouro_KeyPress);
            // 
            // lblLogradouro
            // 
            this.lblLogradouro.Size = new System.Drawing.Size(105, 18);
            this.lblLogradouro.Text = "Logradouro *";
            // 
            // txtNum
            // 
            this.txtNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNum_KeyPress);
            // 
            // lblNum
            // 
            this.lblNum.Size = new System.Drawing.Size(78, 18);
            this.lblNum.Text = "Número *";
            // 
            // txtComplemento
            // 
            this.txtComplemento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtComplemento_KeyPress);
            // 
            // lblComplemento
            // 
            this.lblComplemento.Size = new System.Drawing.Size(120, 18);
            this.lblComplemento.Text = "Complemento *";
            // 
            // txtBairro
            // 
            this.txtBairro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBairro_KeyPress);
            // 
            // lblBairro
            // 
            this.lblBairro.Size = new System.Drawing.Size(66, 18);
            this.lblBairro.Text = "Bairro *";
            // 
            // txtCidade
            // 
            this.txtCidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCidade_KeyPress);
            // 
            // lblCidade
            // 
            this.lblCidade.Size = new System.Drawing.Size(71, 18);
            this.lblCidade.Text = "Cidade *";
            // 
            // txtCEP
            // 
            this.txtCEP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCEP_KeyPress);
            // 
            // lblCEP
            // 
            this.lblCEP.Size = new System.Drawing.Size(51, 18);
            this.lblCEP.Text = "CEP *";
            // 
            // txtEmail
            // 
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            this.txtEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmail_KeyPress);
            this.txtEmail.Leave += new System.EventHandler(this.txtEmail_Leave_1);
            // 
            // lblEmail
            // 
            this.lblEmail.Size = new System.Drawing.Size(62, 18);
            this.lblEmail.Text = "Email *";
            // 
            // txtTelefone
            // 
            this.txtTelefone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefone_KeyPress);
            this.txtTelefone.Leave += new System.EventHandler(this.txtTelefone_Leave_1);
            // 
            // txtCelular
            // 
            this.txtCelular.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCelular_KeyPress);
            this.txtCelular.Leave += new System.EventHandler(this.txtCelular_Leave_1);
            // 
            // txtRG
            // 
            this.txtRG.Size = new System.Drawing.Size(140, 32);
            this.txtRG.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRG_KeyPress);
            this.txtRG.Leave += new System.EventHandler(this.txtRG_Leave_1);
            // 
            // lblRG
            // 
            this.lblRG.Size = new System.Drawing.Size(44, 18);
            this.lblRG.Text = "RG *";
            // 
            // txtCPFouCNPJ
            // 
            this.txtCPFouCNPJ.Location = new System.Drawing.Point(161, 310);
            this.txtCPFouCNPJ.Size = new System.Drawing.Size(163, 32);
            this.txtCPFouCNPJ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCPFouCNPJ_KeyPress);
            this.txtCPFouCNPJ.Leave += new System.EventHandler(this.txtCPFouCNPJ_Leave_1);
            // 
            // lblCPFouCNPJ
            // 
            this.lblCPFouCNPJ.Location = new System.Drawing.Point(158, 289);
            // 
            // lblNasc
            // 
            this.lblNasc.Location = new System.Drawing.Point(328, 289);
            // 
            // txtCodCargo
            // 
            this.txtCodCargo.Location = new System.Drawing.Point(11, 453);
            this.txtCodCargo.Visible = false;
            // 
            // lblCodCargo
            // 
            this.lblCodCargo.Location = new System.Drawing.Point(8, 430);
            this.lblCodCargo.Visible = false;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(161, 453);
            this.txtCargo.Visible = false;
            // 
            // lblCargo
            // 
            this.lblCargo.Location = new System.Drawing.Point(158, 430);
            this.lblCargo.Visible = false;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(646, 453);
            this.txtSalario.Visible = false;
            // 
            // lblSalario
            // 
            this.lblSalario.Location = new System.Drawing.Point(643, 430);
            this.lblSalario.Visible = false;
            // 
            // cmbFisJur
            // 
            this.cmbFisJur.SelectedIndexChanged += new System.EventHandler(this.cmbFisJur_SelectedIndexChanged);
            // 
            // txtCodCidade
            // 
            this.txtCodCidade.TextChanged += new System.EventHandler(this.txtCodCidade_TextChanged);
            this.txtCodCidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCidade_KeyPress);
            // 
            // lblCodCidade
            // 
            this.lblCodCidade.Size = new System.Drawing.Size(104, 18);
            this.lblCodCidade.Text = "Cod Cidade *";
            // 
            // txtUltAltFunc
            // 
            this.txtUltAltFunc.Visible = false;
            // 
            // lblUltAltFunc
            // 
            this.lblUltAltFunc.Visible = false;
            // 
            // txtDtCriacao
            // 
            this.txtDtCriacao.ReadOnly = true;
            // 
            // txtDtUltMod
            // 
            this.txtDtUltMod.ReadOnly = true;
            // 
            // txtCodCondPag
            // 
            this.txtCodCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCondPag.Location = new System.Drawing.Point(708, 310);
            this.txtCodCondPag.MaxLength = 5;
            this.txtCodCondPag.Name = "txtCodCondPag";
            this.txtCodCondPag.Size = new System.Drawing.Size(97, 32);
            this.txtCodCondPag.TabIndex = 602;
            this.txtCodCondPag.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCondPag_KeyPress);
            // 
            // lblCodCondPag
            // 
            this.lblCodCondPag.AutoSize = true;
            this.lblCodCondPag.Location = new System.Drawing.Point(702, 289);
            this.lblCodCondPag.Name = "lblCodCondPag";
            this.lblCodCondPag.Size = new System.Drawing.Size(92, 18);
            this.lblCodCondPag.TabIndex = 603;
            this.lblCodCondPag.Text = "Cód Cond *";
            // 
            // lblCondPag
            // 
            this.lblCondPag.AutoSize = true;
            this.lblCondPag.Location = new System.Drawing.Point(811, 289);
            this.lblCondPag.Name = "lblCondPag";
            this.lblCondPag.Size = new System.Drawing.Size(171, 18);
            this.lblCondPag.TabIndex = 604;
            this.lblCondPag.Text = "Condição Pagamento *";
            // 
            // txtCondPag
            // 
            this.txtCondPag.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCondPag.Location = new System.Drawing.Point(811, 310);
            this.txtCondPag.MaxLength = 75;
            this.txtCondPag.Name = "txtCondPag";
            this.txtCondPag.ReadOnly = true;
            this.txtCondPag.Size = new System.Drawing.Size(234, 32);
            this.txtCondPag.TabIndex = 605;
            this.txtCondPag.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCondPag_KeyPress);
            // 
            // btnCondPag
            // 
            this.btnCondPag.BackColor = System.Drawing.Color.Gold;
            this.btnCondPag.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCondPag.Location = new System.Drawing.Point(1054, 312);
            this.btnCondPag.Name = "btnCondPag";
            this.btnCondPag.Size = new System.Drawing.Size(112, 24);
            this.btnCondPag.TabIndex = 606;
            this.btnCondPag.Text = "BUSCAR";
            this.btnCondPag.UseVisualStyleBackColor = false;
            this.btnCondPag.Click += new System.EventHandler(this.btnCondPag_Click);
            // 
            // FrmCadastroClienteII
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(1201, 554);
            this.Controls.Add(this.btnCondPag);
            this.Controls.Add(this.txtCondPag);
            this.Controls.Add(this.lblCondPag);
            this.Controls.Add(this.lblCodCondPag);
            this.Controls.Add(this.txtCodCondPag);
            this.Name = "FrmCadastroClienteII";
            this.Text = "Frm Cadastro Cliente";
            this.Load += new System.EventHandler(this.FrmCadastroClienteII_Load);
            this.Controls.SetChildIndex(this.txtCodCondPag, 0);
            this.Controls.SetChildIndex(this.lblCodCondPag, 0);
            this.Controls.SetChildIndex(this.lblCondPag, 0);
            this.Controls.SetChildIndex(this.txtCondPag, 0);
            this.Controls.SetChildIndex(this.btnCondPag, 0);
            this.Controls.SetChildIndex(this.lblApelido, 0);
            this.Controls.SetChildIndex(this.cmbFisJur, 0);
            this.Controls.SetChildIndex(this.txtNome, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.lblTipo, 0);
            this.Controls.SetChildIndex(this.lblNome, 0);
            this.Controls.SetChildIndex(this.txtApelido, 0);
            this.Controls.SetChildIndex(this.cmbSexo, 0);
            this.Controls.SetChildIndex(this.lblSexo, 0);
            this.Controls.SetChildIndex(this.txtLogradouro, 0);
            this.Controls.SetChildIndex(this.lblLogradouro, 0);
            this.Controls.SetChildIndex(this.txtNum, 0);
            this.Controls.SetChildIndex(this.lblNum, 0);
            this.Controls.SetChildIndex(this.txtComplemento, 0);
            this.Controls.SetChildIndex(this.lblComplemento, 0);
            this.Controls.SetChildIndex(this.txtBairro, 0);
            this.Controls.SetChildIndex(this.lblBairro, 0);
            this.Controls.SetChildIndex(this.txtCidade, 0);
            this.Controls.SetChildIndex(this.lblCidade, 0);
            this.Controls.SetChildIndex(this.txtCEP, 0);
            this.Controls.SetChildIndex(this.lblCEP, 0);
            this.Controls.SetChildIndex(this.btnBuscaCep, 0);
            this.Controls.SetChildIndex(this.txtEmail, 0);
            this.Controls.SetChildIndex(this.lblEmail, 0);
            this.Controls.SetChildIndex(this.txtTelefone, 0);
            this.Controls.SetChildIndex(this.lblTelefone, 0);
            this.Controls.SetChildIndex(this.txtCelular, 0);
            this.Controls.SetChildIndex(this.lblCelular, 0);
            this.Controls.SetChildIndex(this.txtRG, 0);
            this.Controls.SetChildIndex(this.lblRG, 0);
            this.Controls.SetChildIndex(this.txtCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.lblCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.dtNascimento, 0);
            this.Controls.SetChildIndex(this.lblNasc, 0);
            this.Controls.SetChildIndex(this.txtCodCargo, 0);
            this.Controls.SetChildIndex(this.lblCodCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscaCid, 0);
            this.Controls.SetChildIndex(this.txtCargo, 0);
            this.Controls.SetChildIndex(this.lblCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscarCargo, 0);
            this.Controls.SetChildIndex(this.txtSalario, 0);
            this.Controls.SetChildIndex(this.lblSalario, 0);
            this.Controls.SetChildIndex(this.txtDtCriacao, 0);
            this.Controls.SetChildIndex(this.lblDtCriacao, 0);
            this.Controls.SetChildIndex(this.txtDtUltMod, 0);
            this.Controls.SetChildIndex(this.lblDtUltMod, 0);
            this.Controls.SetChildIndex(this.txtUltAltFunc, 0);
            this.Controls.SetChildIndex(this.lblUltAltFunc, 0);
            this.Controls.SetChildIndex(this.cmbStatus, 0);
            this.Controls.SetChildIndex(this.txtCodCidade, 0);
            this.Controls.SetChildIndex(this.lblCodCidade, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCodCondPag;
        private System.Windows.Forms.Label lblCodCondPag;
        private System.Windows.Forms.Label lblCondPag;
        private System.Windows.Forms.TextBox txtCondPag;
        private System.Windows.Forms.Button btnCondPag;
    }
}
