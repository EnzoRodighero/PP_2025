﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Globalization;
using TextBox = System.Windows.Forms.TextBox;
using System.Reflection;

namespace PP_2025
{
    public partial class FrmCadastroCompra : FrmCadastros
    {
        CTLCondicaoPagamento aCTLcon;
        CondicaoPagamento aCondicao;
        CTLProdutos aCTLProdutos;
        CTLCompras aCTLCompra;
        CTLFornecedores aCTLForn;
        bool permiteExclusao;
        private bool AutorizadoSalvar = false;
        Compra aCompra;
        ItemCompra oItemCompra;
        CultureInfo cultura = new CultureInfo("pt-BR");
        Fornecedores oFornecedor;

        ContasPagar aContaPagar;
        CTLContasPagar aCTLContasPagar;

        public FrmCadastroCompra()
        {
            InitializeComponent();
            Operacao.DisableCopyPaste(this);
            Instanciar();
            InicializarColunasListViewContasPagar();
        }

        private void Instanciar()
        {
            aCompra = new Compra();
            oItemCompra = new ItemCompra();
            aCTLProdutos = new CTLProdutos();
            aCTLCompra = new CTLCompras();
            aCTLForn = new CTLFornecedores();
            aCondicao = new CondicaoPagamento();
            aCTLcon = new CTLCondicaoPagamento();
            oFornecedor = new Fornecedores();

            aContaPagar = new ContasPagar();
            aCTLContasPagar = new CTLContasPagar();

            permiteExclusao = true; // armazena a permissão do datagrid de produtos.
            DataGrid();
        }
        protected override void LimparCampos()
        {
            dtChegada.Value = DateTime.Now;
            dtEmissao.Value = DateTime.Now;
            txtCodProduto.Clear();
            txtUND.Clear();
            txtQtd.Clear();
            txtCusto.Clear();
            txtDesconto.Clear();
            txtTotalItens.Clear();
            txtFrete.Text = "0";
            txtSeguro.Text = "0";
            txtOutras.Text = "0";
            txtProduto.Clear();
        }
        protected virtual bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            // Verifica se a Data de Chegada está vazia ou no futuro
            if (dtChegada.Value == DateTime.MinValue || dtChegada.Value.Date > DateTime.Now.Date)
            {
                camposFaltantes.Add("Data de Chegada (não pode ser no futuro)");
            }

            // Verifica se a Data de Emissão está vazia ou no futuro
            if (dtEmissao.Value == DateTime.MinValue || dtEmissao.Value.Date > DateTime.Now.Date)
            {
                camposFaltantes.Add("Data de Emissão (não pode ser no futuro)");
            }

            // Verifica se o Código do Produto está vazio
            if (string.IsNullOrWhiteSpace(txtCodProduto.Text))
            {
                camposFaltantes.Add("Código do Produto");
            }

            // Verifica se a Unidade de Medida está vazia
            if (string.IsNullOrWhiteSpace(txtUND.Text))
            {
                camposFaltantes.Add("Unidade de Medida");
            }

            // Verifica se a Quantidade está vazia
            if (string.IsNullOrWhiteSpace(txtQtd.Text))
            {
                camposFaltantes.Add("Quantidade");
            }

            // Verifica se o Custo está vazio
            if (string.IsNullOrWhiteSpace(txtCusto.Text))
            {
                camposFaltantes.Add("Custo");
            }

            // Verifica se o Desconto está vazio
            if (string.IsNullOrWhiteSpace(txtDesconto.Text))
            {
                camposFaltantes.Add("Desconto");
            }

            // Verifica se o Total de Itens está vazio
            if (string.IsNullOrWhiteSpace(txtTotalItens.Text))
            {
                camposFaltantes.Add("Total de Itens");
            }

            // Exibe uma mensagem de erro se houver campos faltantes
            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos corretamente: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        public override void Verificar()
        {
            if (btnSalvar.Text == "SALVAR")
                Salvar();
            else if (btnSalvar.Text == "CANCELAR")
            {
                CancelarCompra();
            }
            else if (btnSalvar.Text == "EMITIR")
            {
                //
            }
        }
        protected virtual void CancelarCompra()
        {
            string mensagem = "Tem certeza que deseja cancelar a Compra?";

            DialogResult resultado = MessageBox.Show(mensagem, $"Confirmação de Cancelamento", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    aCompra.NumNFC = Convert.ToInt32(txtNumNFC.Value);
                    aCompra.SerieNFC = Convert.ToInt32(txtSerieNFC.Value);
                    aCompra.ModeloNFC = Convert.ToInt32(txtModeloNFC.Value);
                    aCompra.Fornecedor.ID = Convert.ToInt32(txtCodigo.Text);
                    aCompra.StatusCompra = "CANCELADA";
                    aCompra.DataCancelamento = DateTime.Now;

                    aCTLCompra.CancelarCompra(aCompra);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao Cancelar compra: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
        protected override void Salvar()
        {
            if (VerificaData())
            {
                if (lvParcelas.Items.Count == 0)
                {
                    MessageBox.Show("Nenhuma parcela adicionada. Não é possível salvar a compra.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (AutorizadoSalvar)
                {
                    if (Dgv.Rows.Count > 0)
                    {
                        CultureInfo cultura = CultureInfo.InvariantCulture;
                        txtFrete_Leave(txtFrete, EventArgs.Empty);
                        CTLCompras aCTLCompra = new CTLCompras();
                        List<ContasPagar> listaContasPagar = new List<ContasPagar>();
                        Compra Obj = new Compra();
                        Obj.Fornecedor = new Fornecedores();
                        Obj.Condicao = new CondicaoPagamento();
                        Obj.Fornecedor.ID = Convert.ToInt32(txtCodigo.Text);
                        Obj.Condicao.ID = int.Parse(txtCodCondicao.Text);
                        Obj.NumNFC = int.Parse(txtNumNFC.Text);
                        Obj.ModeloNFC = int.Parse(txtModeloNFC.Text);
                        Obj.SerieNFC = int.Parse(txtSerieNFC.Text);
                        Obj.ValorTotal = decimal.Parse(txtTotalNota.Text, cultura);
                        Obj.ValorFrete = string.IsNullOrEmpty(txtFrete.Text) ? 0 : decimal.Parse(txtFrete.Text, cultura);
                        Obj.ValorSeguro = string.IsNullOrEmpty(txtSeguro.Text) ? 0 : decimal.Parse(txtSeguro.Text, cultura);
                        Obj.ValorOutrasDespesas = string.IsNullOrEmpty(txtOutras.Text) ? 0 : decimal.Parse(txtOutras.Text, cultura);
                        Obj.DataChegada = DateTime.Parse(dtChegada.Text);
                        Obj.DataEmissao = DateTime.Parse(dtEmissao.Text);
                        Obj.DataCriacao = DateTime.Now;
                        Obj.StatusCompra = "ATIVO";
                        Obj.ItensCompra = ItensListView(Obj.NumNFC, Obj.ModeloNFC, Obj.SerieNFC, Obj.Fornecedor.ID);

                        // Criar as contas a pagar baseadas nas parcelas
                        foreach (ListViewItem item in lvParcelas.Items)
                        {
                            ContasPagar aContaPagar = new ContasPagar();
                            aContaPagar.NumNFC = Obj.NumNFC;
                            aContaPagar.ModeloNFC = Obj.ModeloNFC;
                            aContaPagar.SerieNFC = Obj.SerieNFC;
                            aContaPagar.NumParcela = Convert.ToInt32(item.SubItems[0].Text);
                            aContaPagar.Fornecedor.ID = Obj.Fornecedor.ID;
                            aContaPagar.Condicao.ID = Obj.Condicao.ID;
                            aContaPagar.Valor = Convert.ToDecimal(item.SubItems[5].Text);
                            aContaPagar.Situacao = "A PAGAR";
                            aContaPagar.DataCriacao = DateTime.Now;
                            aContaPagar.DataVencimento = dtEmissao.Value.AddDays(Convert.ToInt32(item.SubItems[1].Text));
                            aContaPagar.DataUltAlteracao = DateTime.Now;
                            aContaPagar.FormaPagamento.ID = Convert.ToInt32(item.SubItems[2].Text);
                            aContaPagar.Taxa = aCondicao.Taxa;
                            aContaPagar.Desconto = aCondicao.Desconto;
                            aContaPagar.Multa = aCondicao.Multa;
                            //DataBaixa não é necessário atribuir valor, pois a conta ainda não foi paga.
                            listaContasPagar.Add(aContaPagar);
                        }

                        Obj.ContasPAgar = listaContasPagar;

                        // Chamar o método AdicionarCompra no controlador CTLCompras
                        bool result = aCTLCompra.AdicionarCompra(Obj);

                        if (!result)
                        {
                            MessageBox.Show("Erro ao salvar a compra.");
                        }
                        else
                        {
                            MessageBox.Show("Compra salva com sucesso!");
                        }
                        this.Close();
                    }
                    return;
                }
            }

        }
        private  void Salvar2()
        {
            if (VerificaData())
            {
                if (AutorizadoSalvar)
                {
                    if (Dgv.Rows.Count > 0)
                    {
                        txtFrete_Leave(txtFrete, EventArgs.Empty);
                        CTLCompras aCTLCompra = new CTLCompras();
                        List<ContasPagar> listaContasPagar = new List<ContasPagar>();
                        Compra Obj = new Compra();
                        Obj.Fornecedor = new Fornecedores();
                        Obj.Condicao = new CondicaoPagamento();

                        // Variáveis para parseamento seguro
                        int fornecedorId = 0;
                        int condicaoId = 0;
                        int numNfc = 0;
                        int modeloNFC = 0;
                        int serieNFC = 0;
                        decimal valorTotal = 0m;
                        decimal valorFrete = 0m;
                        decimal valorSeguro = 0m;
                        decimal valorOutras = 0m;

                        // --- 1. Conversão de campos da Compra (Parte de Cima do Form) ---

                        // Conversão segura de inteiros para Fornecedor, Condição e Nota Fiscal
                        if (!int.TryParse(txtCodigo.Text, out fornecedorId))
                        {
                            MessageBox.Show("Código do Fornecedor inválido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (!int.TryParse(txtCodCondicao.Text, out condicaoId))
                        {
                            MessageBox.Show("Código da Condição de Pagamento inválido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (!int.TryParse(txtNumNFC.Text, out numNfc))
                        {
                            MessageBox.Show("Número da Nota Fiscal inválido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (!int.TryParse(txtModeloNFC.Text, out modeloNFC))
                        {
                            MessageBox.Show("Modelo da Nota Fiscal inválido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (!int.TryParse(txtSerieNFC.Text, out serieNFC))
                        {
                            MessageBox.Show("Série da Nota Fiscal inválida.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        // Conversão segura de decimais para valores (usando 'cultura')
                        if (!decimal.TryParse(txtTotalNota.Text, System.Globalization.NumberStyles.Currency, cultura, out valorTotal))
                        {
                            MessageBox.Show("Valor Total da Nota inválido.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        decimal.TryParse(txtFrete.Text, System.Globalization.NumberStyles.Currency, cultura, out valorFrete); // Se falhar, valorFrete é 0
                        decimal.TryParse(txtSeguro.Text, System.Globalization.NumberStyles.Currency, cultura, out valorSeguro); // Se falhar, valorSeguro é 0
                        decimal.TryParse(txtOutras.Text, System.Globalization.NumberStyles.Currency, cultura, out valorOutras); // Se falhar, valorOutras é 0

                        // Atribuição ao objeto
                        Obj.Fornecedor.ID = fornecedorId;
                        Obj.Condicao.ID = condicaoId;
                        Obj.NumNFC = numNfc;
                        Obj.ModeloNFC = modeloNFC;
                        Obj.SerieNFC = serieNFC;
                        Obj.ValorTotal = valorTotal;
                        Obj.ValorFrete = valorFrete;
                        Obj.ValorSeguro = valorSeguro;
                        Obj.ValorOutrasDespesas = valorOutras;
                        Obj.DataChegada = dtChegada.Value; // Já que é um DateTimePicker, use .Value
                        Obj.DataEmissao = dtEmissao.Value; // Já que é um DateTimePicker, use .Value
                        Obj.DataCriacao = DateTime.Now;
                        Obj.StatusCompra = "ATIVO";
                        Obj.ItensCompra = ItensListView(Obj.NumNFC, Obj.ModeloNFC, Obj.SerieNFC, Obj.Fornecedor.ID);

                        // --- 2. Criação das contas a pagar (Loop onde o erro ocorreu) ---
                        foreach (ListViewItem item in lvParcelas.Items)
                        {
                            ContasPagar aContaPagar = new ContasPagar();
                            aContaPagar.NumNFC = Obj.NumNFC;
                            aContaPagar.ModeloNFC = Obj.ModeloNFC;
                            aContaPagar.SerieNFC = Obj.SerieNFC;

                            // *** LINHA 222 (Refatorada para tratar "1.") ***
                            // 1. Limpa a string removendo o ponto decimal e espaços.
                            string parcelaString = item.SubItems[0].Text.Trim().Replace(".", "").Replace(",", "");
                            int numParcela;

                            // 2. Tenta fazer o parse de forma segura.
                            if (!int.TryParse(parcelaString, out numParcela))
                            {
                                MessageBox.Show($"Erro: O número da parcela '{item.SubItems[0].Text}' não é um inteiro válido.", "Erro de Dados na Parcela", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                listaContasPagar.Clear(); // Limpa a lista para não salvar dados incompletos
                                return; // Sai do método para o usuário corrigir o erro
                            }
                            aContaPagar.NumParcela = numParcela;
                            // **********************************************

                            aContaPagar.Fornecedor.ID = Obj.Fornecedor.ID;
                            aContaPagar.Condicao.ID = Obj.Condicao.ID;

                            // Conversão de Decimal (Valor)
                            decimal valorParcela;
                            string valorString = item.SubItems[5].Text;
                            if (!decimal.TryParse(valorString, System.Globalization.NumberStyles.Currency, cultura, out valorParcela))
                            {
                                MessageBox.Show($"Erro: O valor da parcela '{valorString}' não é um decimal válido.", "Erro de Dados na Parcela", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                listaContasPagar.Clear();
                                return;
                            }
                            aContaPagar.Valor = valorParcela;

                            aContaPagar.Situacao = "A PAGAR";
                            aContaPagar.DataCriacao = DateTime.Now;
                            aContaPagar.DataUltAlteracao = DateTime.Now;

                            // Conversão de Data de Vencimento
                            DateTime dataVencimento;
                            if (!DateTime.TryParse(item.SubItems[1].Text, out dataVencimento))
                            {
                                MessageBox.Show($"Erro: A data de vencimento da parcela '{item.SubItems[1].Text}' não é válida.", "Erro de Dados na Parcela", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                listaContasPagar.Clear();
                                return;
                            }
                            aContaPagar.DataVencimento = dataVencimento;

                            // Conversão de Forma de Pagamento ID
                            int formaPagamentoId;
                            if (!int.TryParse(item.SubItems[2].Text, out formaPagamentoId))
                            {
                                MessageBox.Show($"Erro: O ID da Forma de Pagamento '{item.SubItems[2].Text}' não é válido.", "Erro de Dados na Parcela", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                listaContasPagar.Clear();
                                return;
                            }
                            aContaPagar.FormaPagamento.ID = formaPagamentoId;

                            // Assume-se que 'aCondicao' está disponível no escopo da classe
                            aContaPagar.Taxa = aCondicao.Taxa;
                            aContaPagar.Desconto = aCondicao.Desconto;
                            aContaPagar.Multa = aCondicao.Multa;

                            listaContasPagar.Add(aContaPagar);
                        }

                        Obj.ContasPAgar = listaContasPagar;

                        // --- 3. Chamada ao Controlador ---
                        bool result = aCTLCompra.AdicionarCompra(Obj);

                        if (!result)
                        {
                            MessageBox.Show("Erro ao salvar a compra.");
                        }
                        else
                        {
                            MessageBox.Show("Compra salva com sucesso!");
                        }
                        this.Close();
                    }
                    return;
                }
            }
        }

        public List<ItemCompra> ItensListView(int Num_nfc, int Modelo_nfc, int Serie_nfc, int Id_fornecedor)
        {
            var vLista = new List<ItemCompra>();
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                ItemCompra ItensCompra = new ItemCompra();
                ItensCompra.NumNFC = Num_nfc;
                ItensCompra.ModeloNFC = Modelo_nfc;
                ItensCompra.SerieNFC = Serie_nfc;
                ItensCompra.Fornecedor.ID = Id_fornecedor;
                ItensCompra.Produto = aCTLProdutos.BuscarProdutoPorId(Convert.ToInt32(vLinha.Cells["id_produto"].Value));
                ItensCompra.QtdProduto = Convert.ToInt32(vLinha.Cells["qtd_entrada"].Value);
                ItensCompra.PrecoCusto = Convert.ToDecimal(vLinha.Cells["custo_sugerido"].Value);
                ItensCompra.Desconto = Convert.ToDecimal(vLinha.Cells["desconto"].Value);
                ItensCompra.PercentualCompra = Convert.ToDecimal(vLinha.Cells["percentual_compra"].Value);
                ItensCompra.MediaPonderada = Convert.ToDecimal(vLinha.Cells["media_ponderada"].Value);
                ItensCompra.DataCriacao = DateTime.Now;
                vLista.Add(ItensCompra);
            }
            return vLista;
        }


        public virtual void Popular(Compra aCompra)
        {
            permiteExclusao = false;
            // Formata os valores de preço para exibição correta
            txtNumNFC.Value = aCompra.NumNFC;
            txtModeloNFC.Value = aCompra.ModeloNFC;
            txtSerieNFC.Value = aCompra.SerieNFC;
            txtCodigo.Text = aCompra.Fornecedor.ID.ToString();
            txtFornecedor.Text = aCompra.Fornecedor.NomeFantasia;
            dtChegada.Value = aCompra.DataChegada;
            dtEmissao.Value = aCompra.DataEmissao;
            txtCodCondicao.Text = aCompra.Condicao.ID.ToString();
            txtCondicao.Text = aCompra.Condicao.Condicao;
            txtFrete.Text = aCompra.ValorFrete.ToString("0.##", cultura);
            txtSeguro.Text = aCompra.ValorSeguro.ToString("0.##", cultura);
            txtOutras.Text = aCompra.ValorOutrasDespesas.ToString("0.##", cultura);
            txtTotalNota.Text = aCompra.ValorTotal.ToString("0.##", cultura);

            int codigo = Convert.ToInt32(txtNumNFC.Value);
            int modelo = Convert.ToInt32(txtModeloNFC.Value);
            int serie = Convert.ToInt32(txtSerieNFC.Value);
            int fornecedor = Convert.ToInt32(txtCodigo.Text);

            CTLItensCompra aCTLItensCompra = new CTLItensCompra();
            List<ItemCompra> Itemcompra = aCTLItensCompra.BuscarItemCompraPorChave2(codigo, modelo, serie, fornecedor);

            PopularItens(Itemcompra);
            CarregaLV(); // popula a condição de pagamento.
        }
        public void PopularItens(List<ItemCompra> List)
        {
            Dgv.Rows.Clear();
            foreach (ItemCompra Item in List)
            {
                decimal valorItem = Item.QtdProduto * Item.PrecoCusto;
                Dgv.Rows.Add(
                    Properties.Resources.Lixeira_x32,         // 1. Excluir
                    Item.Produto.ID,                          // 2. ID
                    Item.Produto.Nome,                        // 3. Produto
                    valorItem,                                // 4. Valor Item
                    Item.Produto.UnidadeMedida,               // 5. UND
                    Item.QtdProduto,                          // 6. QTD Entrada
                    //Item.Produto.PrecoCusto,                  // 7. Custo Atual
                    Item.PrecoCusto,                          // 8. Preço Compra
                    Item.Desconto,                            // 9. Desconto
                    Item.PercentualCompra,                    // 10. % Compra
                    Item.TotalCusto,                          // 11. Preço Total
                    Item.MediaPonderada                       // 12. Média Ponderada
                );
            }
        }


        #region Itens do form botões eventos etc.

        private void VerificarEExecutarAcao(int nNFC, int nModelo, int nSerie, int codForn)
        {
            var compraExiste = aCTLCompra.VerificarSeCompraExiste(nNFC, nModelo, nSerie, codForn);

            if (compraExiste)
            {
                MessageBox.Show("Nota já cadastrada");
            }
            else
            {
                aCondicao = aCTLcon.BuscarCondicaoPagamentoPorId(oFornecedor.CondicaoPagamento.ID);
                btnVerificar.Visible = false;
                txtCodigo.Enabled = false;
                gbDatas.Enabled = true;
                GbChave.Enabled = false; // bloqueia campo chave para não mais mudar.
            }
        }
        private void LimparFornecedor()
        {
            txtFornecedor.Clear();
            txtCodigo.Clear();
        }
        private void CarregaLV()
        {
            int cod = Convert.ToInt32(txtCodCondicao.Text);
            CTLParcelas aCTLParcela = new CTLParcelas();
            List<Parcela> dados = aCTLParcela.BuscarParcelasPorIDCondicao(cod);

            // Aqui você precisa buscar as contas a pagar reais
            int numNFC = Convert.ToInt32(txtNumNFC.Value);
            int modeloNFC = Convert.ToInt32(txtModeloNFC.Value);
            int serieNFC = Convert.ToInt32(txtSerieNFC.Value);
            int numFornecedor = Convert.ToInt32(txtCodigo.Text);
            int parcelaNFC = 0; // Para buscar todas as parcelas

            ContasPagar contaPagar = aCTLContasPagar.BuscarContaPagar(numNFC, modeloNFC, serieNFC, numFornecedor, parcelaNFC);
            List<ContasPagar> dados2 = new List<ContasPagar>();
            if (contaPagar != null)
            {
                dados2.Add(contaPagar);
            }
            //List<ContasPagar> dados2 = aCTLContasPagar.BuscarContas(numNFC, modeloNFC, serieNFC, numFornecedor, parcelaNFC);
            PreencherListView(dados); // Limpa e adiciona as parcelas
            PreencherListViewContasPagar(dados2); // Adiciona as contas a pagar (sem limpar)
        }
        private void PreencherListView(IEnumerable<Parcela> dados)
        {
            lvParcelas.Items.Clear();

            // Calcula o custo total com os adicionais uma vez para uso em todas as parcelas
            decimal custoTotalComAdicionais = CalcularCustoTotalComAdicionais();

            foreach (var parcela in dados)
            {
                ListViewItem item = new ListViewItem(parcela.NumParcela.ToString());
                item.SubItems.Add(parcela.DiasTotais.ToString());
                item.SubItems.Add(parcela.Forma.ID.ToString());
                item.SubItems.Add(parcela.Forma.Forma);
                item.SubItems.Add(parcela.Porcentagem.ToString());

                // Calcula o valor da parcela com base na porcentagem e no custo total com adicionais
                decimal valorParcela = (parcela.Porcentagem / 100) * custoTotalComAdicionais;
                item.SubItems.Add(valorParcela.ToString("F2")); // Adiciona o valor da parcela na posição correta

                item.Tag = parcela;
                lvParcelas.Items.Add(item);
            }
        }

        private void PreencherListViewContasPagar (IEnumerable<ContasPagar> dados)
        {
            lvContasPagar.Items.Clear();

            foreach (var conta in dados)
            {
                ListViewItem item = new ListViewItem(conta.NumParcela.ToString());
                item.SubItems.Add(conta.DataVencimento.ToShortDateString());
                item.SubItems.Add(conta.FormaPagamento.ID.ToString());
                item.SubItems.Add(conta.FormaPagamento.Forma);
                item.SubItems.Add(conta.Taxa.ToString("F2"));
                item.SubItems.Add(conta.Valor.ToString("F2"));
                item.SubItems.Add(conta.Situacao);
                item.SubItems.Add(conta.NumNFC.ToString());
                item.SubItems.Add(conta.ModeloNFC.ToString());
                item.SubItems.Add(conta.SerieNFC.ToString());
                item.SubItems.Add(conta.Fornecedor.ID.ToString());
                item.SubItems.Add(conta.Condicao.ID.ToString());
                item.SubItems.Add(conta.NumParcela.ToString());
                item.Tag = conta;
                lvContasPagar.Items.Add(item);
            }
        }

        private void InicializarColunasListViewContasPagar()
        {
            lvContasPagar.Columns.Clear();
            lvContasPagar.View = View.Details;
            lvContasPagar.FullRowSelect = true;
            lvContasPagar.GridLines = true;

            lvContasPagar.Columns.Add("Nº Parcela", 80);
            lvContasPagar.Columns.Add("Vencimento", 100);
            lvContasPagar.Columns.Add("ID Forma", 70);
            lvContasPagar.Columns.Add("Forma Pagamento", 120);
            lvContasPagar.Columns.Add("Taxa", 70);
            lvContasPagar.Columns.Add("Valor", 90);
            lvContasPagar.Columns.Add("Situação", 90);
            lvContasPagar.Columns.Add("Nº NFC", 70);
            lvContasPagar.Columns.Add("Modelo NFC", 90);
            lvContasPagar.Columns.Add("Série NFC", 80);
            lvContasPagar.Columns.Add("ID Fornecedor", 90);
            lvContasPagar.Columns.Add("ID Condição", 90);
        }


        private decimal CalcularCustoTotalComAdicionais()
        {
            decimal custoItens = CustoTotal();

            decimal frete = string.IsNullOrEmpty(txtFrete.Text) ? 0 : decimal.Parse(txtFrete.Text, CultureInfo.InvariantCulture);
            decimal seguro = string.IsNullOrEmpty(txtSeguro.Text) ? 0 : decimal.Parse(txtSeguro.Text, CultureInfo.InvariantCulture);
            decimal outras = string.IsNullOrEmpty(txtOutras.Text) ? 0 : decimal.Parse(txtOutras.Text, CultureInfo.InvariantCulture);

            return custoItens + frete + seguro + outras;
        }

        private void btnBuscarFornecedor_Click(object sender, EventArgs e)
        {
            using (FrmConsultaFornecedor frm = new FrmConsultaFornecedor())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txtCodigo.Text = IdSelecionado.ToString();
                txtFornecedor.Text = NomeSelecionado;
            }
        }
        private void LimparText()
        {
            txtCodProduto.Clear();
            txtProduto.Clear();
            txtUND.Clear();
            txtQtd.Clear();
            txtCusto.Clear();
            txtDesconto.Clear();
            txtTotalItens.Clear();
        }
        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (VerificarCamposVazios())
            {
                AdicionarItens();
                LimparText();
                txtTotalNota.Text = Convert.ToString(CustoTotal());
                btnFinaliza.Enabled = true;
            }
        }
        public void AdicionarItens()
        {
            if (decimal.TryParse(txtTotalItens.Text, out decimal total) && total <= 0)
            {
                MessageBox.Show("O total deve ser maior que 0 para adicionar um item.");
                return;
            }
            string idProduto = txtCodProduto.Text;
            if (ProdutoJaAdicionado(idProduto))
            {
                MessageBox.Show("Este produto já foi adicionado.");
                return;
            }

            Produto Produtos = aCTLProdutos.BuscarProdutoPorId(Convert.ToInt32(txtCodProduto.Text));
            var NomeProduto = txtProduto.Text;
            var IdProduto = txtCodProduto.Text;
            var CustoSugerido = txtCusto.Text;
            var Desconto = txtDesconto.Text;
            var QtdEntrada = txtQtd.Text;
            var QtdEstoque = Produtos.QtdEstoque;
            var CustoAtual = Produtos.PrecoCusto;
            var MediaPonderada = 0;
            var Percentual = 0;

            var Unidade = Produtos.UnidadeMedida;

            // Calcula o Valor Item (Qtd * Custo)
            decimal valorItem = 0;
            if (decimal.TryParse(QtdEntrada, out decimal qtd) && decimal.TryParse(CustoSugerido, out decimal custo))
            {
                valorItem = qtd * custo;
            }

            Dgv.Rows.Add(
                Properties.Resources.Lixeira_x32, // 1. Excluir
                IdProduto,                        // 2. ID
                NomeProduto,                      // 3. Produto
                valorItem,                        // 4. Valor Item
                Unidade,                       // 5. UND
                QtdEntrada,                       // 6. QTD Entrada
                                                  //CustoAtual,                       // 7. Custo Atual
                CustoSugerido,                    // 8. Preço Compra
                Desconto,                         // 9. Desconto
                Percentual,                       // 10. % Compra
                MediaPonderada                    // 11. Preço Total
            );
            PercentualItem();
            NovoPrecoItens();

            AtualizarTotalProdutos();
        }
        private void DataGrid()
        {
            Dgv.RowHeadersVisible = false;
            Dgv.AutoGenerateColumns = false;
            Dgv.Columns.Clear();

            // 1. Excluir
            DataGridViewImageColumn deleteColumn = new DataGridViewImageColumn();
            deleteColumn.Name = "DeleteColumn";
            deleteColumn.HeaderText = "Excluir";
            deleteColumn.Width = 80;
            deleteColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
            Dgv.Columns.Add(deleteColumn);

            // 2. ID
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "id_produto", HeaderText = "Cod Prod", DataPropertyName = "id_produto", Width = 70 });

            // 3. Produto
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "produto", HeaderText = "Produto", DataPropertyName = "produto", Width = 400 });

            // 4. Valor Item (agora é a quarta coluna)
            Dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "valor_item",
                HeaderText = "Custo",
                DataPropertyName = "valor_item",
                Width = 100,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleRight }
            });

            // 5. UND
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "und", HeaderText = "UND", DataPropertyName = "und", Width = 125 });

            // 6. QTD Entrada
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "qtd_entrada", HeaderText = "QTD", DataPropertyName = "qtd_entrada", Width = 125 });

            // 7. Custo Atual
            //Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "custo_atual", HeaderText = "Custo Atual", DataPropertyName = "custo_atual", Width = 125, DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleRight } });

            // 8. Preço Compra
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "Custo_Sugerido", HeaderText = "Preço Compra", DataPropertyName = "Custo_Sugerido", Width = 125, DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleRight } });

            // 9. Desconto
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "desconto", HeaderText = "Desconto", DataPropertyName = "desconto", Width = 125, DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleRight } });

            // 10. % Compra
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "percentual_compra", HeaderText = "% Compra", DataPropertyName = "percentual_compra", Width = 125 });

            // 11. Preço Total
            Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "preco_total", HeaderText = "Preço Total", DataPropertyName = "preco_total", Width = 125 });

            // 12. Média Ponderada
            //Dgv.Columns.Add(new DataGridViewTextBoxColumn { Name = "media_ponderada", HeaderText = "Média Ponderada", DataPropertyName = "media_ponderada", Width = 125 });

            Dgv.RowTemplate.Height = 40;
            Dgv.Columns["preco_total"].Visible = false;
            Dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Dgv.MultiSelect = false;
        }

        private void AtualizarTotalNota()
        {
            decimal custoItens = CustoTotal(); // Método para calcular o custo total dos itens da compra

            // Adicionar valores de frete, seguro e outras despesas
            decimal frete = string.IsNullOrEmpty(txtFrete.Text) ? 0 : decimal.Parse(txtFrete.Text, CultureInfo.InvariantCulture);
            decimal seguro = string.IsNullOrEmpty(txtSeguro.Text) ? 0 : decimal.Parse(txtSeguro.Text, CultureInfo.InvariantCulture);
            decimal outras = string.IsNullOrEmpty(txtOutras.Text) ? 0 : decimal.Parse(txtOutras.Text, CultureInfo.InvariantCulture);

            decimal totalNota = custoItens + frete + seguro + outras;

            // Atualizar o valor do txtTotalNota
            txtTotalNota.Text = totalNota.ToString("N2", CultureInfo.InvariantCulture);
        }

        private bool ProdutoJaAdicionado(string idProduto)
        {
            foreach (DataGridViewRow row in Dgv.Rows)
            {
                if (row.Cells["id_produto"].Value != null && row.Cells["id_produto"].Value.ToString() == idProduto)
                {
                    return true;
                }
            }
            return false;
        }
        public void PercentualItem()
        {
            decimal totalQtdEntrada = 0;

            // Primeira passagem: Calcular a quantidade total de todas as linhas válidas
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                if (vLinha.IsNewRow) continue;

                if (vLinha.Cells["qtd_entrada"] != null && vLinha.Cells["qtd_entrada"].Value != null)
                {
                    if (decimal.TryParse(vLinha.Cells["qtd_entrada"].Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal currentQtd))
                    {
                        totalQtdEntrada += currentQtd;
                    }
                }
            }

            // Segunda passagem: Calcular e definir a porcentagem para cada item
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                if (vLinha.IsNewRow) continue;

                if (vLinha.Cells["qtd_entrada"] != null && vLinha.Cells["percentual_compra"] != null)
                {
                    decimal currentQtd = 0;
                    if (vLinha.Cells["qtd_entrada"].Value != null && decimal.TryParse(vLinha.Cells["qtd_entrada"].Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out currentQtd))
                    {
                        decimal calculatedPercentage = 0m;
                        if (totalQtdEntrada > 0)
                        {
                            calculatedPercentage = (currentQtd / totalQtdEntrada) * 100;
                            vLinha.Cells["percentual_compra"].Value = Math.Round(calculatedPercentage, 8);
                        }
                        else
                        {
                            vLinha.Cells["percentual_compra"].Value = 0m;
                        }
                    }
                    else
                    {
                        vLinha.Cells["percentual_compra"].Value = 0m;
                    }
                }
            }
        }
        private void NovoPrecoItens()
        {
            // Analisar Custos de Despesas Gerais - Substituir vírgula por ponto, depois analisar com InvariantCulture
            decimal frete = 0;
            string freteText = txtFrete.Text.Replace(',', '.');
            if (!string.IsNullOrEmpty(freteText))
                decimal.TryParse(freteText, NumberStyles.Any, CultureInfo.InvariantCulture, out frete);

            decimal seguro = 0;
            string seguroText = txtSeguro.Text.Replace(',', '.');
            if (!string.IsNullOrEmpty(seguroText))
                decimal.TryParse(seguroText, NumberStyles.Any, CultureInfo.InvariantCulture, out seguro);

            decimal outrosCustos = 0;
            string outrosCustosText = txtOutras.Text.Replace(',', '.');
            if (!string.IsNullOrEmpty(outrosCustosText))
                decimal.TryParse(outrosCustosText, NumberStyles.Any, CultureInfo.InvariantCulture, out outrosCustos);


            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                if (vLinha.IsNewRow) continue;

                // Recuperar Valores da linha atual do DataGridView
                int productId;
                if (vLinha.Cells["id_produto"] == null || vLinha.Cells["id_produto"].Value == null || !int.TryParse(vLinha.Cells["id_produto"].Value.ToString(), out productId)) continue;

                Produto produtoDetalhes = aCTLProdutos.BuscarProdutoPorId(productId);
                if (produtoDetalhes == null)
                {
                    // Opcional: Lidar com o caso de produto não encontrado, talvez removendo a linha ou exibindo um erro.
                    continue;
                }

                decimal custoProdutoAtual = produtoDetalhes.PrecoCusto;
                if (custoProdutoAtual < 0) custoProdutoAtual = 0;

                decimal qtdEstoqueAtual = produtoDetalhes.QtdEstoque;
                if (qtdEstoqueAtual < 0) qtdEstoqueAtual = 0;


                decimal percentualCompra = 0;
                if (vLinha.Cells["percentual_compra"] != null && vLinha.Cells["percentual_compra"].Value != null)
                    decimal.TryParse(vLinha.Cells["percentual_compra"].Value.ToString().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out percentualCompra);

                decimal initialUnitPurchasePrice = 0;
                if (vLinha.Cells["Custo_Sugerido"] != null && vLinha.Cells["Custo_Sugerido"].Value != null)
                    decimal.TryParse(vLinha.Cells["Custo_Sugerido"].Value.ToString().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out initialUnitPurchasePrice);

                int qtdEntradaEstoque = 0;
                if (vLinha.Cells["qtd_entrada"] != null && vLinha.Cells["qtd_entrada"].Value != null)
                    int.TryParse(vLinha.Cells["qtd_entrada"].Value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out qtdEntradaEstoque);

                decimal descontoUnitario = 0;
                if (vLinha.Cells["desconto"] != null && vLinha.Cells["desconto"].Value != null)
                    decimal.TryParse(vLinha.Cells["desconto"].Value.ToString().Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out descontoUnitario);


                // Calcular para Média Ponderada
                decimal ratFrete = (percentualCompra / 100m) * frete;
                decimal ratSeguro = (percentualCompra / 100m) * seguro;
                decimal ratOutrosCustos = (percentualCompra / 100m) * outrosCustos;

                decimal finalEffectiveUnitCostForAverage = (initialUnitPurchasePrice + ratFrete + ratSeguro + ratOutrosCustos) - descontoUnitario;
                if (finalEffectiveUnitCostForAverage < 0) finalEffectiveUnitCostForAverage = 0;

                // Calcular Média Ponderada
                decimal mediaPond = 0;
                if (qtdEstoqueAtual + qtdEntradaEstoque > 0)
                {
                    mediaPond = ((qtdEstoqueAtual * custoProdutoAtual) + (qtdEntradaEstoque * finalEffectiveUnitCostForAverage)) / (qtdEstoqueAtual + qtdEntradaEstoque);
                }
                else
                {
                    mediaPond = finalEffectiveUnitCostForAverage;
                }

                // Atualizar Células do DataGridView
                vLinha.Cells["media_ponderada"].Value = Math.Round(mediaPond, 8);
            }
        }

        private void LiberarCondicaoPagamento()
        {
            if (Dgv.Rows.Count > 0)
            {
                if (aCondicao != null)
                {
                    txtCodCondicao.Text = aCondicao.ID.ToString();
                    txtCondicao.Text = aCondicao.Condicao;
                    CarregaLV();
                }
            }
            else
            {
                gbCondicao.Enabled = false;
                txtCodCondicao.Text = "";
                txtCondicao.Text = "";
            }
        }

        private decimal CustoTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow vLinha in Dgv.Rows)
            {
                total += Convert.ToDecimal(vLinha.Cells["qtd_entrada"].Value) * Convert.ToDecimal(vLinha.Cells["custo_sugerido"].Value);
            }
            return total;
        }
        private void txtCodProduto_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodProduto.Text))
                LimparProdutos();
            else if (int.TryParse(txtCodProduto.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente
                CTLProdutos aCTLprod = new CTLProdutos();
                Produto produto = aCTLprod.BuscarProdutoPorId(cod);

                if (produto == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparProdutos();
                }
                else
                {
                    txtProduto.Text = produto.Nome;
                    txtUND.Text = produto.QtdEstoque.ToString();

                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparProdutos();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }
        private void LimparProdutos()
        {
            txtProduto.Clear();
            txtCodProduto.Clear();
        }
        private void btnBuscarProduto_Click(object sender, EventArgs e)
        {
            using (FrmConsultaProduto frm = new FrmConsultaProduto())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;
                string unidade = frm.Und;

                txtCodProduto.Text = IdSelecionado.ToString();
                txtProduto.Text = NomeSelecionado;
                txtUND.Text = unidade;
                txtCodProduto_Leave(txtCodProduto, EventArgs.Empty);

            }
        }

        private void txtCodFornecedor_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null; // Remove o botão "SALVAR" como botão padrão
        }
        #endregion
        private void txtNumNFC_Leave(object sender, EventArgs e)
        {
            ValidarNota();
        }
        public bool ValidarNota()
        {
            if (txtNumNFC.Value > 0 && txtModeloNFC.Value > 0 && txtSerieNFC.Value > 0 && Convert.ToInt32(txtCodigo.Text) > 0)
            {
                var Obj = aCTLCompra.BuscarCompraPorChave(Convert.ToInt32(txtNumNFC.Value), Convert.ToInt32(txtModeloNFC.Value),
                    Convert.ToInt32(txtSerieNFC.Value), Convert.ToInt32(Convert.ToInt32(txtCodigo.Text)));
                if (Obj == null)
                {
                    MessageBox.Show("Nota ja cadastrada");
                    return false;
                }
                else
                {
                    Desbloquear();
                }
                return true;
            }
            return false;
        }
        public void Desbloquear()
        {
            GbChave.Enabled = false;
            gbCondicao.Enabled = true;
            gbDatas.Enabled = true;
            gbProdutos.Enabled = true;
        }
        private void txtQtd_Leave(object sender, EventArgs e)
        {
            try
            {
                // Tenta converter os valores dos campos para os cálculos
                decimal qtd = string.IsNullOrWhiteSpace(txtQtd.Text) ? 0 : decimal.Parse(txtQtd.Text, cultura);
                decimal custo = string.IsNullOrWhiteSpace(txtCusto.Text) ? 0 : decimal.Parse(txtCusto.Text, cultura);
                decimal desconto = string.IsNullOrWhiteSpace(txtDesconto.Text) ? 0 : decimal.Parse(txtDesconto.Text, cultura);

                // Calcula o total
                decimal total = (qtd * custo) - (qtd * desconto);

                txtTotalItens.Text = total.ToString("0.00", cultura); // AQUI
            }
            catch (FormatException)
            {
                // Exibe uma mensagem de erro se a conversão falhar
                MessageBox.Show("Por favor, insira valores válidos.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }
        private void txtCodigo_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null; // Remove o botão "SALVAR" como botão padrão      
        }
        private void txtFrete_Leave(object sender, EventArgs e)
        {
            AtualizarTotalNota();
        }
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodigo.Text))
                LimparFornecedor();
            else if (int.TryParse(txtCodigo.Text, out int cod) && cod > 0)
            {


                oFornecedor = aCTLForn.BuscarFornecedorPorId(cod);

                if (oFornecedor == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparFornecedor();
                }
                else if (oFornecedor.StatusFornecedor == "I")
                {
                    MessageBox.Show("O Fornecedor associado a este código está inativo.");
                    LimparFornecedor();
                }
                else
                {
                    txtFornecedor.Text = oFornecedor.NomeFantasia;

                    int nNFC = (int)txtNumNFC.Value;
                    int nModelo = (int)txtModeloNFC.Value;
                    int nSerie = (int)txtSerieNFC.Value;
                    int codForn = Convert.ToInt32(txtCodigo.Text);
                    VerificarEExecutarAcao(nNFC, nModelo, nSerie, codForn);

                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparFornecedor();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }
        private void txtCusto_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPressComVirgula((System.Windows.Forms.TextBox)sender, e);
        }
        private void txtNumNFC_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verifica se o caractere digitado é o ponto (.) ou a vírgula (,)
            if (e.KeyChar == '.' || e.KeyChar == ',')
            {
                // Se for, cancela o evento de pressionar a tecla
                e.Handled = true;
            }
        }

        private void txtFrete_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPressComVirgula((System.Windows.Forms.TextBox)sender, e);
        }
        private bool VerificaData()
        {
            // Supondo que dtChegada e dtEmissao são DateTimePickers
            DateTime dataEmissao = dtEmissao.Value.Date;
            DateTime dataChegada = dtChegada.Value.Date;
            DateTime dataAtual = DateTime.Now.Date;

            // Verificar se a data de emissão não é futura
            if (dataEmissao > dataAtual)
            {
                MessageBox.Show("A data de emissão de compra não pode ser no futuro. Apenas data de hoje ou anterior é permitida.",
                    "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            // Verificar se a data de chegada não é futura
            if (dataChegada > dataAtual)
            {
                MessageBox.Show("A data de chegada não pode ser uma data futura.",
                    "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            // Verificar se a data de chegada é maior ou igual à data de emissão
            if (dataChegada < dataEmissao)
            {
                MessageBox.Show("A data de chegada deve ser maior ou igual à data de emissão. Não é possível que o produto chegue antes da emissão da nota.",
                    "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void btnVerificaData_Click(object sender, EventArgs e)
        {
            if (VerificaData())
            {
                gbProdutos.Enabled = true;
            }
        }


        private void Dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == Dgv.Columns["DeleteColumn"].Index && e.RowIndex >= 0 && permiteExclusao)
            {
                // Confirmação de exclusão
                var resultado = MessageBox.Show("Você tem certeza que deseja excluir este item?",
                    "Confirmação de Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    Dgv.Rows.RemoveAt(e.RowIndex);
                    txtTotalNota.Text = Convert.ToString(CustoTotal());
                    AtualizarTotalProdutos();
                }
            }
        }

        private void btnLiberarCondicao_Click(object sender, EventArgs e)
        {
            if (btnFinaliza.Text == "FINALIZAR COMPRA")
            {
                LimparProdutos();
                gbProdutos.Enabled = false;
                gbCondicao.Enabled = true;
                permiteExclusao = false;
                btnFinaliza.Text = "LIBERAR PRODUTOS";
                btnFinaliza.BackColor = Color.DarkGoldenrod;
                txtCodCondicao.Text = aCondicao.ID.ToString();
                txtCondicao.Text = aCondicao.Condicao;

            }
            else
            {
                LimparProdutos();
                gbProdutos.Enabled = true;
                gbCondicao.Enabled = false;
                Dgv.ReadOnly = false;
                permiteExclusao = true;
                lvParcelas.Items.Clear();
                txtFrete.Text = "0";
                txtOutras.Text = "0";
                txtSeguro.Text = "0";
                btnFinaliza.Text = "FINALIZAR COMPRA";
                //btnFinaliza.BackColor = Color.DarkRed;

            }
            AtualizarTotalNota();
        }

        private void btnFinalizaCondicao_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodCondicao.Text) || string.IsNullOrEmpty(txtCondicao.Text))
            {
                MessageBox.Show("Nenhuma condição de pagamento encontrada.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (btnFinalizaCondicao.Text == "FINALIZAR")
            {
                LiberarFrete(false);
                btnFinalizaCondicao.Text = "LIBERAR"; // muda o texto do botão
                btnFinalizaCondicao.BackColor = Color.DarkGoldenrod; // muda a cor do botão
                btnFinalizaCondicao.Enabled = true; //mantem o botão aberto
                txtTotalNota.Enabled = true; // mantem a nota aberta.
                AtualizarTotalNota();// chama para recalcular as parcelas 
                LiberarCondicaoPagamento();
                AutorizadoSalvar = true;
                btnBuscarCondicao.Enabled = false;
                txtCodCondicao.Enabled = false;

            }
            else if (btnFinalizaCondicao.Text == "LIBERAR")
            {
                LiberarFrete(true);
                btnFinalizaCondicao.Text = "FINALIZAR";
                //btnFinalizaCondicao.BackColor = Color.DarkRed;
                btnFinalizaCondicao.Enabled = true;
                AtualizarTotalNota();// chama para recalcular as parcelas 
                LiberarCondicaoPagamento();
                AutorizadoSalvar = false;
                btnBuscarCondicao.Enabled = true;
                txtCodCondicao.Enabled = true;
            }
        }
        private void LiberarFrete(bool valor)
        {
            txtFrete.Enabled = valor;
            txtOutras.Enabled = valor;
            txtSeguro.Enabled = valor;
        }

        private void btnBuscarCondicao_Click(object sender, EventArgs e)
        {
            using (FrmConsultaCondicaoPagamento frm = new FrmConsultaCondicaoPagamento())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txtCodCondicao.Text = IdSelecionado.ToString();
                txtCondicao.Text = NomeSelecionado;
                aCondicao = aCTLcon.BuscarCondicaoPagamentoPorId(IdSelecionado);
                lvParcelas.Items.Clear();
            }
        }

        private void txtCodCondicao_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodCondicao.Text))
                LimparCondicao();
            else if (int.TryParse(txtCodCondicao.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente

                aCondicao = aCTLcon.BuscarCondicaoPagamentoPorId(cod);

                if (aCondicao == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparCondicao();
                }
                else
                {
                    txtCondicao.Text = aCondicao.Condicao;
                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparCondicao();
            }
            lvParcelas.Items.Clear();
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }
        private void LimparCondicao()
        {
            txtCondicao.Clear();
            txtCodCondicao.Clear();
        }

        private void AtualizarTotalProdutos()
        {
            decimal total = 0;
            foreach (DataGridViewRow row in Dgv.Rows)
            {
                if (row.Cells["valor_item"].Value != null)
                {
                    decimal valorItem;
                    if (decimal.TryParse(row.Cells["valor_item"].Value.ToString(), out valorItem))
                    {
                        total += valorItem;
                    }
                }
            }
            txtTotalProds.Text = total.ToString("N2", cultura);
        }


        private void FrmCadastroCompra_Load(object sender, EventArgs e)
        {

        }

        private void gbCondicao_Enter(object sender, EventArgs e)
        {

        }

        private void txtFrete_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
#region itens futuros com xml.
/*
    private void btnImportarXML_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Arquivos XML (*.xml)|*.xml";
            openFileDialog.Title = "Selecionar Arquivo XML";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ProcessarXML(openFileDialog.FileName);

                    MessageBox.Show("XML importado com sucesso!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao importar XML: " + ex.Message);
                }
            }
        }

        private void ProcessarXML(string filePath)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filePath);

            XmlNodeList nNF = xmlDoc.GetElementsByTagName("nNF");
            XmlNodeList serie = xmlDoc.GetElementsByTagName("serie");
            XmlNodeList modelo = xmlDoc.GetElementsByTagName("mod");
            XmlNodeList dhEmi = xmlDoc.GetElementsByTagName("dhEmi");
            XmlNodeList dhSaiEnt = xmlDoc.GetElementsByTagName("dhSaiEnt");
            XmlNodeList vNF = xmlDoc.GetElementsByTagName("vNF");
            XmlNodeList vFrete = xmlDoc.GetElementsByTagName("vFrete");
            XmlNodeList vSeg = xmlDoc.GetElementsByTagName("vSeg");
            XmlNodeList vOutro = xmlDoc.GetElementsByTagName("vOutro");
            XmlNodeList cProd = xmlDoc.GetElementsByTagName("cProd");
            XmlNodeList xProd = xmlDoc.GetElementsByTagName("xProd");
            XmlNodeList uCom = xmlDoc.GetElementsByTagName("uCom");
            XmlNodeList qCom = xmlDoc.GetElementsByTagName("qCom");
            XmlNodeList vUnCom = xmlDoc.GetElementsByTagName("vUnCom");

            // NOTA FISCAL IDENT.
            txtNumero.Text = GetValueIfExists(nNF);
            txtSerie.Text = GetValueIfExists(serie);
            txtModelo.Text = GetValueIfExists(modelo);
            txtTotalNota.Text = GetValueIfExists(vNF);
            txtDataEmissao.Text = GetDateTimeValueIfExists(dhEmi);
            txtDataChegada.Text = GetDateTimeValueIfExists(dhSaiEnt);

            // Preencher campos com valores dos itens da NF
            double freteTotal = GetDoubleValueFromItems(xmlDoc, "vFrete");
            double seguroTotal = GetDoubleValueFromItems(xmlDoc, "vSeg");
            double outrasDespesasTotal = GetDoubleValueFromItems(xmlDoc, "vOutro");

            txtFrete.Text = freteTotal.ToString("0.00");
            txtSeguro.Text = seguroTotal.ToString("0.00");
            txtOutras.Text = outrasDespesasTotal.ToString("0.00");

            // Adicionar produtos à ListView
            for (int i = 0; i < cProd.Count; i++)
            {
                string codigoProduto = cProd[i].InnerText;
                string nomeProduto = xProd[i].InnerText;
                string unidadeMedida = uCom[i].InnerText;
                string quantidade = qCom[i].InnerText;
                string custoUnitario = vUnCom[i].InnerText;

                AdicionarNaListView(codigoProduto, nomeProduto, unidadeMedida, quantidade, custoUnitario);
            }
        }*/
#endregion