﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using TextBox = System.Windows.Forms.TextBox;

namespace PP_2025
{
    public partial class FrmCadastroContaPagar : FrmCadastros
    {
        ContasPagar aConta;
        CTLContasPagar aCTLConta;
        CultureInfo cultura = CultureInfo.InvariantCulture;
        public FrmCadastroContaPagar()
        {
            InitializeComponent();
            aConta = new ContasPagar();
            aCTLConta = new CTLContasPagar();

            dtBaixa.Format = DateTimePickerFormat.Custom;
            dtBaixa.CustomFormat = "dd/MM/yy";

            dtEmissao.Format = DateTimePickerFormat.Custom;
            dtEmissao.CustomFormat = "dd/MM/yy";

            dtVencimento.Format = DateTimePickerFormat.Custom;
            dtVencimento.CustomFormat = "dd/MM/yy";
        }


        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is ContasPagar conta)
            {
                aConta = conta;
                CarregarCampos();
            }
        }
        protected override void LimparCampos()
        {
            txtCodigo.Clear();
            txtModelo.Clear();
            txtSerie.Clear();
            txtParcela.Clear();
            txtCodForn.Clear();
            txtCodCondPg.Clear();
            txtCodForma.Clear();
            txtForma.Clear();
            txtFornecedor.Clear();
            txtStatus.Clear();
            txtTaxa.Clear();
            txtMulta.Clear();
            txtDesconto.Clear();
            txtParcela.Clear();
            txtTotalPago.Clear();
            dtVencimento.Value = DateTime.Now;
            dtEmissao.Value = DateTime.Now;
            dtBaixa.Value = DateTime.Now;
        }
        public override void BloquearCampos()
        {
            base.BloquearCampos();
            txtCodigo.Enabled = false;
            txtModelo.Enabled = false;
            txtSerie.Enabled = false;
            txtParcela.Enabled = false;
            txtCodForn.Enabled = false;
            txtCodCondPg.Enabled = false;
            txtCodForma.Enabled = false;
            txtForma.Enabled = false;
            txtFornecedor.Enabled = false;
            txtStatus.Enabled = false;
            txtTaxa.Enabled = false;
            txtMulta.Enabled = false;
            txtDesconto.Enabled = false;
            txtTotalPago.Enabled = false;
            dtVencimento.Enabled = false;
            dtBaixa.Enabled = false;
            dtEmissao.Enabled = false;
            btnSalvar.Enabled = false;
        }
        public override void DesbloquearCampos()
        {
            base.DesbloquearCampos();
            txtCodigo.Enabled = true;
            txtModelo.Enabled = true;
            txtSerie.Enabled = true;
            txtParcela.Enabled = true;
            txtCodForn.Enabled = true;
            txtCodCondPg.Enabled = true;
            dtEmissao.Enabled = true;
            txtCodForma.Enabled = true;
            txtForma.Enabled = true;
            txtFornecedor.Enabled = true;
            txtStatus.Enabled = true;
            txtTaxa.Enabled = true;
            txtMulta.Enabled = true;
            txtDesconto.Enabled = true;
            txtTotalPago.Enabled = true;
            dtVencimento.Enabled = true;
            dtBaixa.Enabled = true;
            btnSalvar.Enabled = true;
        }
        public override void CarregarCampos()
        {
            base.CarregarCampos();

            txtCodigo.Text = aConta.NumNFC.ToString();
            txtModelo.Text = aConta.ModeloNFC.ToString();
            txtSerie.Text = aConta.SerieNFC.ToString();
            txtParcela.Text = aConta.NumParcela.ToString();
            txtCodForn.Text = aConta.Fornecedor.ID.ToString();
            txtCodCondPg.Text = aConta.Condicao.ID.ToString();
            txtCodForma.Text = aConta.FormaPagamento.ID.ToString();
            txtForma.Text = aConta.FormaPagamento.Forma;
            txtFornecedor.Text = aConta.Fornecedor.NomeFantasia;
            txtStatus.Text = aConta.Situacao;
            txtTaxa.Text = aConta.Taxa.ToString("0.00", cultura);
            txtMulta.Text = aConta.Multa.ToString("0.00", cultura);
            txtDesconto.Text = aConta.Desconto.ToString("0.00", cultura);
            txtValorParcela.Text = aConta.Valor.ToString("0.00", cultura);
            dtEmissao.Value = aConta.DataCriacao;
            dtVencimento.Value = aConta.DataVencimento;

            // Verifica se DataBaixa é nulo ou default (DateTime.MinValue) e atribui DateTime.Now se for o caso
            dtBaixa.Value = aConta.DataBaixa != DateTime.MinValue ? aConta.DataBaixa : DateTime.Now;

            txtTotalPago.Text = aConta.Pagamento.ToString("0.00", cultura);
            if (txtStatus.Text == "PAGO")
                BloquearCampos();
        }

        protected bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            // Verifica se o campo txtTotalPago está vazio ou é zero
            if (string.IsNullOrWhiteSpace(txtTotalPago.Text) || !decimal.TryParse(txtTotalPago.Text.Replace('.', ','), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal totalPago) || totalPago <= 0)
            {
                if (btnSalvar.Text != "ALTERAR")// se for SALVAR então precsa do valor para pagar, alteração não vai salvar o valor da parcela. pois não da baixa na mesma.
                    camposFaltantes.Add("Valor total pago deve ser um número maior que zero.");
            }
            else
            {
                // Verifica se txtValorParcela não está vazio e tenta converter
                if (string.IsNullOrWhiteSpace(txtValorParcela.Text) || !decimal.TryParse(txtValorParcela.Text.Replace('.', ','), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal valorParcela) || valorParcela <= 0)
                {
                    camposFaltantes.Add("Valor da parcela deve ser um número maior que zero.");
                }
                else
                {
                    // Arredonda os valores para duas casas decimais
                    decimal valorParcelaArredondado = Math.Round(valorParcela, 2);
                    decimal totalPagoArredondado = Math.Round(totalPago, 2);

                    // Verifica se o valor pago é menor que o valor da parcela
                    if (totalPagoArredondado < valorParcelaArredondado)
                    {
                        DialogResult result = MessageBox.Show(
                            "O valor pago é menor que o valor da parcela. Tem certeza que deseja prosseguir?",
                            "Valor Inferior",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (result == DialogResult.No)
                        {
                            return false; // O usuário escolheu não prosseguir
                        }
                    }

                }

                // Verifica se txtValorSugerido não está vazio e tenta converter
                if (!string.IsNullOrWhiteSpace(txtValorSugerido.Text) && decimal.TryParse(txtValorSugerido.Text.Replace('.', ','), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal valorSugerido) && valorSugerido > 0)
                {
                    // Verifica se o valor pago é menor que o valor sugerido
                    if (totalPago < valorSugerido)
                    {
                        DialogResult result = MessageBox.Show(
                            "O valor pago é menor que o valor sugerido. Tem certeza que deseja prosseguir?",
                            "Valor Inferior",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (result == DialogResult.No)
                        {
                            return false; // O usuário escolheu não prosseguir
                        }
                    }
                }
            }

            // Verifica se a data de baixa é maior que a data atual
            if (dtBaixa.Value.Date > DateTime.Now.Date)
            {
                camposFaltantes.Add("Data de baixa não pode ser uma data futura.");
            }

            // Verifica se o desconto é válido (não vazio)
            if (!decimal.TryParse(txtDesconto.Text, out decimal desconto))
            {
                camposFaltantes.Add("Desconto");
            }

            // Verifica se a taxa é válida (não vazia)
            if (!decimal.TryParse(txtTaxa.Text, out decimal taxa))
            {
                camposFaltantes.Add("Taxa");
            }

            // Verifica se a multa é válida (não vazia)
            if (!decimal.TryParse(txtMulta.Text, out decimal multa))
            {
                camposFaltantes.Add("Multa");
            }

            // Se houver campos faltantes, mostra mensagem de erro
            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos ou contêm valores inválidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            return true;
        }




        protected override void Salvar()
        {
            if (VerificarCamposVazios())
            {

                aConta.DataUltAlteracao = DateTime.Now;
                aConta.DataVencimento = dtVencimento.Value;
                aConta.Taxa = decimal.Parse(txtTaxa.Text, cultura);
                aConta.Multa = decimal.Parse(txtMulta.Text, cultura);
                aConta.Desconto = decimal.Parse(txtDesconto.Text, cultura);

                if (btnSalvar.Text == "SALVAR")
                {
                    aConta.Situacao = "PAGO";
                    aConta.DataBaixa = dtBaixa.Value;
                    aConta.Pagamento = decimal.Parse(txtTotalPago.Text, cultura);
                    var result = aCTLConta.Quitar(aConta);
                    if (result == "OK")
                    {
                        MessageBox.Show("Operação realizada com sucesso ");
                        Close();
                    }
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else if (btnSalvar.Text == "ALTERAR")
                {
                    var result = aCTLConta.AtualizarContaPagar(aConta);
                    if (result == "OK")
                    {
                        MessageBox.Show("Operação realizada com sucesso ");
                        Close();
                    }
                    else
                        MessageBox.Show("Erro inesperado.");
                }


            }
        }

        protected void txtTotalPago_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite apenas números, um ponto decimal e teclas de controle (como Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // Permite apenas um ponto decimal
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

            // Bloqueia qualquer modificação com Ctrl
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }
        protected virtual void VerificarValor()
        {
            try
            {
                // Configuração de cultura para interpretar vírgulas como separadores decimais
                CultureInfo cultura = new CultureInfo("pt-BR");
                NumberFormatInfo formato = cultura.NumberFormat;
                formato.NumberDecimalSeparator = ",";
                formato.NumberGroupSeparator = ".";

                // Converta os valores dos TextBoxes para decimal para realizar cálculos
                decimal valorParcela;
                decimal taxaJurosDiaria;
                decimal multaDiaria;
                decimal desconto;

                // Corrija o formato de entrada substituindo ponto por vírgula para os valores com vírgula
                string valorParcelaStr = txtValorParcela.Text.Replace('.', ',');
                string taxaJurosStr = txtTaxa.Text.Replace('.', ',');
                string multaDiariaStr = txtMulta.Text.Replace('.', ',');
                string descontoStr = txtDesconto.Text.Replace('.', ',');

                if (!decimal.TryParse(valorParcelaStr, NumberStyles.Any, formato, out valorParcela))
                {
                    MessageBox.Show("Valor da parcela inválido. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!decimal.TryParse(taxaJurosStr, NumberStyles.Any, formato, out taxaJurosDiaria))
                {
                    MessageBox.Show("Taxa de juros inválida. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!decimal.TryParse(multaDiariaStr, NumberStyles.Any, formato, out multaDiaria))
                {
                    MessageBox.Show("Multa diária inválida. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!decimal.TryParse(descontoStr, NumberStyles.Any, formato, out desconto))
                {
                    MessageBox.Show("Desconto inválido. Verifique o formato.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Ajusta a taxa de juros para ser um valor decimal entre 0 e 1
                taxaJurosDiaria /= 100;

                // Obtenha as datas dos DateTimePickers
                DateTime dataVencimento = dtVencimento.Value.Date;
                DateTime dataBaixa = dtBaixa.Value.Date;

                decimal totalPago = valorParcela; // Inicialize com o valor da parcela

                // Verifique se a data de pagamento é posterior ao vencimento (atraso)
                if (dataBaixa > dataVencimento)
                {
                    int diasAtraso = (dataBaixa - dataVencimento).Days;
                    decimal juros = valorParcela * taxaJurosDiaria * diasAtraso;
                    decimal multa = multaDiaria * diasAtraso;

                    totalPago += juros + multa; // Adicione juros e multa ao valor total
                }
                // Verifique se a data de pagamento é anterior ao vencimento (desconto)
                else if (dataBaixa < dataVencimento)
                {
                    decimal descontoAplicado = valorParcela * (desconto / 100); // Calcula o desconto aplicado
                    totalPago -= descontoAplicado; // Subtraia o desconto do valor total
                }

                // Mostre o valor total a ser pago no TextBox txtValorSugerido
                txtValorSugerido.Text = totalPago.ToString("F2", cultura); // Formatação com 2 casas decimais
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao calcular o valor sugerido: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            VerificarValor();
        }

    }
}
