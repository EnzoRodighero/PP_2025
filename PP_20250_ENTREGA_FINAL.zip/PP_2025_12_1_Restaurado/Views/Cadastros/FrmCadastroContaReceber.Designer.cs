﻿namespace PP_2025
{
    partial class FrmCadastroContaReceber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // txtStatus
            // 
            this.txtStatus.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // txtFornecedor
            // 
            this.txtFornecedor.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(272, 589);
            // 
            // txtValorSugerido
            // 
            this.txtValorSugerido.Location = new System.Drawing.Point(55, 589);
            this.txtValorSugerido.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // txtModelo
            // 
            this.txtModelo.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // label3
            // 
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Size = new System.Drawing.Size(96, 18);
            this.label3.Text = "Cod Cliente.";
            // 
            // txtMulta
            // 
            this.txtMulta.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtCodForn
            // 
            this.txtCodForn.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtSerie
            // 
            this.txtSerie.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtParcela
            // 
            this.txtParcela.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtCodCondPg
            // 
            this.txtCodCondPg.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtCodForma
            // 
            this.txtCodForma.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtTaxa
            // 
            this.txtTaxa.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtDesconto
            // 
            this.txtDesconto.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtValorParcela
            // 
            this.txtValorParcela.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtForma
            // 
            this.txtForma.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            // 
            // txtValor
            // 
            this.txtValor.Location = new System.Drawing.Point(51, 568);
            // 
            // label8
            // 
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Size = new System.Drawing.Size(59, 18);
            this.label8.Text = "Cliente";
            // 
            // txtTotalPago
            // 
            this.txtTotalPago.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtTotalPago.Size = new System.Drawing.Size(322, 90);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            // 
            // FrmCadastroContaReceber
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(706, 536);
            this.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.Name = "FrmCadastroContaReceber";
            this.Text = "Contas a receber";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}
