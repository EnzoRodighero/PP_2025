﻿namespace PP_2025
{
    partial class FrmCadastroPessoa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbFisJur = new System.Windows.Forms.ComboBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblTipo = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtApelido = new System.Windows.Forms.TextBox();
            this.lblApelido = new System.Windows.Forms.Label();
            this.cmbSexo = new System.Windows.Forms.ComboBox();
            this.lblSexo = new System.Windows.Forms.Label();
            this.txtLogradouro = new System.Windows.Forms.TextBox();
            this.lblLogradouro = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.lblNum = new System.Windows.Forms.Label();
            this.txtComplemento = new System.Windows.Forms.TextBox();
            this.lblComplemento = new System.Windows.Forms.Label();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.lblBairro = new System.Windows.Forms.Label();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.lblCidade = new System.Windows.Forms.Label();
            this.txtCEP = new System.Windows.Forms.TextBox();
            this.lblCEP = new System.Windows.Forms.Label();
            this.btnBuscaCep = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.txtCelular = new System.Windows.Forms.TextBox();
            this.lblCelular = new System.Windows.Forms.Label();
            this.txtRG = new System.Windows.Forms.TextBox();
            this.lblRG = new System.Windows.Forms.Label();
            this.txtCPFouCNPJ = new System.Windows.Forms.TextBox();
            this.lblCPFouCNPJ = new System.Windows.Forms.Label();
            this.dtNascimento = new System.Windows.Forms.DateTimePicker();
            this.lblNasc = new System.Windows.Forms.Label();
            this.txtCodCargo = new System.Windows.Forms.TextBox();
            this.lblCodCargo = new System.Windows.Forms.Label();
            this.btnBuscaCid = new System.Windows.Forms.Button();
            this.txtCargo = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.btnBuscarCargo = new System.Windows.Forms.Button();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.lblSalario = new System.Windows.Forms.Label();
            this.txtDtCriacao = new System.Windows.Forms.TextBox();
            this.lblDtCriacao = new System.Windows.Forms.Label();
            this.txtDtUltMod = new System.Windows.Forms.TextBox();
            this.lblDtUltMod = new System.Windows.Forms.Label();
            this.txtUltAltFunc = new System.Windows.Forms.TextBox();
            this.lblUltAltFunc = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtCodCidade = new System.Windows.Forms.TextBox();
            this.lblCodCidade = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(6, 13);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(4, 33);
            // 
            // cmbFisJur
            // 
            this.cmbFisJur.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbFisJur.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFisJur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFisJur.FormattingEnabled = true;
            this.cmbFisJur.Items.AddRange(new object[] {
            "PESSOA FÍSICA",
            "PESSOA JÚRIDICA"});
            this.cmbFisJur.Location = new System.Drawing.Point(9, 88);
            this.cmbFisJur.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbFisJur.Name = "cmbFisJur";
            this.cmbFisJur.Size = new System.Drawing.Size(197, 33);
            this.cmbFisJur.TabIndex = 4;
            this.cmbFisJur.SelectedIndexChanged += new System.EventHandler(this.cmbFisJur_SelectedIndexChanged);
            // 
            // txtNome
            // 
            this.txtNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(213, 89);
            this.txtNome.MaxLength = 50;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(502, 32);
            this.txtNome.TabIndex = 552;
            this.txtNome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtNome_KeyDown);
            //this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // lblTipo
            // 
            this.lblTipo.AutoSize = true;
            this.lblTipo.Location = new System.Drawing.Point(8, 67);
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(41, 18);
            this.lblTipo.TabIndex = 553;
            this.lblTipo.Text = "Tipo";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(210, 67);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(50, 18);
            this.lblNome.TabIndex = 554;
            this.lblNome.Text = "Nome";
            // 
            // txtApelido
            // 
            this.txtApelido.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApelido.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApelido.Location = new System.Drawing.Point(721, 89);
            this.txtApelido.MaxLength = 50;
            this.txtApelido.Name = "txtApelido";
            this.txtApelido.Size = new System.Drawing.Size(203, 32);
            this.txtApelido.TabIndex = 555;
            //this.txtApelido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtApelido_KeyPress);
            // 
            // lblApelido
            // 
            this.lblApelido.AutoSize = true;
            this.lblApelido.Location = new System.Drawing.Point(718, 67);
            this.lblApelido.Name = "lblApelido";
            this.lblApelido.Size = new System.Drawing.Size(65, 18);
            this.lblApelido.TabIndex = 556;
            this.lblApelido.Text = "Apelido";
            this.lblApelido.Click += new System.EventHandler(this.lblApelido_Click);
            // 
            // cmbSexo
            // 
            this.cmbSexo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbSexo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSexo.FormattingEnabled = true;
            this.cmbSexo.Items.AddRange(new object[] {
            "Masculino",
            "Feminino"});
            this.cmbSexo.Location = new System.Drawing.Point(931, 88);
            this.cmbSexo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbSexo.Name = "cmbSexo";
            this.cmbSexo.Size = new System.Drawing.Size(235, 33);
            this.cmbSexo.TabIndex = 557;
            // 
            // lblSexo
            // 
            this.lblSexo.AutoSize = true;
            this.lblSexo.Location = new System.Drawing.Point(928, 67);
            this.lblSexo.Name = "lblSexo";
            this.lblSexo.Size = new System.Drawing.Size(43, 18);
            this.lblSexo.TabIndex = 558;
            this.lblSexo.Text = "Sexo";
            // 
            // txtLogradouro
            // 
            this.txtLogradouro.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtLogradouro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLogradouro.Location = new System.Drawing.Point(11, 145);
            this.txtLogradouro.MaxLength = 75;
            this.txtLogradouro.Name = "txtLogradouro";
            this.txtLogradouro.Size = new System.Drawing.Size(502, 32);
            this.txtLogradouro.TabIndex = 559;
            this.txtLogradouro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLogradouro_KeyPress);
            // 
            // lblLogradouro
            // 
            this.lblLogradouro.AutoSize = true;
            this.lblLogradouro.Location = new System.Drawing.Point(8, 124);
            this.lblLogradouro.Name = "lblLogradouro";
            this.lblLogradouro.Size = new System.Drawing.Size(92, 18);
            this.lblLogradouro.TabIndex = 560;
            this.lblLogradouro.Text = "Logradouro";
            // 
            // txtNum
            // 
            this.txtNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum.Location = new System.Drawing.Point(519, 145);
            this.txtNum.MaxLength = 5;
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(121, 32);
            this.txtNum.TabIndex = 561;
            this.txtNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNum_KeyPress);
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Location = new System.Drawing.Point(516, 124);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(65, 18);
            this.lblNum.TabIndex = 562;
            this.lblNum.Text = "Número";
            // 
            // txtComplemento
            // 
            this.txtComplemento.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtComplemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComplemento.Location = new System.Drawing.Point(646, 145);
            this.txtComplemento.MaxLength = 50;
            this.txtComplemento.Name = "txtComplemento";
            this.txtComplemento.Size = new System.Drawing.Size(245, 32);
            this.txtComplemento.TabIndex = 563;
            this.txtComplemento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtComplemento_KeyPress);
            // 
            // lblComplemento
            // 
            this.lblComplemento.AutoSize = true;
            this.lblComplemento.Location = new System.Drawing.Point(643, 124);
            this.lblComplemento.Name = "lblComplemento";
            this.lblComplemento.Size = new System.Drawing.Size(107, 18);
            this.lblComplemento.TabIndex = 564;
            this.lblComplemento.Text = "Complemento";
            // 
            // txtBairro
            // 
            this.txtBairro.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBairro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBairro.Location = new System.Drawing.Point(897, 145);
            this.txtBairro.MaxLength = 50;
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(269, 32);
            this.txtBairro.TabIndex = 565;
            this.txtBairro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBairro_KeyPress);
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.Location = new System.Drawing.Point(894, 123);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(53, 18);
            this.lblBairro.TabIndex = 566;
            this.lblBairro.Text = "Bairro";
            // 
            // txtCidade
            // 
            this.txtCidade.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCidade.Enabled = false;
            this.txtCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCidade.Location = new System.Drawing.Point(135, 199);
            this.txtCidade.MaxLength = 75;
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.ReadOnly = true;
            this.txtCidade.Size = new System.Drawing.Size(382, 32);
            this.txtCidade.TabIndex = 567;
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.Location = new System.Drawing.Point(132, 180);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(58, 18);
            this.lblCidade.TabIndex = 568;
            this.lblCidade.Text = "Cidade";
            // 
            // txtCEP
            // 
            this.txtCEP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCEP.Location = new System.Drawing.Point(646, 199);
            this.txtCEP.MaxLength = 8;
            this.txtCEP.Name = "txtCEP";
            this.txtCEP.Size = new System.Drawing.Size(399, 32);
            this.txtCEP.TabIndex = 569;
            this.txtCEP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCEP_KeyPress);
            // 
            // lblCEP
            // 
            this.lblCEP.AutoSize = true;
            this.lblCEP.Location = new System.Drawing.Point(643, 178);
            this.lblCEP.Name = "lblCEP";
            this.lblCEP.Size = new System.Drawing.Size(38, 18);
            this.lblCEP.TabIndex = 570;
            this.lblCEP.Text = "CEP";
            // 
            // btnBuscaCep
            // 
            this.btnBuscaCep.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscaCep.BackColor = System.Drawing.Color.Gold;
            this.btnBuscaCep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscaCep.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscaCep.ForeColor = System.Drawing.Color.Black;
            this.btnBuscaCep.Location = new System.Drawing.Point(1053, 202);
            this.btnBuscaCep.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscaCep.Name = "btnBuscaCep";
            this.btnBuscaCep.Size = new System.Drawing.Size(113, 27);
            this.btnBuscaCep.TabIndex = 571;
            this.btnBuscaCep.Text = "BUSCAR";
            this.btnBuscaCep.UseVisualStyleBackColor = false;
            this.btnBuscaCep.Click += new System.EventHandler(this.btnBuscaCep_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(11, 254);
            this.txtEmail.MaxLength = 75;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(653, 32);
            this.txtEmail.TabIndex = 572;
            this.txtEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEmail_KeyPress);
            this.txtEmail.Leave += new System.EventHandler(this.txtEmail_Leave);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(8, 234);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 573;
            this.lblEmail.Text = "Email";
            // 
            // txtTelefone
            // 
            this.txtTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTelefone.Location = new System.Drawing.Point(670, 254);
            this.txtTelefone.MaxLength = 13;
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(245, 32);
            this.txtTelefone.TabIndex = 574;
            this.txtTelefone.TextChanged += new System.EventHandler(this.txtTelefone_TextChanged);
            this.txtTelefone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTelefone_KeyPress);
            this.txtTelefone.Leave += new System.EventHandler(this.txtTelefone_Leave);
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.Location = new System.Drawing.Point(667, 234);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(71, 18);
            this.lblTelefone.TabIndex = 575;
            this.lblTelefone.Text = "Telefone";
            // 
            // txtCelular
            // 
            this.txtCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCelular.Location = new System.Drawing.Point(921, 254);
            this.txtCelular.MaxLength = 13;
            this.txtCelular.Name = "txtCelular";
            this.txtCelular.Size = new System.Drawing.Size(245, 32);
            this.txtCelular.TabIndex = 576;
            this.txtCelular.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCelular_KeyPress);
            this.txtCelular.Leave += new System.EventHandler(this.txtCelular_Leave);
            // 
            // lblCelular
            // 
            this.lblCelular.AutoSize = true;
            this.lblCelular.Location = new System.Drawing.Point(918, 233);
            this.lblCelular.Name = "lblCelular";
            this.lblCelular.Size = new System.Drawing.Size(60, 18);
            this.lblCelular.TabIndex = 577;
            this.lblCelular.Text = "Celular";
            // 
            // txtRG
            // 
            this.txtRG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRG.Location = new System.Drawing.Point(11, 310);
            this.txtRG.MaxLength = 9;
            this.txtRG.Name = "txtRG";
            this.txtRG.Size = new System.Drawing.Size(245, 32);
            this.txtRG.TabIndex = 578;
            this.txtRG.TextChanged += new System.EventHandler(this.txtRG_TextChanged);
            this.txtRG.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRG_KeyPress);
            this.txtRG.Leave += new System.EventHandler(this.txtRG_Leave);
            // 
            // lblRG
            // 
            this.lblRG.AutoSize = true;
            this.lblRG.Location = new System.Drawing.Point(8, 289);
            this.lblRG.Name = "lblRG";
            this.lblRG.Size = new System.Drawing.Size(31, 18);
            this.lblRG.TabIndex = 579;
            this.lblRG.Text = "RG";
            // 
            // txtCPFouCNPJ
            // 
            this.txtCPFouCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCPFouCNPJ.Location = new System.Drawing.Point(262, 310);
            this.txtCPFouCNPJ.MaxLength = 11;
            this.txtCPFouCNPJ.Name = "txtCPFouCNPJ";
            this.txtCPFouCNPJ.Size = new System.Drawing.Size(245, 32);
            this.txtCPFouCNPJ.TabIndex = 580;
            this.txtCPFouCNPJ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCPFouCNPJ_KeyPress);
            // 
            // lblCPFouCNPJ
            // 
            this.lblCPFouCNPJ.AutoSize = true;
            this.lblCPFouCNPJ.Location = new System.Drawing.Point(262, 289);
            this.lblCPFouCNPJ.Name = "lblCPFouCNPJ";
            this.lblCPFouCNPJ.Size = new System.Drawing.Size(89, 18);
            this.lblCPFouCNPJ.TabIndex = 581;
            this.lblCPFouCNPJ.Text = "CPF / CNPJ";
            // 
            // dtNascimento
            // 
            this.dtNascimento.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtNascimento.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dtNascimento.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtNascimento.Location = new System.Drawing.Point(519, 310);
            this.dtNascimento.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtNascimento.Name = "dtNascimento";
            this.dtNascimento.Size = new System.Drawing.Size(647, 32);
            this.dtNascimento.TabIndex = 582;
            // 
            // lblNasc
            // 
            this.lblNasc.AutoSize = true;
            this.lblNasc.Location = new System.Drawing.Point(516, 289);
            this.lblNasc.Name = "lblNasc";
            this.lblNasc.Size = new System.Drawing.Size(160, 18);
            this.lblNasc.TabIndex = 583;
            this.lblNasc.Text = "Nascimento / Criação";
            // 
            // txtCodCargo
            // 
            this.txtCodCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCargo.Location = new System.Drawing.Point(11, 368);
            this.txtCodCargo.Margin = new System.Windows.Forms.Padding(5);
            this.txtCodCargo.MaxLength = 5;
            this.txtCodCargo.Name = "txtCodCargo";
            this.txtCodCargo.Size = new System.Drawing.Size(140, 32);
            this.txtCodCargo.TabIndex = 584;
            this.txtCodCargo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodCargo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCargo_KeyPress);
            // 
            // lblCodCargo
            // 
            this.lblCodCargo.AutoSize = true;
            this.lblCodCargo.Location = new System.Drawing.Point(8, 345);
            this.lblCodCargo.Name = "lblCodCargo";
            this.lblCodCargo.Size = new System.Drawing.Size(107, 18);
            this.lblCodCargo.TabIndex = 585;
            this.lblCodCargo.Text = "Código Cargo";
            // 
            // btnBuscaCid
            // 
            this.btnBuscaCid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscaCid.BackColor = System.Drawing.Color.Gold;
            this.btnBuscaCid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscaCid.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscaCid.ForeColor = System.Drawing.Color.Black;
            this.btnBuscaCid.Location = new System.Drawing.Point(525, 202);
            this.btnBuscaCid.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscaCid.Name = "btnBuscaCid";
            this.btnBuscaCid.Size = new System.Drawing.Size(113, 27);
            this.btnBuscaCid.TabIndex = 586;
            this.btnBuscaCid.Text = "BUSCAR";
            this.btnBuscaCid.UseVisualStyleBackColor = false;
            this.btnBuscaCid.Click += new System.EventHandler(this.btnBuscaCid_Click);
            // 
            // txtCargo
            // 
            this.txtCargo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCargo.Location = new System.Drawing.Point(161, 368);
            this.txtCargo.Margin = new System.Windows.Forms.Padding(5);
            this.txtCargo.MaxLength = 100;
            this.txtCargo.Name = "txtCargo";
            this.txtCargo.ReadOnly = true;
            this.txtCargo.Size = new System.Drawing.Size(356, 32);
            this.txtCargo.TabIndex = 587;
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(158, 345);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(51, 18);
            this.lblCargo.TabIndex = 588;
            this.lblCargo.Text = "Cargo";
            // 
            // btnBuscarCargo
            // 
            this.btnBuscarCargo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarCargo.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarCargo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarCargo.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCargo.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarCargo.Location = new System.Drawing.Point(525, 370);
            this.btnBuscarCargo.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscarCargo.Name = "btnBuscarCargo";
            this.btnBuscarCargo.Size = new System.Drawing.Size(113, 27);
            this.btnBuscarCargo.TabIndex = 589;
            this.btnBuscarCargo.Text = "BUSCAR";
            this.btnBuscarCargo.UseVisualStyleBackColor = false;
            this.btnBuscarCargo.Click += new System.EventHandler(this.btnBuscarCargo_Click);
            // 
            // txtSalario
            // 
            this.txtSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalario.Location = new System.Drawing.Point(646, 368);
            this.txtSalario.MaxLength = 15;
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(520, 32);
            this.txtSalario.TabIndex = 590;
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(643, 345);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(58, 18);
            this.lblSalario.TabIndex = 591;
            this.lblSalario.Text = "Salario";
            // 
            // txtDtCriacao
            // 
            this.txtDtCriacao.Enabled = false;
            this.txtDtCriacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDtCriacao.Location = new System.Drawing.Point(11, 511);
            this.txtDtCriacao.Margin = new System.Windows.Forms.Padding(5);
            this.txtDtCriacao.MaxLength = 6;
            this.txtDtCriacao.Name = "txtDtCriacao";
            this.txtDtCriacao.Size = new System.Drawing.Size(140, 32);
            this.txtDtCriacao.TabIndex = 592;
            this.txtDtCriacao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDtCriacao.TextChanged += new System.EventHandler(this.txtDtCriacao_TextChanged);
            // 
            // lblDtCriacao
            // 
            this.lblDtCriacao.AutoSize = true;
            this.lblDtCriacao.Location = new System.Drawing.Point(8, 488);
            this.lblDtCriacao.Name = "lblDtCriacao";
            this.lblDtCriacao.Size = new System.Drawing.Size(121, 18);
            this.lblDtCriacao.TabIndex = 593;
            this.lblDtCriacao.Text = "Data de Criação";
            // 
            // txtDtUltMod
            // 
            this.txtDtUltMod.Enabled = false;
            this.txtDtUltMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDtUltMod.Location = new System.Drawing.Point(161, 511);
            this.txtDtUltMod.Margin = new System.Windows.Forms.Padding(5);
            this.txtDtUltMod.MaxLength = 6;
            this.txtDtUltMod.Name = "txtDtUltMod";
            this.txtDtUltMod.Size = new System.Drawing.Size(140, 32);
            this.txtDtUltMod.TabIndex = 594;
            this.txtDtUltMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblDtUltMod
            // 
            this.lblDtUltMod.AutoSize = true;
            this.lblDtUltMod.Location = new System.Drawing.Point(159, 488);
            this.lblDtUltMod.Name = "lblDtUltMod";
            this.lblDtUltMod.Size = new System.Drawing.Size(135, 18);
            this.lblDtUltMod.TabIndex = 595;
            this.lblDtUltMod.Text = "Data Modificação";
            // 
            // txtUltAltFunc
            // 
            this.txtUltAltFunc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtUltAltFunc.Enabled = false;
            this.txtUltAltFunc.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUltAltFunc.Location = new System.Drawing.Point(309, 511);
            this.txtUltAltFunc.MaxLength = 75;
            this.txtUltAltFunc.Name = "txtUltAltFunc";
            this.txtUltAltFunc.Size = new System.Drawing.Size(502, 32);
            this.txtUltAltFunc.TabIndex = 596;
            // 
            // lblUltAltFunc
            // 
            this.lblUltAltFunc.AutoSize = true;
            this.lblUltAltFunc.Location = new System.Drawing.Point(306, 490);
            this.lblUltAltFunc.Name = "lblUltAltFunc";
            this.lblUltAltFunc.Size = new System.Drawing.Size(129, 18);
            this.lblUltAltFunc.TabIndex = 597;
            this.lblUltAltFunc.Text = "Última Alteração";
            // 
            // cmbStatus
            // 
            this.cmbStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbStatus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "ATIVO",
            "INATIVO"});
            this.cmbStatus.Location = new System.Drawing.Point(1059, 37);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(107, 33);
            this.cmbStatus.TabIndex = 598;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(1056, 21);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(51, 18);
            this.lblStatus.TabIndex = 599;
            this.lblStatus.Text = "Status";
            this.lblStatus.Click += new System.EventHandler(this.lblStatus_Click);
            // 
            // txtCodCidade
            // 
            this.txtCodCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCidade.Location = new System.Drawing.Point(11, 199);
            this.txtCodCidade.MaxLength = 5;
            this.txtCodCidade.Name = "txtCodCidade";
            this.txtCodCidade.Size = new System.Drawing.Size(115, 32);
            this.txtCodCidade.TabIndex = 600;
            this.txtCodCidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCidade_KeyPress);
            // 
            // lblCodCidade
            // 
            this.lblCodCidade.AutoSize = true;
            this.lblCodCidade.Location = new System.Drawing.Point(8, 180);
            this.lblCodCidade.Name = "lblCodCidade";
            this.lblCodCidade.Size = new System.Drawing.Size(91, 18);
            this.lblCodCidade.TabIndex = 601;
            this.lblCodCidade.Text = "Cod Cidade";
            // 
            // FrmCadastroPessoa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(1201, 554);
            this.Controls.Add(this.lblCodCidade);
            this.Controls.Add(this.txtCodCidade);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.lblUltAltFunc);
            this.Controls.Add(this.txtUltAltFunc);
            this.Controls.Add(this.lblDtUltMod);
            this.Controls.Add(this.txtDtUltMod);
            this.Controls.Add(this.lblDtCriacao);
            this.Controls.Add(this.txtDtCriacao);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.btnBuscarCargo);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txtCargo);
            this.Controls.Add(this.btnBuscaCid);
            this.Controls.Add(this.lblCodCargo);
            this.Controls.Add(this.txtCodCargo);
            this.Controls.Add(this.lblNasc);
            this.Controls.Add(this.dtNascimento);
            this.Controls.Add(this.lblCPFouCNPJ);
            this.Controls.Add(this.txtCPFouCNPJ);
            this.Controls.Add(this.lblRG);
            this.Controls.Add(this.txtRG);
            this.Controls.Add(this.lblCelular);
            this.Controls.Add(this.txtCelular);
            this.Controls.Add(this.lblTelefone);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.btnBuscaCep);
            this.Controls.Add(this.lblCEP);
            this.Controls.Add(this.txtCEP);
            this.Controls.Add(this.lblCidade);
            this.Controls.Add(this.txtCidade);
            this.Controls.Add(this.lblBairro);
            this.Controls.Add(this.txtBairro);
            this.Controls.Add(this.lblComplemento);
            this.Controls.Add(this.txtComplemento);
            this.Controls.Add(this.lblNum);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.lblLogradouro);
            this.Controls.Add(this.txtLogradouro);
            this.Controls.Add(this.lblSexo);
            this.Controls.Add(this.cmbSexo);
            this.Controls.Add(this.lblApelido);
            this.Controls.Add(this.txtApelido);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblTipo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.cmbFisJur);
            this.Name = "FrmCadastroPessoa";
            this.Text = "Frm Cadastro Pessoa";
            this.Load += new System.EventHandler(this.FrmCadastroPessoa_Load);
            this.Controls.SetChildIndex(this.cmbFisJur, 0);
            this.Controls.SetChildIndex(this.txtNome, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.lblTipo, 0);
            this.Controls.SetChildIndex(this.lblNome, 0);
            this.Controls.SetChildIndex(this.txtApelido, 0);
            this.Controls.SetChildIndex(this.lblApelido, 0);
            this.Controls.SetChildIndex(this.cmbSexo, 0);
            this.Controls.SetChildIndex(this.lblSexo, 0);
            this.Controls.SetChildIndex(this.txtLogradouro, 0);
            this.Controls.SetChildIndex(this.lblLogradouro, 0);
            this.Controls.SetChildIndex(this.txtNum, 0);
            this.Controls.SetChildIndex(this.lblNum, 0);
            this.Controls.SetChildIndex(this.txtComplemento, 0);
            this.Controls.SetChildIndex(this.lblComplemento, 0);
            this.Controls.SetChildIndex(this.txtBairro, 0);
            this.Controls.SetChildIndex(this.lblBairro, 0);
            this.Controls.SetChildIndex(this.txtCidade, 0);
            this.Controls.SetChildIndex(this.lblCidade, 0);
            this.Controls.SetChildIndex(this.txtCEP, 0);
            this.Controls.SetChildIndex(this.lblCEP, 0);
            this.Controls.SetChildIndex(this.btnBuscaCep, 0);
            this.Controls.SetChildIndex(this.txtEmail, 0);
            this.Controls.SetChildIndex(this.lblEmail, 0);
            this.Controls.SetChildIndex(this.txtTelefone, 0);
            this.Controls.SetChildIndex(this.lblTelefone, 0);
            this.Controls.SetChildIndex(this.txtCelular, 0);
            this.Controls.SetChildIndex(this.lblCelular, 0);
            this.Controls.SetChildIndex(this.txtRG, 0);
            this.Controls.SetChildIndex(this.lblRG, 0);
            this.Controls.SetChildIndex(this.txtCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.lblCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.dtNascimento, 0);
            this.Controls.SetChildIndex(this.lblNasc, 0);
            this.Controls.SetChildIndex(this.txtCodCargo, 0);
            this.Controls.SetChildIndex(this.lblCodCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscaCid, 0);
            this.Controls.SetChildIndex(this.txtCargo, 0);
            this.Controls.SetChildIndex(this.lblCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscarCargo, 0);
            this.Controls.SetChildIndex(this.txtSalario, 0);
            this.Controls.SetChildIndex(this.lblSalario, 0);
            this.Controls.SetChildIndex(this.txtDtCriacao, 0);
            this.Controls.SetChildIndex(this.lblDtCriacao, 0);
            this.Controls.SetChildIndex(this.txtDtUltMod, 0);
            this.Controls.SetChildIndex(this.lblDtUltMod, 0);
            this.Controls.SetChildIndex(this.txtUltAltFunc, 0);
            this.Controls.SetChildIndex(this.lblUltAltFunc, 0);
            this.Controls.SetChildIndex(this.cmbStatus, 0);
            this.Controls.SetChildIndex(this.lblStatus, 0);
            this.Controls.SetChildIndex(this.txtCodCidade, 0);
            this.Controls.SetChildIndex(this.lblCodCidade, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected System.Windows.Forms.ComboBox cmbSexo;
        protected System.Windows.Forms.Button btnBuscaCep;
        protected System.Windows.Forms.DateTimePicker dtNascimento;
        protected System.Windows.Forms.Button btnBuscaCid;
        protected System.Windows.Forms.Button btnBuscarCargo;
        public System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label lblStatus;
        protected System.Windows.Forms.TextBox txtNome;
        protected System.Windows.Forms.Label lblTipo;
        protected System.Windows.Forms.Label lblNome;
        protected System.Windows.Forms.TextBox txtApelido;
        protected System.Windows.Forms.Label lblApelido;
        protected System.Windows.Forms.Label lblSexo;
        protected System.Windows.Forms.TextBox txtLogradouro;
        protected System.Windows.Forms.Label lblLogradouro;
        protected System.Windows.Forms.TextBox txtNum;
        protected System.Windows.Forms.Label lblNum;
        protected System.Windows.Forms.TextBox txtComplemento;
        protected System.Windows.Forms.Label lblComplemento;
        protected System.Windows.Forms.TextBox txtBairro;
        protected System.Windows.Forms.Label lblBairro;
        protected System.Windows.Forms.TextBox txtCidade;
        protected System.Windows.Forms.Label lblCidade;
        protected System.Windows.Forms.TextBox txtCEP;
        protected System.Windows.Forms.Label lblCEP;
        protected System.Windows.Forms.TextBox txtEmail;
        protected System.Windows.Forms.Label lblEmail;
        protected System.Windows.Forms.TextBox txtTelefone;
        protected System.Windows.Forms.Label lblTelefone;
        protected System.Windows.Forms.TextBox txtCelular;
        protected System.Windows.Forms.Label lblCelular;
        protected System.Windows.Forms.TextBox txtRG;
        protected System.Windows.Forms.Label lblRG;
        protected System.Windows.Forms.TextBox txtCPFouCNPJ;
        protected System.Windows.Forms.Label lblCPFouCNPJ;
        protected System.Windows.Forms.Label lblNasc;
        protected System.Windows.Forms.TextBox txtCodCargo;
        protected System.Windows.Forms.Label lblCodCargo;
        protected System.Windows.Forms.TextBox txtCargo;
        protected System.Windows.Forms.Label lblCargo;
        protected System.Windows.Forms.TextBox txtSalario;
        protected System.Windows.Forms.Label lblSalario;
        public System.Windows.Forms.ComboBox cmbFisJur;
        protected System.Windows.Forms.TextBox txtCodCidade;
        protected System.Windows.Forms.Label lblCodCidade;
        protected System.Windows.Forms.TextBox txtUltAltFunc;
        protected System.Windows.Forms.Label lblUltAltFunc;
        public System.Windows.Forms.TextBox txtDtCriacao;
        public System.Windows.Forms.TextBox txtDtUltMod;
        public System.Windows.Forms.Label lblDtCriacao;
        public System.Windows.Forms.Label lblDtUltMod;
    }
}
