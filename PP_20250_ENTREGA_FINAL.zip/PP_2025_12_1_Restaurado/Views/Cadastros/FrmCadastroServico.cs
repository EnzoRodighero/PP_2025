﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace PP_2025
{
    public partial class FrmCadastroServico : FrmCadastros
    {
        Servico oServico = new Servico();
        CTLServicos aCTLServicos;

        public FrmCadastroServico()
        {
            InitializeComponent();
            aCTLServicos = new CTLServicos();
            Operacao.DisableCopyPaste(this);
        }
        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Servico servico)
            {
                oServico = servico;
                CarregarCampos();
            }
        }

        protected override void LimparCampos()
        {
            txtCodigo.Clear();
            txtDescricao.Clear();
            cmbStatus.SelectedIndex = 0;
            txtValor.Clear();
        }

        public override void BloquearCampos()
        {
            base.BloquearCampos();
            txtDescricao.Enabled = false;
            cmbStatus.Enabled = false;
            txtValor.Enabled = false;
        }

        public override void DesbloquearCampos()
        {
            base.DesbloquearCampos();
            txtDescricao.Enabled = true;
            cmbStatus.Enabled = true;
            txtValor.Enabled = true;
        }

        public override void CarregarCampos()
        {
            base.CarregarCampos();
            txtCodigo.Text = oServico.ID.ToString();
            txtDescricao.Text = oServico.Descricao;
            cmbStatus.Text = oServico.Status == "I" ? "Inativo" : oServico.Status == "A" ? "Ativo" : oServico.Status;
            txtValor.Text = oServico.Valor.ToString();
        }

        public override void Verificar()
        {
            if (btnSalvar.Text == "SALVAR" || btnSalvar.Text == "ALTERAR")
                Salvar();
            else if (btnSalvar.Text == "EXCLUIR")
            {
                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este serviço?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    ExcluirServico();
                }
            }
        }

        private void ExcluirServico()
        {
            if (oServico != null)
            {
                try
                {
                    var result = aCTLServicos.ExcluirServico(oServico.ID);
                    if (result)
                        Close();
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir o serviço. Detalhes: " + result);
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547)
                    {
                        MessageBox.Show("Não é possível excluir o serviço devido a outros registros estarem vinculados a este serviço.");
                    }
                    else
                    {
                        MessageBox.Show("Ocorreu um erro ao excluir o serviço. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }

        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txtDescricao.Text))
            {
                camposFaltantes.Add("Descrição");
            }
            if (string.IsNullOrWhiteSpace(cmbStatus.Text))
            {
                camposFaltantes.Add("Status");
            }
            // Verificação de txtPrecoVenda
            if (string.IsNullOrWhiteSpace(txtValor.Text))
                camposFaltantes.Add("Valor");
            else
            {
                if (!decimal.TryParse(txtValor.Text, out decimal valor) || valor <= 0)
                    camposFaltantes.Add("Valor (deve ser um número maior que zero)");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        protected override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                CultureInfo cultura = CultureInfo.InvariantCulture; // Usar a cultura atual do sistema
                oServico.Descricao = txtDescricao.Text;
                oServico.Status = cmbStatus.Text[0].ToString();
                oServico.Valor = decimal.Parse(txtValor.Text, cultura);

                if (oServico.ID == 0)
                {
                    oServico.DataCriacao = DateTime.Now;
                    var result = aCTLServicos.AdicionarServico(oServico);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    oServico.DataUltimaAlteracao = DateTime.Now;
                    var result = aCTLServicos.AtualizarServico(oServico);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }

                return;
            }
        }

        private void txtValor_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite apenas números, um ponto decimal e teclas de controle (como Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // Permite apenas um ponto decimal
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

            // Bloqueia qualquer modificação com Ctrl
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }

        private void FrmCadastroServico_Load(object sender, EventArgs e)
        {

        }
    }
}