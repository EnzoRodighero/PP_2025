﻿namespace PP_2025
{
    partial class FrmCadastroUnidadeMedida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblNomeUnidadeMedida = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(233, 130);
            // 
            // panel3
            // 
            this.panel3.Size = new System.Drawing.Size(477, 10);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(354, 130);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(11, 97);
            this.txtNome.MaxLength = 10;
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(431, 26);
            this.txtNome.TabIndex = 552;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress_1);
            // 
            // lblNomeUnidadeMedida
            // 
            this.lblNomeUnidadeMedida.AutoSize = true;
            this.lblNomeUnidadeMedida.Location = new System.Drawing.Point(11, 76);
            this.lblNomeUnidadeMedida.Name = "lblNomeUnidadeMedida";
            this.lblNomeUnidadeMedida.Size = new System.Drawing.Size(193, 18);
            this.lblNomeUnidadeMedida.TabIndex = 553;
            this.lblNomeUnidadeMedida.Text = "Nome Unidade de Medida";
            this.lblNomeUnidadeMedida.Click += new System.EventHandler(this.label1_Click);
            // 
            // FrmCadastroUnidadeMedida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(477, 211);
            this.Controls.Add(this.lblNomeUnidadeMedida);
            this.Controls.Add(this.txtNome);
            this.Name = "FrmCadastroUnidadeMedida";
            this.Load += new System.EventHandler(this.FrmCadastroUnidadeMedida_Load);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.txtNome, 0);
            this.Controls.SetChildIndex(this.lblNomeUnidadeMedida, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblNomeUnidadeMedida;
    }
}
