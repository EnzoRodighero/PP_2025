﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PP_2025;

namespace PP_2025
{
    public partial class FrmCadastroUnidadeMedida : FrmCadastros
    {
        UnidadeMedida oUnidadeMedida;
        CtlUnidadeMedida ctlUnidadeMedida;

        public FrmCadastroUnidadeMedida()
        {
            InitializeComponent();
            ctlUnidadeMedida = new CtlUnidadeMedida();
            oUnidadeMedida = new UnidadeMedida();
            Operacao.DisableCopyPaste(this);
        }

        private void FrmCadastroUnidadeMedida_Load(object sender, EventArgs e)
        {

        }

        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is UnidadeMedida unidade)
            {
                oUnidadeMedida = unidade;
                CarregarCampos();
            }
        }

        protected override void LimparCampos()
        {
            txtCodigo.Clear();
            txtNome.Clear();
        }

        public override void BloquearCampos()
        {
            base.BloquearCampos();
            txtNome.Enabled = false;
        }

        public override void DesbloquearCampos()
        {
            base.DesbloquearCampos();
            txtNome.Enabled = true;
        }

        public override void CarregarCampos()
        {
            base.CarregarCampos();
            txtCodigo.Text = oUnidadeMedida.ID.ToString();
            txtNome.Text = oUnidadeMedida.UnidadeMedidaNome;
        }

        public override void Verificar()
        {
            if (btnSalvar.Text == "SALVAR" || btnSalvar.Text == "ALTERAR")
                Salvar();
            else if (btnSalvar.Text == "EXCLUIR")
            {
                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir esta unidade de medida?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    ExcluirUnidadeMedida();
                }
            }
        }

        private void ExcluirUnidadeMedida()
        {
            if (oUnidadeMedida != null)
            {
                try
                {
                    var result = ctlUnidadeMedida.ExcluirUnidadeMedida(oUnidadeMedida.ID);
                    if (result)
                        Close();
                    else
                        MessageBox.Show("Ocorreu um erro ao excluir a unidade de medida.");
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547)
                        MessageBox.Show("Não é possível excluir devido a outros registros vinculados.");
                    else
                        MessageBox.Show("Erro ao excluir: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro inesperado: " + ex.Message);
                }
            }
        }

        private bool VerificarCamposVazios()
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("O campo Nome é obrigatório.", "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        protected override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                oUnidadeMedida.UnidadeMedidaNome = txtNome.Text;
                if (oUnidadeMedida.ID == 0)
                {
                    oUnidadeMedida.DataCriacao = DateTime.Now;
                    var result = ctlUnidadeMedida.AdicionarUnidadeMedida(oUnidadeMedida);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    oUnidadeMedida.DataUltimaAlteracao = DateTime.Now;
                    var result = ctlUnidadeMedida.AtualizarUnidadeMedida(oUnidadeMedida);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);
        }
    }
}
