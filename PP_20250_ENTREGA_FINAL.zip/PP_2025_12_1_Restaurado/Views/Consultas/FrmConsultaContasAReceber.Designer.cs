﻿namespace PP_2025
{
    partial class FrmConsultaContasAReceber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtParcela = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.btnBuscarCliente = new System.Windows.Forms.Button();
            this.txtModelo = new System.Windows.Forms.NumericUpDown();
            this.txtSerie = new System.Windows.Forms.NumericUpDown();
            this.txtNumero = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbM = new System.Windows.Forms.Label();
            this.btnBuscarTodos = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.pbFoto = new System.Windows.Forms.PictureBox();
            this.dgvContas = new System.Windows.Forms.DataGridView();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbDatas = new System.Windows.Forms.ComboBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.dtData2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtData1 = new System.Windows.Forms.DateTimePicker();
            this.btnAlterarConta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.txtParcela)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModelo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContas)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(17, 66);
            this.lblCodigo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCodigo.Size = new System.Drawing.Size(59, 18);
            this.lblCodigo.Text = "Cliente";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(1157, 695);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtCodigo.Size = new System.Drawing.Size(256, 26);
            this.txtCodigo.Text = "";
            this.txtCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCodigo.Visible = false;
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(1761, 695);
            this.btnSair.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            // 
            // txtParcela
            // 
            this.txtParcela.BackColor = System.Drawing.Color.White;
            this.txtParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParcela.Location = new System.Drawing.Point(314, 27);
            this.txtParcela.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtParcela.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtParcela.Name = "txtParcela";
            this.txtParcela.Size = new System.Drawing.Size(95, 32);
            this.txtParcela.TabIndex = 608;
            this.txtParcela.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(310, 9);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 18);
            this.label7.TabIndex = 615;
            this.label7.Text = "Nº Parcela";
            // 
            // btnBuscarCliente
            // 
            this.btnBuscarCliente.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarCliente.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCliente.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarCliente.Location = new System.Drawing.Point(417, 27);
            this.btnBuscarCliente.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnBuscarCliente.Name = "btnBuscarCliente";
            this.btnBuscarCliente.Size = new System.Drawing.Size(113, 31);
            this.btnBuscarCliente.TabIndex = 610;
            this.btnBuscarCliente.Text = "BUSCAR";
            this.btnBuscarCliente.UseVisualStyleBackColor = false;
            this.btnBuscarCliente.Click += new System.EventHandler(this.btnBuscarCliente_Click);
            // 
            // txtModelo
            // 
            this.txtModelo.BackColor = System.Drawing.Color.White;
            this.txtModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModelo.Location = new System.Drawing.Point(113, 27);
            this.txtModelo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtModelo.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(95, 32);
            this.txtModelo.TabIndex = 606;
            this.txtModelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSerie
            // 
            this.txtSerie.BackColor = System.Drawing.Color.White;
            this.txtSerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerie.Location = new System.Drawing.Point(213, 27);
            this.txtSerie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSerie.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtSerie.Name = "txtSerie";
            this.txtSerie.Size = new System.Drawing.Size(95, 32);
            this.txtSerie.TabIndex = 607;
            this.txtSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumero
            // 
            this.txtNumero.BackColor = System.Drawing.Color.White;
            this.txtNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumero.Location = new System.Drawing.Point(14, 27);
            this.txtNumero.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumero.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(95, 32);
            this.txtNumero.TabIndex = 605;
            this.txtNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(10, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 18);
            this.label4.TabIndex = 613;
            this.label4.Text = "Número";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(111, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 18);
            this.label6.TabIndex = 612;
            this.label6.Text = "Modelo";
            // 
            // lbM
            // 
            this.lbM.AutoSize = true;
            this.lbM.ForeColor = System.Drawing.Color.Black;
            this.lbM.Location = new System.Drawing.Point(211, 9);
            this.lbM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbM.Name = "lbM";
            this.lbM.Size = new System.Drawing.Size(44, 18);
            this.lbM.TabIndex = 611;
            this.lbM.Text = "Série";
            // 
            // btnBuscarTodos
            // 
            this.btnBuscarTodos.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarTodos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarTodos.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTodos.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarTodos.Location = new System.Drawing.Point(636, 85);
            this.btnBuscarTodos.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnBuscarTodos.Name = "btnBuscarTodos";
            this.btnBuscarTodos.Size = new System.Drawing.Size(113, 27);
            this.btnBuscarTodos.TabIndex = 617;
            this.btnBuscarTodos.Text = "BUSCAR";
            this.btnBuscarTodos.UseVisualStyleBackColor = false;
            this.btnBuscarTodos.Click += new System.EventHandler(this.btnBuscarTodos_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(450, 65);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 618;
            this.label2.Text = "Status";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "A RECEBER",
            "PAGO",
            "CANCELADA",
            "TODOS"});
            this.cmbStatus.Location = new System.Drawing.Point(454, 86);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(172, 24);
            this.cmbStatus.TabIndex = 616;
            // 
            // pbFoto
            // 
            this.pbFoto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbFoto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbFoto.Location = new System.Drawing.Point(2002, 14);
            this.pbFoto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pbFoto.Name = "pbFoto";
            this.pbFoto.Size = new System.Drawing.Size(262, 91);
            this.pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbFoto.TabIndex = 619;
            this.pbFoto.TabStop = false;
            // 
            // dgvContas
            // 
            this.dgvContas.AllowUserToAddRows = false;
            this.dgvContas.AllowUserToDeleteRows = false;
            this.dgvContas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvContas.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvContas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContas.Location = new System.Drawing.Point(10, 175);
            this.dgvContas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvContas.Name = "dgvContas";
            this.dgvContas.ReadOnly = true;
            this.dgvContas.RowHeadersVisible = false;
            this.dgvContas.RowHeadersWidth = 51;
            this.dgvContas.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvContas.RowTemplate.Height = 24;
            this.dgvContas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContas.Size = new System.Drawing.Size(1864, 513);
            this.dgvContas.TabIndex = 620;
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdicionar.BackColor = System.Drawing.Color.Gold;
            this.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionar.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.Black;
            this.btnAdicionar.Location = new System.Drawing.Point(1628, 695);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(123, 27);
            this.btnAdicionar.TabIndex = 621;
            this.btnAdicionar.Text = "RECEBER";
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // txtCliente
            // 
            this.txtCliente.Location = new System.Drawing.Point(14, 85);
            this.txtCliente.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.Size = new System.Drawing.Size(431, 26);
            this.txtCliente.TabIndex = 622;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(10, 120);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 18);
            this.label8.TabIndex = 629;
            this.label8.Text = "Tipo de data";
            // 
            // cbDatas
            // 
            this.cbDatas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDatas.FormattingEnabled = true;
            this.cbDatas.Items.AddRange(new object[] {
            "EMISSAO",
            "VENCIMENTO",
            "BAIXA"});
            this.cbDatas.Location = new System.Drawing.Point(14, 142);
            this.cbDatas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbDatas.Name = "cbDatas";
            this.cbDatas.Size = new System.Drawing.Size(211, 24);
            this.cbDatas.TabIndex = 623;
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.Gold;
            this.btnBuscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscar.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.ForeColor = System.Drawing.Color.Black;
            this.btnBuscar.Location = new System.Drawing.Point(915, 141);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(113, 27);
            this.btnBuscar.TabIndex = 626;
            this.btnBuscar.Text = "BUSCAR";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // dtData2
            // 
            this.dtData2.Location = new System.Drawing.Point(577, 142);
            this.dtData2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtData2.Name = "dtData2";
            this.dtData2.Size = new System.Drawing.Size(324, 26);
            this.dtData2.TabIndex = 625;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(575, 121);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 18);
            this.label1.TabIndex = 628;
            this.label1.Text = "Periodo : Fim da busca";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(237, 122);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 18);
            this.label3.TabIndex = 627;
            this.label3.Text = "Periodo : Inicio de busca";
            // 
            // dtData1
            // 
            this.dtData1.Location = new System.Drawing.Point(240, 142);
            this.dtData1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtData1.Name = "dtData1";
            this.dtData1.Size = new System.Drawing.Size(322, 26);
            this.dtData1.TabIndex = 624;
            // 
            // btnAlterarConta
            // 
            this.btnAlterarConta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAlterarConta.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnAlterarConta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterarConta.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterarConta.ForeColor = System.Drawing.Color.Black;
            this.btnAlterarConta.Location = new System.Drawing.Point(1434, 695);
            this.btnAlterarConta.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.btnAlterarConta.Name = "btnAlterarConta";
            this.btnAlterarConta.Size = new System.Drawing.Size(184, 27);
            this.btnAlterarConta.TabIndex = 630;
            this.btnAlterarConta.Text = "ALTERAR  DADOS";
            this.btnAlterarConta.UseVisualStyleBackColor = false;
            this.btnAlterarConta.Click += new System.EventHandler(this.btnAlterarConta_Click);
            // 
            // FrmConsultaContasAReceber
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(1908, 737);
            this.Controls.Add(this.btnAlterarConta);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbDatas);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.dtData2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtData1);
            this.Controls.Add(this.txtCliente);
            this.Controls.Add(this.btnAdicionar);
            this.Controls.Add(this.dgvContas);
            this.Controls.Add(this.pbFoto);
            this.Controls.Add(this.btnBuscarTodos);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.txtParcela);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnBuscarCliente);
            this.Controls.Add(this.txtModelo);
            this.Controls.Add(this.txtSerie);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbM);
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "FrmConsultaContasAReceber";
            this.Text = "Listar Contas a Receber";
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.lbM, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.txtNumero, 0);
            this.Controls.SetChildIndex(this.txtSerie, 0);
            this.Controls.SetChildIndex(this.txtModelo, 0);
            this.Controls.SetChildIndex(this.btnBuscarCliente, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.txtParcela, 0);
            this.Controls.SetChildIndex(this.cmbStatus, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.btnBuscarTodos, 0);
            this.Controls.SetChildIndex(this.pbFoto, 0);
            this.Controls.SetChildIndex(this.dgvContas, 0);
            this.Controls.SetChildIndex(this.btnAdicionar, 0);
            this.Controls.SetChildIndex(this.txtCliente, 0);
            this.Controls.SetChildIndex(this.dtData1, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.dtData2, 0);
            this.Controls.SetChildIndex(this.btnBuscar, 0);
            this.Controls.SetChildIndex(this.cbDatas, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.btnAlterarConta, 0);
            ((System.ComponentModel.ISupportInitialize)(this.txtParcela)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModelo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.NumericUpDown txtParcela;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.Button btnBuscarCliente;
        protected System.Windows.Forms.NumericUpDown txtModelo;
        protected System.Windows.Forms.NumericUpDown txtSerie;
        protected System.Windows.Forms.NumericUpDown txtNumero;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.Label lbM;
        protected System.Windows.Forms.Button btnBuscarTodos;
        protected System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.PictureBox pbFoto;
        private System.Windows.Forms.DataGridView dgvContas;
        protected System.Windows.Forms.Button btnAdicionar;
        private System.Windows.Forms.TextBox txtCliente;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.ComboBox cbDatas;
        protected System.Windows.Forms.Button btnBuscar;
        protected System.Windows.Forms.DateTimePicker dtData2;
        protected System.Windows.Forms.Label label1;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.DateTimePicker dtData1;
        protected System.Windows.Forms.Button btnAlterarConta;
    }
}
