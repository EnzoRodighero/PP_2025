﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PP_2025;

namespace PP_2025
{
    public partial class FrmConsultaUnidadeMedida : FrmConsulta
    {
        private CtlUnidadeMedida ctlUnidadeMedida = new CtlUnidadeMedida();
        private List<UnidadeMedida> listaUnidades = new List<UnidadeMedida>();

        public FrmConsultaUnidadeMedida()
        {
            InitializeComponent();
            // Adicione este trecho no Load ou no construtor após InitializeComponent()
            listView1.Columns.Clear();
            listView1.Columns.Add("Código", 80);
            listView1.Columns.Add("Nome da Unidade", 200);
        }

        private void FrmConsultaUnidadeMedida_Load(object sender, EventArgs e)
        {

        }

        public override void CarregaLV()
        {
            listView1.Items.Clear();
            listaUnidades = ctlUnidadeMedida.ListarUnidadesMedida();

            foreach (var unidade in listaUnidades)
            {
                var item = new ListViewItem(unidade.ID.ToString());
                item.SubItems.Add(unidade.UnidadeMedidaNome);
                item.Tag = unidade;
                listView1.Items.Add(item);
            }
            // Chame AjustarTamanhoColunas via reflexão para contornar o nível de proteção
            var method = typeof(FrmConsulta).GetMethod("AjustarTamanhoColunas", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            if (method != null)
            {
                method.Invoke(this, null);
            }
        }

        protected override void Incluir()
        {
            ctlUnidadeMedida.Incluir();
            CarregaLV();
        }

        protected override void Alterar()
        {
            if (listView1.SelectedItems.Count > 0)
            {
                var unidade = listView1.SelectedItems[0].Tag as UnidadeMedida;
                ctlUnidadeMedida.Alterar(unidade);
                CarregaLV();
            }
        }

        public override void Excluir()
        {
            if (listView1.SelectedItems.Count > 0)
            {
                var unidade = listView1.SelectedItems[0].Tag as UnidadeMedida;
                ctlUnidadeMedida.Excluir(unidade);
                CarregaLV();
            }
        }

        public override void Visualizar()
        {
            if (listView1.SelectedItems.Count > 0)
            {
                var unidade = listView1.SelectedItems[0].Tag as UnidadeMedida;
                ctlUnidadeMedida.Visualizar(unidade);
            }
        }

        protected override void Pesquisar()
        {
            string termo = txtCodigo.Text.Trim();
            listView1.Items.Clear();

            foreach (var unidade in listaUnidades)
            {
                if (unidade.ID.ToString().Contains(termo) || unidade.UnidadeMedidaNome.IndexOf(termo, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    var item = new ListViewItem(unidade.ID.ToString());
                    item.SubItems.Add(unidade.UnidadeMedidaNome);
                    item.Tag = unidade;
                    listView1.Items.Add(item);
                }
            }
            // Chame AjustarTamanhoColunas via reflexão para contornar o nível de proteção
            var method = typeof(FrmConsulta).GetMethod("AjustarTamanhoColunas", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            if (method != null)
            {
                method.Invoke(this, null);
            }
        }
    }
}
