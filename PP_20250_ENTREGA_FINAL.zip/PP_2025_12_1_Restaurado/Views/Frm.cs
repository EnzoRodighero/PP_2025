﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_2025
{
    public partial class Frm : Form
    {
        public Frm()
        {
            InitializeComponent();
            Operacao.DisableCopyPaste(this);
        }

        //Metodos Virtuais
        protected virtual void Sair()
        {
            Close();
        }

        //Metodos Privados
        private void btnSair_Click(object sender, EventArgs e)
        {
            Sair();
        }

        private void Frm_Load(object sender, EventArgs e)
        {

        }
    }
}
