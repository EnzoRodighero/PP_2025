﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace PP_2025
{
    public class CTLClientes
    {
        private DALClientes clientesDAL = new DALClientes();

        public string AdicionarCliente(Clientes cliente)
        {
            return clientesDAL.AdicionarCliente(cliente);
        }

        public string AtualizarCliente(Clientes cliente)
        {
            return clientesDAL.AtualizarCliente(cliente);
        }

        public bool ExcluirCliente(int clienteId)
        {
            return clientesDAL.ExcluirCliente(clienteId);
        }

        public Clientes BuscarClientePorId(int id)
        {
            return clientesDAL.BuscarClientePorId(id);
        }
        public string BuscarClientePorDocumento(string nome)
        {
            return clientesDAL.BuscarClientePorCPFouCNPJ(nome);
        }
        public Clientes BuscarClientePorDocumento2(string nome)
        {
            return clientesDAL.BuscarClientePorCPFouCNPJ2(nome);
        }
        public string BuscarClientePorRG(string nome)
        {
            return clientesDAL.BuscarClientePorRG(nome);
        }

        public List<Clientes> ListarClientes(string status)
        {
            return clientesDAL.ListarClientes(status);
        }

        public List<Clientes> PesquisarClientesPorCriterio(string criterio, string valorPesquisa, string status)
        {
            List<Clientes> Encontrados = clientesDAL.PesquisarClientesPorCriterio(criterio, valorPesquisa,status);
            return Encontrados;
        }

        public void Incluir()
        {
            FrmCadastroClienteII frmCadastroClientes = new FrmCadastroClienteII();
            frmCadastroClientes.Text = "Incluir Cliente";
            frmCadastroClientes.cmbStatus.Text = "ATIVO";
            frmCadastroClientes.cmbStatus.Enabled = false;
            frmCadastroClientes.toolTip1.SetToolTip(frmCadastroClientes.btnSalvar, "Salvar dados.");
            frmCadastroClientes.ShowDialog();
        }

        public void Alterar(Clientes cliente)
        {
            if (cliente != null)
            {
                FrmCadastroClienteII frmCadastroClientes = new FrmCadastroClienteII();
                frmCadastroClientes.ConhecaObj(cliente);
                frmCadastroClientes.Text = "Alterar Cliente";
                frmCadastroClientes.btnSalvar.Text = "ALTERAR";
                frmCadastroClientes.btnSalvar.BackColor = Color.BurlyWood;
                frmCadastroClientes.cmbFisJur.Enabled= false;
                frmCadastroClientes.cmbFisJur.Enabled = false;
                frmCadastroClientes.CarregarCampos();
                frmCadastroClientes.toolTip1.SetToolTip(frmCadastroClientes.btnSalvar, "Alterar dados.");
                frmCadastroClientes.ShowDialog();
            }
        }
        //cade os erros ?
        public void Excluir(Clientes cliente)
        {
            if (cliente != null)
            {
                FrmCadastroClienteII frmCadastroClientes = new FrmCadastroClienteII();
                frmCadastroClientes.ConhecaObj(cliente);
                frmCadastroClientes.Text = "Excluir Cliente";
                frmCadastroClientes.btnSalvar.Text = "EXCLUIR";
                frmCadastroClientes.toolTip1.SetToolTip(frmCadastroClientes.btnSalvar, "Excluir cliente.");
                frmCadastroClientes.btnSalvar.ForeColor = Color.White;
                frmCadastroClientes.btnSalvar.BackColor = Color.DarkRed;
                frmCadastroClientes.CarregarCampos();
                frmCadastroClientes.cmbFisJur.Enabled = false;
                frmCadastroClientes.BloquearCampos();  
                frmCadastroClientes.ShowDialog();
            }
        }

        public void Visualizar(Clientes cliente)
        {
            if (cliente != null)
            {
                FrmCadastroClienteII frmCadastroClientes = new FrmCadastroClienteII();
                frmCadastroClientes.ConhecaObj(cliente);
                frmCadastroClientes.Text = "Consultar Cliente";
                frmCadastroClientes.CarregarCampos();
                frmCadastroClientes.BloquearCampos();
                frmCadastroClientes.cmbFisJur.Enabled = false;
                frmCadastroClientes.btnSalvar.Enabled = false;
                frmCadastroClientes.ShowDialog();
            }
        }
    }
}
