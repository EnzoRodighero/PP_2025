﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PP_2025
{
    public partial class FrmCadastroPessoa : FrmCadastros
    {
        public FrmCadastroPessoa()
        {
            InitializeComponent();
        }

        private void txtTelefone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRG_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDtCriacao_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }

        private void FrmCadastroPessoa_Load(object sender, EventArgs e)
        {

        }
    }
}
