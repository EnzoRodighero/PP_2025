﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PP_2025;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PP_2025
{
    public partial class FrmConsultaContasAPagar : FrmConsulta
    {
        FrmCadastroContaPagar frmCOntaPagar;
        ContasPagar aContaPagar;
        protected Dictionary<string, double> _colunasProporcao = new Dictionary<string, double>();
        CTLContasPagar aCTLContaPagar;
        public FrmConsultaContasAPagar()
        {
            InitializeComponent();
            this.Resize += FrmConsultaContasAPagar_Resize;
            aCTLContaPagar = new CTLContasPagar();
            Operacao.DisableCopyPaste(this);
            DataGrid();
            CarregaLV();
        }
        protected void CalcularProporcoesColunas(DataGridView dgv)
        {
            _colunasProporcao.Clear();
            double larguraTotal = dgv.Width;

            foreach (DataGridViewColumn coluna in dgv.Columns)
            {
                if (coluna.Visible)
                {
                    _colunasProporcao[coluna.Name] = (double)coluna.Width / larguraTotal;
                }
            }
        }
        private void FrmConsultaContasAPagar_Resize(object sender, EventArgs e)
        {
            // Verifique se há um DataGridView e redimensione as colunas
            if (this.Controls.OfType<DataGridView>().Any())
            {
                DataGridView dgv = this.Controls.OfType<DataGridView>().First();
                RedimensionarColunas(dgv);
            }
        }
        // Método para redimensionar as colunas
        protected void RedimensionarColunas(DataGridView dgv)
        {
            double larguraTotal = dgv.Width;

            foreach (DataGridViewColumn coluna in dgv.Columns)
            {
                if (coluna.Visible && _colunasProporcao.ContainsKey(coluna.Name))
                {
                    coluna.Width = (int)(_colunasProporcao[coluna.Name] * larguraTotal);
                }
            }
        }

        public void SetFrmCadastro(object obj)
        {
            if (obj != null)
            {
                frmCOntaPagar = (FrmCadastroContaPagar)obj;
            }
        }
        public void ConhecaObj(object obj)
        {
            aContaPagar = (ContasPagar)obj;
        }
        protected void Incluir()
        {
            aCTLContaPagar.Incluir();
            CarregaLV();
        }

        protected int ObterIdSelecionado(string columnName)
        {
            if (dgvContas.SelectedRows.Count > 0)
            {
                return int.Parse(dgvContas.SelectedRows[0].Cells[columnName].Value.ToString());
            }
            return 0;
        }
        protected string ObterNomeSelecionado(string columnName)
        {
            if (dgvContas.SelectedRows.Count > 0)
            {
                return dgvContas.SelectedRows[0].Cells[columnName].Value.ToString();
            }
            return string.Empty; // Retorna uma string vazia como valor padrão caso não haja linha selecionada
        }
        public void Visualizar()
        {
            if (btnSair.Text == "Selecionar")
            {
                btnSair.PerformClick();
            }
            else if (dgvContas.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvContas.SelectedRows[0];
                ContasPagar conta = selectedRow.Tag as ContasPagar;
                if (conta != null)
                {
                    aCTLContaPagar.Visualizar(conta);
                    CarregaLV();
                }
            }
        }

        public void CarregaLV()
        {
            string valor = cmbStatus.Text;
            if (string.IsNullOrEmpty(valor))
                valor = "A PAGAR"; // Define o valor padrão como "A PAGAR" se o ComboBox estiver vazio
            List<ContasPagar> dados = aCTLContaPagar.ListarContasPagar(valor);
            PreencherDataGridView(dados);
        }

        private void btnBuscarTodos_Click(object sender, EventArgs e)
        {
            CarregaLV();
        }

        // Método para preencher o DataGridView com os dados de ContasPagar
        protected virtual void PreencherDataGridView(IEnumerable<ContasPagar> dados)
        {
            dgvContas.Rows.Clear();

            foreach (var conta in dados)
            {
                int rowIndex = dgvContas.Rows.Add();
                DataGridViewRow row = dgvContas.Rows[rowIndex];

                row.Cells["num_nfc"].Value = conta.NumNFC;
                row.Cells["modelo_nfc"].Value = conta.ModeloNFC;
                row.Cells["serie_nfc"].Value = conta.SerieNFC;
                row.Cells["num_parcela"].Value = conta.NumParcela;
                row.Cells["id_fornecedor"].Value = conta.Fornecedor.ID;
                row.Cells["fornecedor"].Value = conta.Fornecedor.NomeFantasia;
                row.Cells["Forma_pagamento"].Value = conta.FormaPagamento.Forma;
                row.Cells["Data_emissao"].Value = conta.DataCriacao == DateTime.MinValue ? string.Empty : conta.DataCriacao.ToString("dd/MM/yyyy");
                row.Cells["data_vencimento"].Value = conta.DataVencimento == DateTime.MinValue ? string.Empty : conta.DataVencimento.ToString("dd/MM/yyyy");
                row.Cells["Valor"].Value = conta.Valor == 0 ? string.Empty : conta.Valor.ToString("C");
                row.Cells["data_baixa"].Value = conta.DataBaixa == DateTime.MinValue ? string.Empty : conta.DataBaixa.ToString("dd/MM/yyyy");
                row.Cells["Pagamento"].Value = conta.Pagamento == 0 ? string.Empty : conta.Pagamento.ToString("C");
                row.Cells["Juros"].Value = conta.Taxa;
                row.Cells["Multa"].Value = conta.Multa;
                row.Cells["Desconto"].Value = conta.Desconto;
                row.Cells["situacao"].Value = conta.Situacao;
                row.Tag = conta;
            }

            AplicarFormatacao();
        }

        protected void DataGrid()
        {
            // Configurações iniciais do DataGridView
            dgvContas.AutoGenerateColumns = false;
            dgvContas.Columns.Clear(); // Limpa as colunas existentes
            dgvContas.Columns.AddRange(new DataGridViewTextBoxColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "num_nfc", HeaderText = "Nº NFC", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "modelo_nfc", HeaderText = "Modelo", Width = 60 },
                new DataGridViewTextBoxColumn { Name = "serie_nfc", HeaderText = "Série", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "num_parcela", HeaderText = "Parcela", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "id_fornecedor", HeaderText = "Cód Forn.", Width = 50 },
                new DataGridViewTextBoxColumn { Name = "fornecedor", HeaderText = "Fornecedor", Width = 200 },
                new DataGridViewTextBoxColumn { Name = "Forma_pagamento", HeaderText = "Forma Pgt", Width = 155 },
                new DataGridViewTextBoxColumn { Name = "Data_emissao", HeaderText = "Data Emissão", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "data_vencimento", HeaderText = "Data Vencimento", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Valor", HeaderText = "Parcela VR (R$)",  Width = 120, DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }},
                new DataGridViewTextBoxColumn { Name = "data_baixa",HeaderText = "Data Baixa", Width = 100},
                new DataGridViewTextBoxColumn {Name = "Pagamento", HeaderText = "Valor PG (R$)",Width = 120, DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }},
                new DataGridViewTextBoxColumn { Name = "Juros",HeaderText = "Juros", Width = 60, DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }},
                new DataGridViewTextBoxColumn { Name = "Multa", HeaderText = "Multa", Width = 60,DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight }},
                new DataGridViewTextBoxColumn { Name = "Desconto", HeaderText = "Desconto",Width = 60, DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleRight } },
                new DataGridViewTextBoxColumn { Name = "situacao", HeaderText = "Status", Width = 110 },
            });

            dgvContas.RowTemplate.Height = 40; // Altura das linhas em pixels

            dgvContas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvContas.MultiSelect = false;
            CalcularProporcoesColunas(dgvContas);
        }



        protected void AplicarFormatacao() // Aplica a formatação das cores no DataGridView
        {
            // Itera sobre cada linha do DataGridView
            foreach (DataGridViewRow row in dgvContas.Rows)
            {
                // Garante que nenhuma célula está selecionada
                dgvContas.CurrentCell = null;

                // Obtém o valor da célula "situacao"
                string situacao = row.Cells["situacao"].Value as string;

                // Formata a linha com fundo verde se a situação for "PAGO"
                if (situacao == "PAGO")
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        cell.Style.BackColor = Color.LightGreen;
                        cell.Style.ForeColor = Color.Black;
                    }
                }
                else if (situacao == "CANCELADA")
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        cell.Style.BackColor = Color.Gray;
                        cell.Style.ForeColor = Color.Black;
                    }
                }
                /*else
                {
                    // Verifica e formata com base na data de vencimento
                    if (row.Cells["data_vencimento"].Value != null && DateTime.TryParse(row.Cells["data_vencimento"].Value.ToString(), out DateTime dataVencimento))
                    {
                        TimeSpan diasParaVencimento = dataVencimento - DateTime.Now;

                        Color backColor;
                        Color foreColor;

                        if (diasParaVencimento.TotalDays < 0)
                        {
                            backColor = Color.DarkRed; // Vencida
                            foreColor = Color.White;  // Texto em branco para vencidas
                        }
                        else if (diasParaVencimento.TotalDays <= 3)
                        {
                            backColor = Color.Orange; // Entre 0 e 3 dias
                            foreColor = Color.Black;  // Texto padrão
                        }
                        else
                        {
                            backColor = Color.Yellow; // Mais de 3 dias
                            foreColor = Color.Black;  // Texto padrão
                        }

                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            cell.Style.BackColor = backColor;
                            cell.Style.ForeColor = foreColor;
                        }
                    }
                }*/
            }
        }



        // Método btnBuscarFornecedor_Click no form
        private void btnBuscarFornecedor_Click(object sender, EventArgs e)
        {
            int NumNFC = Convert.ToInt32(txtNumero.Value);
            int ModeloNFC = Convert.ToInt32(txtModelo.Value);
            int SerieNFC = Convert.ToInt32(txtSerie.Value);
            int FornNFC = Convert.ToInt32(txtForn.Value);
            int ParcelaNFC = Convert.ToInt32(txtParcela.Value);

            List<ContasPagar> dados = aCTLContaPagar.BuscarContas(NumNFC, ModeloNFC, SerieNFC, FornNFC, ParcelaNFC);
            PreencherDataGridView(dados);
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if(dtData1.Value > dtData2.Value)
            {
                MessageBox.Show("O periodo de busca não pode conter uma data inicial maior que a data final.");
            }
            else
                PesquisarContasAPagar();
        }

        private void txtFornecedor_TextChanged(object sender, EventArgs e)
        {

            List<ContasPagar> dados = aCTLContaPagar.BuscarContasPorNomeFornecedor(txtFornecedor.Text);
            PreencherDataGridView(dados);

        }
        protected void PesquisarContasAPagar()
        {
            // Obtém os parâmetros de filtragem
            DateTime? dataInicio = null;
            DateTime? dataFim = null;

            if (dtData1.Value.Date > DateTime.MinValue.Date)
            {
                dataInicio = dtData1.Value.Date;
            }

            if (dtData2.Value.Date > DateTime.MinValue.Date)
            {
                dataFim = dtData2.Value.Date;
            }
            if (string.IsNullOrEmpty(cbDatas.Text)) // Verifica se o ComboBox de tipo de data está vazio
            {
                return;
            }
            // Converte DateTime? para DateTime, usando .Value se houver valor, ou DateTime.MinValue caso contrário
            DateTime dataInicioValue = dataInicio ?? DateTime.MinValue;
            DateTime dataFimValue = dataFim ?? DateTime.MinValue;

            // Chama o método de busca com os parâmetros corrigidos
            List<ContasPagar> contas = aCTLContaPagar.ListarContasPagarComData(cmbStatus.Text, dataInicioValue, dataFimValue, cbDatas.Text);
            PreencherDataGridView(contas);
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (dgvContas.SelectedCells.Count > 0)
            {
                int numero = ObterIdSelecionado("num_nfc");
                int modelo = ObterIdSelecionado("modelo_nfc");
                int serie = ObterIdSelecionado("serie_nfc");
                int fornecedor = ObterIdSelecionado("id_fornecedor");
                int parcela = ObterIdSelecionado("num_parcela");
                string status = ObterNomeSelecionado("situacao");

                if (status != "CANCELADA")
                {
                    ContasPagar conta = aCTLContaPagar.BuscarContaPagar(numero, modelo, serie, fornecedor, parcela);
                    if (conta != null)
                    {
                        aCTLContaPagar.Alterar(conta);
                        CarregaLV();
                    }
                }
                else
                {
                    MessageBox.Show(
                        "A operação não pode ser realizada porque a nota fiscal selecionada foi cancelada.",
                        "Ação não permitida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
            }
        }


        private void FrmConsultaContasAPagar_Load(object sender, EventArgs e)
        {
            this.Resize += FrmConsultaContasAPagar_Resize;
        }

        private void dgvContas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvContas.EndEdit();
        }

        private void dgvContas_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Visualizar();
        }

        private void btnAlterarConta_Click(object sender, EventArgs e)
        {
            if (dgvContas.SelectedCells.Count > 0)
            {
                int numero = ObterIdSelecionado("num_nfc");
                int modelo = ObterIdSelecionado("modelo_nfc");
                int serie = ObterIdSelecionado("serie_nfc");
                int fornecedor = ObterIdSelecionado("id_fornecedor");
                int parcela = ObterIdSelecionado("num_parcela");
                string status = ObterNomeSelecionado("situacao");

                if (status != "CANCELADA")
                {
                    ContasPagar conta = aCTLContaPagar.BuscarContaPagar(numero, modelo, serie, fornecedor, parcela);
                    if (conta != null)
                    {
                        aCTLContaPagar.AlterarDados(conta);
                        CarregaLV();
                    }
                }
                else
                {
                    MessageBox.Show(
                        "A operação não pode ser realizada porque a nota fiscal selecionada foi cancelada.",
                        "Ação não permitida",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                }
            }
        }
    }
}
