﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_2025
{
    internal class Interfaces
    {
        // CLASSES 
        private FormaPagamento aFormaPagamento;
        private CondicaoPagamento aCondicaoPagamento;

        private Paises oPais;
        private Estados oEstado;
        private Cidades aCidade;

        private Clientes oCliente;
        private Fornecedores oFornecedor;

        private Cargos oCargo;
        private Funcionarios oFuncionario;

        private Categoria aCategoria;
        private Marca aMarca;
        private Produto oProduto;

        private Compra aCompra;

        //Cadastros
        FrmCadastroFormaPagamento ofrmCadFormaPagamento;
        FrmCadastroCondicaoPagamento ofrmCadCondPG;

        FrmCadastroPais ofrmCadPaises;
        FrmCadastroEstado ofrmCadEstados;
        FrmCadastroCidade ofrmCadCidades;

        FrmCadastroClienteII ofrmCadClientes;
        FrmCadastroFornecedoresII ofrmCadFornecedores;

        FrmCadastroCargo ofrmCadCargo;
        FrmCadastroFuncionarioII ofrmCadFuncionario;

        FrmCadastroCategoria ofrmCadCategoria;
        FrmCadastroMarca ofrmCadMarca;
        FrmCadastroProduto ofrmCadProduto;

        FrmCadastroCompra ofrmCadCompra;

        //Consultas
        FrmConsultaFormaPagamento ofrmConFormaPagamento;
        FrmConsultaCondicaoPagamento ofrmConCondPG; 

        FrmConsultaPais ofrmConPaises;
        FrmConsultaEstado ofrmConEstados;
        FrmConsultaCidade ofrmConCidades;

        FrmConsultaCliente ofrmConClientes;
        FrmConsultaFornecedor ofrmConFornecedores;

        FrmConsultaCargo ofrmConCargo;
        FrmConsultaFuncionario ofrmConFuncionario;

        FrmConsultaCategoria ofrmConCategoria;
        FrmConsultaMarca ofrmConMarca;
        FrmConsultaProduto ofrmConProduto;

        FrmConsultaCompra ofrmConCompra;

        public Interfaces()
        {
            //Classes 
            aFormaPagamento = new FormaPagamento();
            aCondicaoPagamento = new CondicaoPagamento();

            oPais = new Paises();
            oEstado = new Estados();
            aCidade = new Cidades();

            oCliente = new Clientes();
            oFornecedor = new Fornecedores();

            oCargo = new Cargos();
            oFuncionario = new Funcionarios();

            aCategoria = new Categoria();
            aMarca = new Marca();
            oProduto = new Produto();

            aCompra = new Compra();

            //Cadastros
            ofrmCadFormaPagamento = new FrmCadastroFormaPagamento();
            ofrmCadCondPG = new FrmCadastroCondicaoPagamento();

            ofrmCadPaises = new FrmCadastroPais();
            ofrmCadEstados = new FrmCadastroEstado();
            ofrmCadCidades = new FrmCadastroCidade();

            ofrmCadClientes = new FrmCadastroClienteII();
            ofrmCadFornecedores = new FrmCadastroFornecedoresII();

            ofrmCadCargo = new FrmCadastroCargo();
            ofrmCadFuncionario = new FrmCadastroFuncionarioII();

            ofrmCadCategoria = new FrmCadastroCategoria();
            ofrmCadMarca = new FrmCadastroMarca();
            ofrmCadProduto = new FrmCadastroProduto();

            ofrmCadCompra = new FrmCadastroCompra();

            //Consultas          
            ofrmConFormaPagamento = new FrmConsultaFormaPagamento();
            ofrmConCondPG = new FrmConsultaCondicaoPagamento();

            ofrmConPaises = new FrmConsultaPais();
            ofrmConEstados = new FrmConsultaEstado();
            ofrmConCidades = new FrmConsultaCidade();

            ofrmConClientes = new FrmConsultaCliente();
            ofrmConFornecedores = new FrmConsultaFornecedor();

            ofrmConCargo = new FrmConsultaCargo();
            ofrmConFuncionario = new FrmConsultaFuncionario();

            ofrmConCategoria = new FrmConsultaCategoria();
            ofrmConMarca = new FrmConsultaMarca();
            ofrmConProduto = new FrmConsultaProduto();

            ofrmConCompra = new FrmConsultaCompra();

            //Setar os metodos.
            ofrmConFormaPagamento.SetFrmCadastro(ofrmCadFormaPagamento);
            ofrmConCondPG.SetFrmCadastro(ofrmCadCondPG); 

            ofrmConPaises.SetFrmCadastro(ofrmCadPaises);
            ofrmConEstados.SetFrmCadastro(ofrmCadEstados); 
            ofrmConCidades.SetFrmCadastro(ofrmCadCidades); 
            ofrmCadEstados.SetConsultaPaises(ofrmConPaises);  
            ofrmCadCidades.SetConsultaEstados(ofrmConEstados);

            ofrmConClientes.SetFrmCadastro(ofrmCadClientes); // Incluir Clientes 
            ofrmConFornecedores.SetFrmCadastro(ofrmCadFornecedores); // Incluir Fornecedores
            ofrmConCargo.SetFrmCadastro(ofrmCadCargo); // Incluir Cargo
            ofrmConFuncionario.SetFrmCadastro(ofrmCadFuncionario); // Incluir Funcionario

            ofrmConCategoria.SetFrmCadastro(ofrmCadCategoria); // Incluir Categoria
            ofrmConMarca.SetFrmCadastro(ofrmCadMarca); // Incluir Marca
            ofrmConProduto.SetFrmCadastro(ofrmCadProduto); // Incluir Produto

            ofrmConCompra.SetFrmCadastro(ofrmCadCompra); // Incluir Compra
        }

        public void pecaForm(string tag)
        {
            void PecaFormulario(Form mostra, object consultado)
            {
                if (mostra is FrmConsulta consulta)
                {
                    consulta.ConhecaObj(consultado);
                    consulta.ShowDialog();
                }
            }

            switch (tag) // colocar todos os forms todos.
            {
                //FINANCEIRO
                case "FORMA DE PAGAMENTO": PecaFormulario(ofrmConFormaPagamento, aFormaPagamento); break;
                case "CONDIÇÃO DE PAGAMENTO": PecaFormulario(ofrmConCondPG, aCondicaoPagamento); break;

                //LOCAIS
                case "PAÍSES": PecaFormulario(ofrmConPaises, oPais); break;
                case "ESTADOS": PecaFormulario(ofrmConEstados, oEstado); break;
                case "CIDADES": PecaFormulario(ofrmConCidades, aCidade); break;

                //PESSOAS
                case "CLIENTES": PecaFormulario(ofrmConClientes, oCliente); break;
                case "FORNECEDORES": PecaFormulario(ofrmConFornecedores, oFornecedor); break;
                case "FUNCIONÁRIOS": PecaFormulario(ofrmConFuncionario, oFuncionario); break;

                //FUNÇÕES
                case "CARGOS": PecaFormulario(ofrmConCargo, oCargo); break;

                //PRODUTOS
                case "CATEGORIAS": PecaFormulario(ofrmConCategoria, aCategoria); break;
                case "PRODUTOS": PecaFormulario(ofrmConProduto, oProduto); break;
                case "MARCAS": PecaFormulario(ofrmConMarca, aMarca); break;

                //SERVIÇOS
                case "COMPRAS": PecaFormulario(ofrmConCompra, aCompra); break;
            }
        }
      
        private void Sair()
        {
            DialogResult result = MessageBox.Show("Deseja encerrar a aplicação ?", "confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else 
            {
            
            };
        }
    }
}
