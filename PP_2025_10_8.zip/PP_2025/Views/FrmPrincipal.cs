﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_2025
{
    public partial class FrmPrincipal : Form
    {


        private Interfaces aInter;
        private HashSet<string> acessosPermitidos;
        private int id;

        public FrmPrincipal()
        {
            InitializeComponent();
            aInter = new Interfaces();
            id = 0;

        }

        Dictionary<string, string> tagsLocalizacoes = new Dictionary<string, string> // dicionario com o tag e text, também a foto do botão.
        {
            { "PAÍSES", "Paises" },
            { "ESTADOS", "Estados" },
            { "CIDADES", "Cidades" }, 
        };

        Dictionary<string, string> tagsFinanceiro = new Dictionary<string, string>
        {
            { "FORMA DE PAGAMENTO", "Forma_Pagamento" },
            { "CONDIÇÃO DE PAGAMENTO", "Condicao_pagamento" },
        };

        Dictionary<string, string> tagsPessoas = new Dictionary<string, string> // dicionario com o tag e text, também a foto do botão.
        {
            { "CLIENTES", "Clientes" },
            { "FORNECEDORES", "Fornecedores" },
            { "FUNCIONÁRIOS", "Funcionarios" },
        };

        Dictionary<string, string> tagsFuncao = new Dictionary<string, string> // dicionario com o tag e text, também a foto do botão.
        {
            { "CARGOS", "Cargos" },
        };

        Dictionary<string, string> tagsProdutos = new Dictionary<string, string> // dicionario com o tag e text, também a foto do botão.
        {
            { "CATEGORIAS", "Categorias" },
            { "PRODUTOS", "Produtos" },
            { "MARCAS", "Marcas" }, 
        };

        Dictionary<string, string> tagsServicos = new Dictionary<string, string> // dicionario com o tag e text, também a foto do botão.
        {
            { "COMPRAS", "Compras" }, //TAG + text / FOTO
        };

        private void btnFinanceiro_Click(object sender, EventArgs e)
        {
            DestacarMenu(btnFinanceiro); // Destaca o menu lateral
            RemoverBotoesPorNome("btn"); // Remove os botões gerados
            CriarLayoutBotoes(2, tagsFinanceiro, acessosPermitidos); // QTD Botões Criados + TAG dos botões + Permissões
        }
      
        private void DestacarMenu(Button btn)
        {
            DestacarBotao(btn, new List<Button>
            {
                btnFinanceiro
            }, Color.FromArgb(184, 134, 11), Color.FromArgb(184, 134, 11), lblDesc); //Os dois rgb's eram diferentes
        }
        private void DestacarBotao(Button btn, List<Button> botoes, Color corPadrao, Color corDestaque, Label lbl)
        {
            foreach (Button b in botoes)
            {
                b.BackColor = corPadrao;
                b.ForeColor = Color.Black; // Reseta a cor do texto dos outros botões para preto
            }
            btn.BackColor = corDestaque;
            btn.ForeColor = Color.White; // Altera a cor do texto do botão destacado para branco
            lbl.Text = btn.Text;
        }
        private void RemoverBotoesPorNome(string nomePadrao)
        {
            // Remove todos os botões cujo nome começa com o padrão especificado e libera recursos
            var botoesParaRemover = panelButtons.Controls.OfType<Button>()
                .Where(btn => btn.Name.StartsWith(nomePadrao))
                .ToList();

            foreach (var btn in botoesParaRemover)
            {
                panelButtons.Controls.Remove(btn);
                btn.Dispose(); // Libera os recursos do botão removido
            }
        }
        private void CriarLayoutBotoes(int qtd, Dictionary<string, string> tags, HashSet<string> acessosPermitidos)
        {
            // Limpa os botões existentes
            panelButtons.Controls.Clear();
            int botaoWidth = 218;
            int botaoHeight = 50;
            int espacamento = 7; // Espaçamento entre botões
            int colunas = 4; // Número de colunas

            // Calcula o número de linhas necessárias
            int linhas = (int)Math.Ceiling((double)qtd / colunas);

            // Ajusta o tamanho do painel para acomodar todos os botões
            panelButtons.AutoScroll = true;
            panelButtons.HorizontalScroll.Enabled = false;
            panelButtons.VerticalScroll.Visible = true;
            panelButtons.VerticalScroll.Value = 0;
            panelButtons.VerticalScroll.Maximum = Math.Max(0, (linhas * botaoHeight) - panelButtons.ClientSize.Height);
            panelButtons.AutoScrollMinSize = new Size(botaoWidth * colunas, linhas * botaoHeight);

            int index = 0;

            foreach (var tag in tags)
            {
                if (index >= qtd) break;

                // Verifica se o botão deve ser habilitado com base nas permissões
                bool temAcesso = true; //acessosPermitidos.Contains(tag.Key);
                // alterar apenas para quando for implementar  o controle de acesso. tirar // do codigo a cima e retirar o true.

                Button btn = new Button
                {
                    Name = $"btn{index + 1}", // Nome do botão com base no índice
                    Text = tag.Key, // Define o texto do botão com base na tag
                    BackColor = Color.FromArgb(255, 215, 0), //Mudei os rgb's aqui também
                    Size = new Size(botaoWidth, botaoHeight),
                    TextAlign = ContentAlignment.BottomCenter,
                    TextImageRelation = TextImageRelation.Overlay,
                    FlatStyle = FlatStyle.Flat,
                    BackgroundImageLayout = ImageLayout.Zoom,
                    Cursor = Cursors.Hand,
                    FlatAppearance = { BorderSize = 0 },
                    Font = new Font("Microsoft Sans Serif", 12.75f, FontStyle.Bold),
                    Enabled = temAcesso, // Define se o botão está habilitado com base nas permissões
                    Tag = tag.Key // Define a tag do botão com o texto (tag.Key)
                };

                // Define a localização do botão
                int coluna = index % colunas;
                int linha = index / colunas;
                int x = coluna * (botaoWidth + espacamento);
                int y = linha * (botaoHeight + espacamento);

                btn.Location = new Point(x, y);

                // Define a imagem de fundo do botão com base na tag
                Image image = Properties.Resources.ResourceManager.GetObject(tag.Value) as Image;
                if (image != null)
                {
                    btn.BackgroundImage = null;
                }
                else
                {
                    //btn.BackgroundImage = Properties.Resources.sem_foto;
                }

                // Adiciona tooltip ao botão
                ToolTip toolTip = new ToolTip();
                toolTip.SetToolTip(btn, tag.Key); // Define o texto do tooltip com base na tag

                // Adiciona o manipulador de eventos para o clique do botão
                btn.Click += Btn_Click;

                // Adiciona o botão ao painel
                panelButtons.Controls.Add(btn);

                index++;
            }
        }
        private void Btn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string tag = btn.Tag.ToString(); // Obtém a tag do botão como texto
            aInter.pecaForm(tag); // Chama o método com o texto correspondente
        }

        private void FrmTestes_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnLocalizacoes_Click(object sender, EventArgs e)
        {
            DestacarMenu(btnLocalizacoes); // Destaca o menu lateral
            RemoverBotoesPorNome("btn"); // Remove os botões gerados
            CriarLayoutBotoes(3, tagsLocalizacoes, acessosPermitidos);
        }

        private void btnPessoas_Click(object sender, EventArgs e)
        {
            DestacarMenu(btnLocalizacoes); // Destaca o menu lateral
            RemoverBotoesPorNome("btn"); // Remove os botões gerados
            CriarLayoutBotoes(3, tagsPessoas, acessosPermitidos);
        }

        private void btnFuncao_Click(object sender, EventArgs e)
        {
            DestacarMenu(btnFuncao); // Destaca o menu lateral
            RemoverBotoesPorNome("btn"); // Remove os botões gerados
            CriarLayoutBotoes(1, tagsFuncao, acessosPermitidos);
        }

        private void btnProdutos_Click(object sender, EventArgs e)
        {
            DestacarMenu(btnProdutos); // Destaca o menu lateral
            RemoverBotoesPorNome("btn"); // Remove os botões gerados
            CriarLayoutBotoes(3, tagsProdutos, acessosPermitidos); // QTD Botões Criados + TAG dos botões + Permissões
        }

        private void btnServicos_Click(object sender, EventArgs e)
        {
            DestacarMenu(btnServicos); // Destaca o menu lateral
            RemoverBotoesPorNome("btn"); // Remove os botões gerados
            CriarLayoutBotoes(6, tagsServicos, acessosPermitidos); // QTD Botões Criados + TAG dos botões + Permissões 
        }
    }
}
