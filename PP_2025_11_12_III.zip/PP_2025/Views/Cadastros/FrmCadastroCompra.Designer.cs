﻿namespace PP_2025
{
    partial class FrmCadastroCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.gbCondicao = new System.Windows.Forms.GroupBox();
            this.lblTotalProds = new System.Windows.Forms.Label();
            this.txtTotalProds = new System.Windows.Forms.TextBox();
            this.btnBuscarCondicao = new System.Windows.Forms.Button();
            this.btnFinalizaCondicao = new System.Windows.Forms.Button();
            this.txtTotalNota = new System.Windows.Forms.TextBox();
            this.txtSeguro = new System.Windows.Forms.TextBox();
            this.lbTotalNota = new System.Windows.Forms.Label();
            this.txtOutras = new System.Windows.Forms.TextBox();
            this.txtFrete = new System.Windows.Forms.TextBox();
            this.lbCondicaoPg = new System.Windows.Forms.Label();
            this.lbOutras = new System.Windows.Forms.Label();
            this.txtCondicao = new System.Windows.Forms.TextBox();
            this.lbCodigoCondicao = new System.Windows.Forms.Label();
            this.lbSeguro = new System.Windows.Forms.Label();
            this.txtCodCondicao = new System.Windows.Forms.TextBox();
            this.lbFrete = new System.Windows.Forms.Label();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.GbChave = new System.Windows.Forms.GroupBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.Nome = new System.Windows.Forms.Label();
            this.txtNumNFC = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.txtModeloNFC = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtSerieNFC = new System.Windows.Forms.NumericUpDown();
            this.clForn = new System.Windows.Forms.Label();
            this.txtFornecedor = new System.Windows.Forms.TextBox();
            this.btnBuscarFornecedor = new System.Windows.Forms.Button();
            this.gbDatas = new System.Windows.Forms.GroupBox();
            this.btnVerificaData = new System.Windows.Forms.Button();
            this.dtEmissao = new System.Windows.Forms.DateTimePicker();
            this.dtChegada = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.lblLinkVideo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.gbProdutos = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtTotalItens = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtUND = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCusto = new System.Windows.Forms.TextBox();
            this.txtDesconto = new System.Windows.Forms.TextBox();
            this.txtQtd = new System.Windows.Forms.TextBox();
            this.btnBuscarProduto = new System.Windows.Forms.Button();
            this.txtCodProduto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtProduto = new System.Windows.Forms.TextBox();
            this.Dgv = new System.Windows.Forms.DataGridView();
            this.btnFinaliza = new System.Windows.Forms.Button();
            this.lvContasPagar = new System.Windows.Forms.ListView();
            this.clParcelas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDias = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clIdForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPercentTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPreco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvParcelas = new System.Windows.Forms.ListView();
            this.gbCondicao.SuspendLayout();
            this.GbChave.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumNFC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModeloNFC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerieNFC)).BeginInit();
            this.gbDatas.SuspendLayout();
            this.gbProdutos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSalvar
            // 
            this.btnSalvar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvar.Location = new System.Drawing.Point(1230, 749);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.btnSalvar.TabIndex = 50;
            // 
            // panel3
            // 
            this.panel3.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.panel3.Size = new System.Drawing.Size(1495, 10);
            // 
            // lblCodigo
            // 
            this.lblCodigo.Enabled = true;
            this.lblCodigo.Location = new System.Drawing.Point(347, 53);
            this.lblCodigo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Enabled = true;
            this.txtCodigo.Location = new System.Drawing.Point(347, 73);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.txtCodigo.ReadOnly = false;
            this.txtCodigo.TabIndex = 4;
            this.txtCodigo.Enter += new System.EventHandler(this.txtCodigo_Enter);
            this.txtCodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigo_KeyPress);
            // 
            // btnSair
            // 
            this.btnSair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSair.Location = new System.Drawing.Point(1354, 749);
            this.btnSair.Margin = new System.Windows.Forms.Padding(5);
            this.btnSair.TabIndex = 51;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(-125, 503);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 18);
            this.label9.TabIndex = 82;
            this.label9.Text = "Data Cad.";
            // 
            // gbCondicao
            // 
            this.gbCondicao.Controls.Add(this.lblTotalProds);
            this.gbCondicao.Controls.Add(this.txtTotalProds);
            this.gbCondicao.Controls.Add(this.btnBuscarCondicao);
            this.gbCondicao.Controls.Add(this.btnFinalizaCondicao);
            this.gbCondicao.Controls.Add(this.txtTotalNota);
            this.gbCondicao.Controls.Add(this.txtSeguro);
            this.gbCondicao.Controls.Add(this.lbTotalNota);
            this.gbCondicao.Controls.Add(this.txtOutras);
            this.gbCondicao.Controls.Add(this.txtFrete);
            this.gbCondicao.Controls.Add(this.lbCondicaoPg);
            this.gbCondicao.Controls.Add(this.lbOutras);
            this.gbCondicao.Controls.Add(this.txtCondicao);
            this.gbCondicao.Controls.Add(this.lbCodigoCondicao);
            this.gbCondicao.Controls.Add(this.lbSeguro);
            this.gbCondicao.Controls.Add(this.txtCodCondicao);
            this.gbCondicao.Controls.Add(this.lbFrete);
            this.gbCondicao.Enabled = false;
            this.gbCondicao.Location = new System.Drawing.Point(19, 437);
            this.gbCondicao.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCondicao.Name = "gbCondicao";
            this.gbCondicao.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbCondicao.Size = new System.Drawing.Size(1445, 83);
            this.gbCondicao.TabIndex = 88;
            this.gbCondicao.TabStop = false;
            this.gbCondicao.Enter += new System.EventHandler(this.gbCondicao_Enter);
            // 
            // lblTotalProds
            // 
            this.lblTotalProds.AutoSize = true;
            this.lblTotalProds.Location = new System.Drawing.Point(1195, 20);
            this.lblTotalProds.Name = "lblTotalProds";
            this.lblTotalProds.Size = new System.Drawing.Size(112, 18);
            this.lblTotalProds.TabIndex = 805;
            this.lblTotalProds.Text = "Total Produtos";
            // 
            // txtTotalProds
            // 
            this.txtTotalProds.BackColor = System.Drawing.Color.SkyBlue;
            this.txtTotalProds.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalProds.Location = new System.Drawing.Point(1198, 40);
            this.txtTotalProds.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalProds.MaxLength = 10;
            this.txtTotalProds.Name = "txtTotalProds";
            this.txtTotalProds.ReadOnly = true;
            this.txtTotalProds.Size = new System.Drawing.Size(120, 32);
            this.txtTotalProds.TabIndex = 804;
            this.txtTotalProds.Text = "0";
            this.txtTotalProds.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnBuscarCondicao
            // 
            this.btnBuscarCondicao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscarCondicao.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarCondicao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarCondicao.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCondicao.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarCondicao.Location = new System.Drawing.Point(832, 41);
            this.btnBuscarCondicao.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscarCondicao.Name = "btnBuscarCondicao";
            this.btnBuscarCondicao.Size = new System.Drawing.Size(113, 27);
            this.btnBuscarCondicao.TabIndex = 803;
            this.btnBuscarCondicao.Text = "BUSCAR";
            this.btnBuscarCondicao.UseVisualStyleBackColor = false;
            this.btnBuscarCondicao.Click += new System.EventHandler(this.btnBuscarCondicao_Click);
            // 
            // btnFinalizaCondicao
            // 
            this.btnFinalizaCondicao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFinalizaCondicao.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnFinalizaCondicao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizaCondicao.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizaCondicao.ForeColor = System.Drawing.Color.Black;
            this.btnFinalizaCondicao.Location = new System.Drawing.Point(955, 38);
            this.btnFinalizaCondicao.Margin = new System.Windows.Forms.Padding(5);
            this.btnFinalizaCondicao.Name = "btnFinalizaCondicao";
            this.btnFinalizaCondicao.Size = new System.Drawing.Size(162, 33);
            this.btnFinalizaCondicao.TabIndex = 802;
            this.btnFinalizaCondicao.Text = "FINALIZAR";
            this.btnFinalizaCondicao.UseVisualStyleBackColor = false;
            this.btnFinalizaCondicao.Click += new System.EventHandler(this.btnFinalizaCondicao_Click);
            // 
            // txtTotalNota
            // 
            this.txtTotalNota.BackColor = System.Drawing.Color.BurlyWood;
            this.txtTotalNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalNota.Location = new System.Drawing.Point(1324, 40);
            this.txtTotalNota.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalNota.MaxLength = 10;
            this.txtTotalNota.Name = "txtTotalNota";
            this.txtTotalNota.ReadOnly = true;
            this.txtTotalNota.Size = new System.Drawing.Size(120, 32);
            this.txtTotalNota.TabIndex = 107;
            this.txtTotalNota.Text = "0";
            this.txtTotalNota.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSeguro
            // 
            this.txtSeguro.BackColor = System.Drawing.Color.White;
            this.txtSeguro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeguro.Location = new System.Drawing.Point(136, 35);
            this.txtSeguro.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSeguro.MaxLength = 10;
            this.txtSeguro.Name = "txtSeguro";
            this.txtSeguro.Size = new System.Drawing.Size(120, 32);
            this.txtSeguro.TabIndex = 105;
            this.txtSeguro.Text = "0";
            this.txtSeguro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSeguro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress);
            this.txtSeguro.Leave += new System.EventHandler(this.txtFrete_Leave);
            // 
            // lbTotalNota
            // 
            this.lbTotalNota.AutoSize = true;
            this.lbTotalNota.Location = new System.Drawing.Point(1320, 22);
            this.lbTotalNota.Name = "lbTotalNota";
            this.lbTotalNota.Size = new System.Drawing.Size(83, 18);
            this.lbTotalNota.TabIndex = 99;
            this.lbTotalNota.Text = "Total Nota";
            // 
            // txtOutras
            // 
            this.txtOutras.BackColor = System.Drawing.Color.White;
            this.txtOutras.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutras.Location = new System.Drawing.Point(262, 35);
            this.txtOutras.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtOutras.MaxLength = 10;
            this.txtOutras.Name = "txtOutras";
            this.txtOutras.Size = new System.Drawing.Size(120, 32);
            this.txtOutras.TabIndex = 104;
            this.txtOutras.Text = "0";
            this.txtOutras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOutras.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress);
            this.txtOutras.Leave += new System.EventHandler(this.txtFrete_Leave);
            // 
            // txtFrete
            // 
            this.txtFrete.BackColor = System.Drawing.Color.White;
            this.txtFrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFrete.Location = new System.Drawing.Point(6, 35);
            this.txtFrete.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFrete.MaxLength = 10;
            this.txtFrete.Name = "txtFrete";
            this.txtFrete.Size = new System.Drawing.Size(120, 32);
            this.txtFrete.TabIndex = 106;
            this.txtFrete.Text = "0";
            this.txtFrete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFrete.TextChanged += new System.EventHandler(this.txtFrete_TextChanged);
            this.txtFrete.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress);
            this.txtFrete.Leave += new System.EventHandler(this.txtFrete_Leave);
            // 
            // lbCondicaoPg
            // 
            this.lbCondicaoPg.AutoSize = true;
            this.lbCondicaoPg.Location = new System.Drawing.Point(495, 16);
            this.lbCondicaoPg.Name = "lbCondicaoPg";
            this.lbCondicaoPg.Size = new System.Drawing.Size(179, 18);
            this.lbCondicaoPg.TabIndex = 90;
            this.lbCondicaoPg.Text = "Condição de Pagamento";
            // 
            // lbOutras
            // 
            this.lbOutras.AutoSize = true;
            this.lbOutras.Location = new System.Drawing.Point(259, 15);
            this.lbOutras.Name = "lbOutras";
            this.lbOutras.Size = new System.Drawing.Size(125, 18);
            this.lbOutras.TabIndex = 97;
            this.lbOutras.Text = "Outras Despesas";
            // 
            // txtCondicao
            // 
            this.txtCondicao.Enabled = false;
            this.txtCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCondicao.Location = new System.Drawing.Point(497, 37);
            this.txtCondicao.Margin = new System.Windows.Forms.Padding(5);
            this.txtCondicao.MaxLength = 100;
            this.txtCondicao.Name = "txtCondicao";
            this.txtCondicao.ReadOnly = true;
            this.txtCondicao.Size = new System.Drawing.Size(323, 32);
            this.txtCondicao.TabIndex = 46;
            // 
            // lbCodigoCondicao
            // 
            this.lbCodigoCondicao.AutoSize = true;
            this.lbCodigoCondicao.Location = new System.Drawing.Point(407, 16);
            this.lbCodigoCondicao.Name = "lbCodigoCondicao";
            this.lbCodigoCondicao.Size = new System.Drawing.Size(60, 18);
            this.lbCodigoCondicao.TabIndex = 88;
            this.lbCodigoCondicao.Text = "Código";
            // 
            // lbSeguro
            // 
            this.lbSeguro.AutoSize = true;
            this.lbSeguro.Location = new System.Drawing.Point(133, 16);
            this.lbSeguro.Name = "lbSeguro";
            this.lbSeguro.Size = new System.Drawing.Size(103, 18);
            this.lbSeguro.TabIndex = 95;
            this.lbSeguro.Text = "Custo Seguro";
            // 
            // txtCodCondicao
            // 
            this.txtCodCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCondicao.Location = new System.Drawing.Point(410, 37);
            this.txtCodCondicao.Margin = new System.Windows.Forms.Padding(5);
            this.txtCodCondicao.MaxLength = 100;
            this.txtCodCondicao.Name = "txtCodCondicao";
            this.txtCodCondicao.Size = new System.Drawing.Size(79, 32);
            this.txtCodCondicao.TabIndex = 45;
            this.txtCodCondicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodCondicao.Enter += new System.EventHandler(this.txtCodigo_Enter);
            this.txtCodCondicao.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigo_KeyPress);
            this.txtCodCondicao.Leave += new System.EventHandler(this.txtCodCondicao_Leave);
            // 
            // lbFrete
            // 
            this.lbFrete.AutoSize = true;
            this.lbFrete.Location = new System.Drawing.Point(3, 16);
            this.lbFrete.Name = "lbFrete";
            this.lbFrete.Size = new System.Drawing.Size(89, 18);
            this.lbFrete.TabIndex = 93;
            this.lbFrete.Text = "Custo Frete";
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAdicionar.BackColor = System.Drawing.Color.Gold;
            this.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionar.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.Black;
            this.btnAdicionar.Location = new System.Drawing.Point(1074, 35);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(5);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(130, 27);
            this.btnAdicionar.TabIndex = 36;
            this.btnAdicionar.Text = "ADICIONAR";
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // GbChave
            // 
            this.GbChave.Controls.Add(this.btnVerificar);
            this.GbChave.Controls.Add(this.Nome);
            this.GbChave.Controls.Add(this.txtNumNFC);
            this.GbChave.Controls.Add(this.label3);
            this.GbChave.Controls.Add(this.txtModeloNFC);
            this.GbChave.Controls.Add(this.label4);
            this.GbChave.Controls.Add(this.txtSerieNFC);
            this.GbChave.Controls.Add(this.clForn);
            this.GbChave.Controls.Add(this.txtFornecedor);
            this.GbChave.Controls.Add(this.btnBuscarFornecedor);
            this.GbChave.Location = new System.Drawing.Point(19, 33);
            this.GbChave.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GbChave.Name = "GbChave";
            this.GbChave.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GbChave.Size = new System.Drawing.Size(815, 83);
            this.GbChave.TabIndex = 0;
            this.GbChave.TabStop = false;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnVerificar.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnVerificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerificar.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.ForeColor = System.Drawing.Color.Black;
            this.btnVerificar.Location = new System.Drawing.Point(568, 8);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(5);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(122, 27);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "VERIFICAR";
            this.btnVerificar.UseVisualStyleBackColor = false;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // Nome
            // 
            this.Nome.AutoSize = true;
            this.Nome.Location = new System.Drawing.Point(221, 18);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(63, 18);
            this.Nome.TabIndex = 104;
            this.Nome.Text = "Nº Nota";
            // 
            // txtNumNFC
            // 
            this.txtNumNFC.BackColor = System.Drawing.Color.White;
            this.txtNumNFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumNFC.Location = new System.Drawing.Point(211, 39);
            this.txtNumNFC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumNFC.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtNumNFC.Name = "txtNumNFC";
            this.txtNumNFC.Size = new System.Drawing.Size(95, 32);
            this.txtNumNFC.TabIndex = 1;
            this.txtNumNFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtNumNFC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumNFC_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 18);
            this.label3.TabIndex = 105;
            this.label3.Text = "Modelo Nota";
            // 
            // txtModeloNFC
            // 
            this.txtModeloNFC.BackColor = System.Drawing.Color.White;
            this.txtModeloNFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModeloNFC.Location = new System.Drawing.Point(9, 39);
            this.txtModeloNFC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtModeloNFC.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtModeloNFC.Name = "txtModeloNFC";
            this.txtModeloNFC.Size = new System.Drawing.Size(95, 32);
            this.txtModeloNFC.TabIndex = 2;
            this.txtModeloNFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtModeloNFC.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            this.txtModeloNFC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumNFC_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(129, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 18);
            this.label4.TabIndex = 106;
            this.label4.Text = "Serie";
            // 
            // txtSerieNFC
            // 
            this.txtSerieNFC.BackColor = System.Drawing.Color.White;
            this.txtSerieNFC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerieNFC.Location = new System.Drawing.Point(110, 39);
            this.txtSerieNFC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSerieNFC.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtSerieNFC.Name = "txtSerieNFC";
            this.txtSerieNFC.Size = new System.Drawing.Size(95, 32);
            this.txtSerieNFC.TabIndex = 3;
            this.txtSerieNFC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSerieNFC.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtSerieNFC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumNFC_KeyPress);
            // 
            // clForn
            // 
            this.clForn.AutoSize = true;
            this.clForn.Location = new System.Drawing.Point(432, 18);
            this.clForn.Name = "clForn";
            this.clForn.Size = new System.Drawing.Size(89, 18);
            this.clForn.TabIndex = 97;
            this.clForn.Text = "Fornecedor";
            // 
            // txtFornecedor
            // 
            this.txtFornecedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFornecedor.Location = new System.Drawing.Point(436, 40);
            this.txtFornecedor.Margin = new System.Windows.Forms.Padding(5);
            this.txtFornecedor.MaxLength = 100;
            this.txtFornecedor.Name = "txtFornecedor";
            this.txtFornecedor.ReadOnly = true;
            this.txtFornecedor.Size = new System.Drawing.Size(253, 32);
            this.txtFornecedor.TabIndex = 5;
            // 
            // btnBuscarFornecedor
            // 
            this.btnBuscarFornecedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscarFornecedor.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarFornecedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarFornecedor.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarFornecedor.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarFornecedor.Location = new System.Drawing.Point(696, 41);
            this.btnBuscarFornecedor.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscarFornecedor.Name = "btnBuscarFornecedor";
            this.btnBuscarFornecedor.Size = new System.Drawing.Size(113, 27);
            this.btnBuscarFornecedor.TabIndex = 7;
            this.btnBuscarFornecedor.Text = "BUSCAR";
            this.btnBuscarFornecedor.UseVisualStyleBackColor = false;
            this.btnBuscarFornecedor.Click += new System.EventHandler(this.btnBuscarFornecedor_Click);
            // 
            // gbDatas
            // 
            this.gbDatas.Controls.Add(this.btnVerificaData);
            this.gbDatas.Controls.Add(this.dtEmissao);
            this.gbDatas.Controls.Add(this.dtChegada);
            this.gbDatas.Controls.Add(this.label8);
            this.gbDatas.Controls.Add(this.lblLinkVideo);
            this.gbDatas.Controls.Add(this.label7);
            this.gbDatas.Enabled = false;
            this.gbDatas.Location = new System.Drawing.Point(838, 33);
            this.gbDatas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbDatas.Name = "gbDatas";
            this.gbDatas.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbDatas.Size = new System.Drawing.Size(627, 83);
            this.gbDatas.TabIndex = 108;
            this.gbDatas.TabStop = false;
            // 
            // btnVerificaData
            // 
            this.btnVerificaData.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnVerificaData.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnVerificaData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVerificaData.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificaData.ForeColor = System.Drawing.Color.Black;
            this.btnVerificaData.Location = new System.Drawing.Point(507, 40);
            this.btnVerificaData.Margin = new System.Windows.Forms.Padding(5);
            this.btnVerificaData.Name = "btnVerificaData";
            this.btnVerificaData.Size = new System.Drawing.Size(122, 27);
            this.btnVerificaData.TabIndex = 113;
            this.btnVerificaData.Text = "VERIFICAR";
            this.btnVerificaData.UseVisualStyleBackColor = false;
            this.btnVerificaData.Click += new System.EventHandler(this.btnVerificaData_Click);
            // 
            // dtEmissao
            // 
            this.dtEmissao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtEmissao.Location = new System.Drawing.Point(11, 39);
            this.dtEmissao.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtEmissao.Name = "dtEmissao";
            this.dtEmissao.Size = new System.Drawing.Size(243, 32);
            this.dtEmissao.TabIndex = 9;
            // 
            // dtChegada
            // 
            this.dtChegada.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtChegada.Location = new System.Drawing.Point(262, 40);
            this.dtChegada.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtChegada.Name = "dtChegada";
            this.dtChegada.Size = new System.Drawing.Size(243, 32);
            this.dtChegada.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(259, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 18);
            this.label8.TabIndex = 59;
            this.label8.Text = "Data Chegada";
            // 
            // lblLinkVideo
            // 
            this.lblLinkVideo.AutoSize = true;
            this.lblLinkVideo.Location = new System.Drawing.Point(77, -19);
            this.lblLinkVideo.Name = "lblLinkVideo";
            this.lblLinkVideo.Size = new System.Drawing.Size(373, 18);
            this.lblLinkVideo.TabIndex = 112;
            this.lblLinkVideo.Text = "https://www.youtube.com/watch?v=QOneV9GYaJc";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 21);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 18);
            this.label7.TabIndex = 57;
            this.label7.Text = "Data Emissão";
            // 
            // gbProdutos
            // 
            this.gbProdutos.Controls.Add(this.btnAdicionar);
            this.gbProdutos.Controls.Add(this.label21);
            this.gbProdutos.Controls.Add(this.txtTotalItens);
            this.gbProdutos.Controls.Add(this.label20);
            this.gbProdutos.Controls.Add(this.txtUND);
            this.gbProdutos.Controls.Add(this.label18);
            this.gbProdutos.Controls.Add(this.label17);
            this.gbProdutos.Controls.Add(this.label16);
            this.gbProdutos.Controls.Add(this.txtCusto);
            this.gbProdutos.Controls.Add(this.txtDesconto);
            this.gbProdutos.Controls.Add(this.txtQtd);
            this.gbProdutos.Controls.Add(this.btnBuscarProduto);
            this.gbProdutos.Controls.Add(this.txtCodProduto);
            this.gbProdutos.Controls.Add(this.label5);
            this.gbProdutos.Controls.Add(this.label6);
            this.gbProdutos.Controls.Add(this.txtProduto);
            this.gbProdutos.Enabled = false;
            this.gbProdutos.Location = new System.Drawing.Point(19, 117);
            this.gbProdutos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbProdutos.Name = "gbProdutos";
            this.gbProdutos.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gbProdutos.Size = new System.Drawing.Size(1206, 83);
            this.gbProdutos.TabIndex = 113;
            this.gbProdutos.TabStop = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(910, 13);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 18);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total";
            // 
            // txtTotalItens
            // 
            this.txtTotalItens.BackColor = System.Drawing.Color.BurlyWood;
            this.txtTotalItens.Enabled = false;
            this.txtTotalItens.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtTotalItens.Location = new System.Drawing.Point(915, 34);
            this.txtTotalItens.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTotalItens.Name = "txtTotalItens";
            this.txtTotalItens.ReadOnly = true;
            this.txtTotalItens.Size = new System.Drawing.Size(145, 32);
            this.txtTotalItens.TabIndex = 27;
            this.txtTotalItens.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(537, 13);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 18);
            this.label20.TabIndex = 123;
            this.label20.Text = "Estoque";
            // 
            // txtUND
            // 
            this.txtUND.Enabled = false;
            this.txtUND.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtUND.Location = new System.Drawing.Point(534, 34);
            this.txtUND.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUND.Name = "txtUND";
            this.txtUND.Size = new System.Drawing.Size(71, 32);
            this.txtUND.TabIndex = 23;
            this.txtUND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(795, 15);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 18);
            this.label18.TabIndex = 121;
            this.label18.Text = "Desconto";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(707, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 18);
            this.label17.TabIndex = 120;
            this.label17.Text = "Custo";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(621, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 18);
            this.label16.TabIndex = 119;
            this.label16.Text = "Qtd";
            // 
            // txtCusto
            // 
            this.txtCusto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtCusto.Location = new System.Drawing.Point(680, 34);
            this.txtCusto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCusto.Name = "txtCusto";
            this.txtCusto.Size = new System.Drawing.Size(103, 32);
            this.txtCusto.TabIndex = 25;
            this.txtCusto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCusto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCusto_KeyPress);
            this.txtCusto.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // txtDesconto
            // 
            this.txtDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtDesconto.Location = new System.Drawing.Point(798, 34);
            this.txtDesconto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDesconto.Name = "txtDesconto";
            this.txtDesconto.Size = new System.Drawing.Size(106, 32);
            this.txtDesconto.TabIndex = 26;
            this.txtDesconto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDesconto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCusto_KeyPress);
            this.txtDesconto.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // txtQtd
            // 
            this.txtQtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtQtd.Location = new System.Drawing.Point(611, 34);
            this.txtQtd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtQtd.Name = "txtQtd";
            this.txtQtd.Size = new System.Drawing.Size(63, 32);
            this.txtQtd.TabIndex = 24;
            this.txtQtd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQtd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigo_KeyPress);
            this.txtQtd.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // btnBuscarProduto
            // 
            this.btnBuscarProduto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscarProduto.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarProduto.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarProduto.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarProduto.Location = new System.Drawing.Point(374, 35);
            this.btnBuscarProduto.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscarProduto.Name = "btnBuscarProduto";
            this.btnBuscarProduto.Size = new System.Drawing.Size(152, 27);
            this.btnBuscarProduto.TabIndex = 22;
            this.btnBuscarProduto.Text = "BUSCAR";
            this.btnBuscarProduto.UseVisualStyleBackColor = false;
            this.btnBuscarProduto.Click += new System.EventHandler(this.btnBuscarProduto_Click);
            // 
            // txtCodProduto
            // 
            this.txtCodProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodProduto.Location = new System.Drawing.Point(1, 34);
            this.txtCodProduto.Margin = new System.Windows.Forms.Padding(5);
            this.txtCodProduto.MaxLength = 100;
            this.txtCodProduto.Name = "txtCodProduto";
            this.txtCodProduto.Size = new System.Drawing.Size(102, 32);
            this.txtCodProduto.TabIndex = 20;
            this.txtCodProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodProduto.Enter += new System.EventHandler(this.txtCodFornecedor_Enter);
            this.txtCodProduto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigo_KeyPress);
            this.txtCodProduto.Leave += new System.EventHandler(this.txtCodProduto_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-3, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 18);
            this.label5.TabIndex = 113;
            this.label5.Text = "Cód Produto";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(109, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 18);
            this.label6.TabIndex = 112;
            this.label6.Text = "Produto";
            // 
            // txtProduto
            // 
            this.txtProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProduto.Location = new System.Drawing.Point(113, 34);
            this.txtProduto.Margin = new System.Windows.Forms.Padding(5);
            this.txtProduto.MaxLength = 100;
            this.txtProduto.Name = "txtProduto";
            this.txtProduto.ReadOnly = true;
            this.txtProduto.Size = new System.Drawing.Size(248, 32);
            this.txtProduto.TabIndex = 21;
            // 
            // Dgv
            // 
            this.Dgv.AllowUserToAddRows = false;
            this.Dgv.AllowUserToDeleteRows = false;
            this.Dgv.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Dgv.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.Dgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.Dgv.ColumnHeadersHeight = 29;
            this.Dgv.Location = new System.Drawing.Point(19, 205);
            this.Dgv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Dgv.Name = "Dgv";
            this.Dgv.ReadOnly = true;
            this.Dgv.RowHeadersWidth = 51;
            this.Dgv.RowTemplate.Height = 24;
            this.Dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv.Size = new System.Drawing.Size(1445, 226);
            this.Dgv.TabIndex = 800;
            this.Dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Dgv_CellContentClick);
            // 
            // btnFinaliza
            // 
            this.btnFinaliza.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFinaliza.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnFinaliza.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinaliza.Enabled = false;
            this.btnFinaliza.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinaliza.ForeColor = System.Drawing.Color.Black;
            this.btnFinaliza.Location = new System.Drawing.Point(1233, 151);
            this.btnFinaliza.Margin = new System.Windows.Forms.Padding(5);
            this.btnFinaliza.Name = "btnFinaliza";
            this.btnFinaliza.Size = new System.Drawing.Size(234, 32);
            this.btnFinaliza.TabIndex = 801;
            this.btnFinaliza.Text = "FINALIZAR COMPRA";
            this.btnFinaliza.UseVisualStyleBackColor = false;
            this.btnFinaliza.Click += new System.EventHandler(this.btnLiberarCondicao_Click);
            // 
            // lvContasPagar
            // 
            this.lvContasPagar.HideSelection = false;
            this.lvContasPagar.Location = new System.Drawing.Point(18, 683);
            this.lvContasPagar.Name = "lvContasPagar";
            this.lvContasPagar.Size = new System.Drawing.Size(1200, 97);
            this.lvContasPagar.TabIndex = 802;
            this.lvContasPagar.UseCompatibleStateImageBehavior = false;
            // 
            // clParcelas
            // 
            this.clParcelas.Text = "Nº";
            this.clParcelas.Width = 40;
            // 
            // clDias
            // 
            this.clDias.Text = "Vencimento";
            this.clDias.Width = 100;
            // 
            // clIdForma
            // 
            this.clIdForma.Text = "ID.F";
            // 
            // clForma
            // 
            this.clForma.Text = "Forma PG";
            this.clForma.Width = 475;
            // 
            // clPercentTotal
            // 
            this.clPercentTotal.Text = "%  sob Total";
            this.clPercentTotal.Width = 120;
            // 
            // clPreco
            // 
            this.clPreco.Text = "Valor da parcela";
            this.clPreco.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clPreco.Width = 150;
            // 
            // lvParcelas
            // 
            this.lvParcelas.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lvParcelas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clParcelas,
            this.clDias,
            this.clIdForma,
            this.clForma,
            this.clPercentTotal,
            this.clPreco});
            this.lvParcelas.FullRowSelect = true;
            this.lvParcelas.GridLines = true;
            this.lvParcelas.HideSelection = false;
            this.lvParcelas.Location = new System.Drawing.Point(18, 527);
            this.lvParcelas.Margin = new System.Windows.Forms.Padding(5);
            this.lvParcelas.Name = "lvParcelas";
            this.lvParcelas.Size = new System.Drawing.Size(1200, 148);
            this.lvParcelas.TabIndex = 85;
            this.lvParcelas.UseCompatibleStateImageBehavior = false;
            this.lvParcelas.View = System.Windows.Forms.View.Details;
            // 
            // FrmCadastroCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1495, 796);
            this.Controls.Add(this.lvContasPagar);
            this.Controls.Add(this.btnFinaliza);
            this.Controls.Add(this.Dgv);
            this.Controls.Add(this.gbProdutos);
            this.Controls.Add(this.gbDatas);
            this.Controls.Add(this.gbCondicao);
            this.Controls.Add(this.lvParcelas);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.GbChave);
            this.Margin = new System.Windows.Forms.Padding(5, 2, 5, 2);
            this.Name = "FrmCadastroCompra";
            this.Text = "Compras";
            this.Load += new System.EventHandler(this.FrmCadastroCompra_Load);
            this.Controls.SetChildIndex(this.GbChave, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.lvParcelas, 0);
            this.Controls.SetChildIndex(this.gbCondicao, 0);
            this.Controls.SetChildIndex(this.gbDatas, 0);
            this.Controls.SetChildIndex(this.gbProdutos, 0);
            this.Controls.SetChildIndex(this.Dgv, 0);
            this.Controls.SetChildIndex(this.btnFinaliza, 0);
            this.Controls.SetChildIndex(this.lvContasPagar, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.gbCondicao.ResumeLayout(false);
            this.gbCondicao.PerformLayout();
            this.GbChave.ResumeLayout(false);
            this.GbChave.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumNFC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModeloNFC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerieNFC)).EndInit();
            this.gbDatas.ResumeLayout(false);
            this.gbDatas.PerformLayout();
            this.gbProdutos.ResumeLayout(false);
            this.gbProdutos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label9;
        protected System.Windows.Forms.Button btnBuscarFornecedor;
        private System.Windows.Forms.Label lblLinkVideo;
        protected System.Windows.Forms.Button btnBuscarProduto;
        protected System.Windows.Forms.Button btnAdicionar;
        protected System.Windows.Forms.Button btnVerificar;
        protected System.Windows.Forms.GroupBox gbCondicao;
        protected System.Windows.Forms.GroupBox gbDatas;
        protected System.Windows.Forms.GroupBox gbProdutos;
        public System.Windows.Forms.GroupBox GbChave;
        protected System.Windows.Forms.Label lbCondicaoPg;
        protected System.Windows.Forms.TextBox txtCondicao;
        protected System.Windows.Forms.Label lbCodigoCondicao;
        protected System.Windows.Forms.TextBox txtCodCondicao;
        protected System.Windows.Forms.Label lbTotalNota;
        protected System.Windows.Forms.Label lbOutras;
        protected System.Windows.Forms.Label lbSeguro;
        protected System.Windows.Forms.Label lbFrete;
        protected System.Windows.Forms.Label clForn;
        protected System.Windows.Forms.TextBox txtFornecedor;
        protected System.Windows.Forms.Label Nome;
        protected System.Windows.Forms.NumericUpDown txtNumNFC;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.NumericUpDown txtModeloNFC;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.NumericUpDown txtSerieNFC;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.DateTimePicker dtChegada;
        protected System.Windows.Forms.DateTimePicker dtEmissao;
        protected System.Windows.Forms.TextBox txtCodProduto;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.TextBox txtProduto;
        protected System.Windows.Forms.Label label21;
        protected System.Windows.Forms.TextBox txtTotalItens;
        protected System.Windows.Forms.Label label20;
        protected System.Windows.Forms.TextBox txtUND;
        protected System.Windows.Forms.Label label18;
        protected System.Windows.Forms.Label label17;
        protected System.Windows.Forms.Label label16;
        protected System.Windows.Forms.TextBox txtCusto;
        protected System.Windows.Forms.TextBox txtDesconto;
        protected System.Windows.Forms.TextBox txtQtd;
        private System.Windows.Forms.TextBox txtSeguro;
        private System.Windows.Forms.TextBox txtOutras;
        private System.Windows.Forms.TextBox txtFrete;
        private System.Windows.Forms.TextBox txtTotalNota;
        protected System.Windows.Forms.Button btnVerificaData;
        public System.Windows.Forms.DataGridView Dgv;
        protected System.Windows.Forms.Button btnFinaliza;
        protected System.Windows.Forms.Button btnFinalizaCondicao;
        protected System.Windows.Forms.Button btnBuscarCondicao;
        private System.Windows.Forms.ListView lvContasPagar;
        protected System.Windows.Forms.Label lblTotalProds;
        private System.Windows.Forms.TextBox txtTotalProds;
        private System.Windows.Forms.ColumnHeader clParcelas;
        private System.Windows.Forms.ColumnHeader clDias;
        private System.Windows.Forms.ColumnHeader clIdForma;
        private System.Windows.Forms.ColumnHeader clForma;
        private System.Windows.Forms.ColumnHeader clPercentTotal;
        private System.Windows.Forms.ColumnHeader clPreco;
        protected System.Windows.Forms.ListView lvParcelas;
    }
}
