﻿namespace PP_2025
{
    partial class FrmConsultaContasAPagar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtData2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtData1 = new System.Windows.Forms.DateTimePicker();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.dgvContas = new System.Windows.Forms.DataGridView();
            this.txtForn = new System.Windows.Forms.NumericUpDown();
            this.txtModelo = new System.Windows.Forms.NumericUpDown();
            this.txtSerie = new System.Windows.Forms.NumericUpDown();
            this.txtNumero = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbM = new System.Windows.Forms.Label();
            this.btnBuscarFornecedor = new System.Windows.Forms.Button();
            this.btnBuscarTodos = new System.Windows.Forms.Button();
            this.txtFornecedor = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbDatas = new System.Windows.Forms.ComboBox();
            this.txtParcela = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAlterarConta = new System.Windows.Forms.Button();
            this.pnTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModelo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtParcela)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExcluir
            // 
            this.btnExcluir.Location = new System.Drawing.Point(-838, 486);
            this.toolTip1.SetToolTip(this.btnExcluir, "Selecione um item da lista para excluir");
            // 
            // btnAlterar
            // 
            this.btnAlterar.Location = new System.Drawing.Point(-835, 522);
            this.toolTip1.SetToolTip(this.btnAlterar, "Selecione um item da lista para alterar");
            // 
            // btnIncluir
            // 
            this.btnIncluir.Location = new System.Drawing.Point(-839, 511);
            this.toolTip1.SetToolTip(this.btnIncluir, "Incluir novo");
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(-1266, 109);
            this.listView1.Size = new System.Drawing.Size(119, 425);
            // 
            // pnTop
            // 
            this.pnTop.Location = new System.Drawing.Point(-1255, 59);
            this.pnTop.Size = new System.Drawing.Size(122, 39);
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.Location = new System.Drawing.Point(23, -99);
            this.toolTip1.SetToolTip(this.btnAtualizar, "Atualizar página");
            // 
            // panel3
            // 
            //this.panel3.Size = new System.Drawing.Size(821, 10);
            // 
            // btnAumentarFonte
            // 
            this.btnAumentarFonte.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAumentarFonte.FlatAppearance.BorderSize = 0;
            this.btnAumentarFonte.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAumentarFonte.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnAumentarFonte.Location = new System.Drawing.Point(37, 6);
            this.toolTip1.SetToolTip(this.btnAumentarFonte, "Aumenta a fonte da lista.");
            // 
            // btnDiminuirFonte
            // 
            this.btnDiminuirFonte.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDiminuirFonte.FlatAppearance.BorderSize = 0;
            this.btnDiminuirFonte.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDiminuirFonte.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDiminuirFonte.Location = new System.Drawing.Point(80, 6);
            this.toolTip1.SetToolTip(this.btnDiminuirFonte, "Diminui a fonte da lista");
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(13, 80);
            this.lblCodigo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCodigo.Size = new System.Drawing.Size(89, 18);
            this.lblCodigo.Text = "Fornecedor";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(741, 696);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(6);
            this.txtCodigo.Size = new System.Drawing.Size(0, 26);
            this.txtCodigo.Visible = false;
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(683, 693);
            this.btnSair.Margin = new System.Windows.Forms.Padding(6);
            this.btnSair.TabIndex = 40;
            // 
            // dtData2
            // 
            this.dtData2.Location = new System.Drawing.Point(535, 147);
            this.dtData2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtData2.Name = "dtData2";
            this.dtData2.Size = new System.Drawing.Size(236, 26);
            this.dtData2.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(532, 126);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 18);
            this.label1.TabIndex = 577;
            this.label1.Text = "Periodo : Fim da busca";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(289, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(184, 18);
            this.label3.TabIndex = 576;
            this.label3.Text = "Periodo : Inicio de busca";
            // 
            // dtData1
            // 
            this.dtData1.Location = new System.Drawing.Point(292, 147);
            this.dtData1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dtData1.Name = "dtData1";
            this.dtData1.Size = new System.Drawing.Size(235, 26);
            this.dtData1.TabIndex = 9;
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "A PAGAR",
            "PAGO",
            "CANCELADA",
            "TODOS"});
            this.cmbStatus.Location = new System.Drawing.Point(319, 95);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(191, 24);
            this.cmbStatus.TabIndex = 25;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(316, 77);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 579;
            this.label2.Text = "Status";
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdicionar.BackColor = System.Drawing.Color.Gold;
            this.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionar.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.Black;
            this.btnAdicionar.Location = new System.Drawing.Point(549, 693);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(5);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(123, 24);
            this.btnAdicionar.TabIndex = 35;
            this.btnAdicionar.Text = "PAGAR";
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // dgvContas
            // 
            this.dgvContas.AllowUserToAddRows = false;
            this.dgvContas.AllowUserToDeleteRows = false;
            this.dgvContas.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvContas.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvContas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContas.Location = new System.Drawing.Point(16, 181);
            this.dgvContas.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgvContas.Name = "dgvContas";
            this.dgvContas.ReadOnly = true;
            this.dgvContas.RowHeadersVisible = false;
            this.dgvContas.RowHeadersWidth = 51;
            this.dgvContas.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("MS Reference Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvContas.RowTemplate.Height = 24;
            this.dgvContas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContas.Size = new System.Drawing.Size(755, 505);
            this.dgvContas.TabIndex = 581;
            this.dgvContas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContas_CellClick);
            this.dgvContas.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContas_CellContentDoubleClick);
            this.dgvContas.Resize += new System.EventHandler(this.FrmConsultaContasAPagar_Resize);
            // 
            // txtForn
            // 
            this.txtForn.BackColor = System.Drawing.Color.White;
            this.txtForn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForn.Location = new System.Drawing.Point(417, 43);
            this.txtForn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtForn.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtForn.Name = "txtForn";
            this.txtForn.Size = new System.Drawing.Size(95, 32);
            this.txtForn.TabIndex = 5;
            this.txtForn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtModelo
            // 
            this.txtModelo.BackColor = System.Drawing.Color.White;
            this.txtModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModelo.Location = new System.Drawing.Point(116, 43);
            this.txtModelo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtModelo.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(95, 32);
            this.txtModelo.TabIndex = 2;
            this.txtModelo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtSerie
            // 
            this.txtSerie.BackColor = System.Drawing.Color.White;
            this.txtSerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerie.Location = new System.Drawing.Point(216, 43);
            this.txtSerie.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSerie.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtSerie.Name = "txtSerie";
            this.txtSerie.Size = new System.Drawing.Size(95, 32);
            this.txtSerie.TabIndex = 3;
            this.txtSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumero
            // 
            this.txtNumero.BackColor = System.Drawing.Color.White;
            this.txtNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumero.Location = new System.Drawing.Point(17, 43);
            this.txtNumero.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNumero.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(95, 32);
            this.txtNumero.TabIndex = 1;
            this.txtNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(417, 25);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 18);
            this.label5.TabIndex = 593;
            this.label5.Text = "C. Fornecedor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(13, 25);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 18);
            this.label4.TabIndex = 592;
            this.label4.Text = "Número";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(113, 25);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 18);
            this.label6.TabIndex = 591;
            this.label6.Text = "Modelo";
            // 
            // lbM
            // 
            this.lbM.AutoSize = true;
            this.lbM.ForeColor = System.Drawing.Color.Black;
            this.lbM.Location = new System.Drawing.Point(213, 25);
            this.lbM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbM.Name = "lbM";
            this.lbM.Size = new System.Drawing.Size(44, 18);
            this.lbM.TabIndex = 590;
            this.lbM.Text = "Série";
            // 
            // btnBuscarFornecedor
            // 
            this.btnBuscarFornecedor.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarFornecedor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarFornecedor.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarFornecedor.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarFornecedor.Location = new System.Drawing.Point(519, 43);
            this.btnBuscarFornecedor.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscarFornecedor.Name = "btnBuscarFornecedor";
            this.btnBuscarFornecedor.Size = new System.Drawing.Size(113, 31);
            this.btnBuscarFornecedor.TabIndex = 6;
            this.btnBuscarFornecedor.Text = "BUSCAR";
            this.btnBuscarFornecedor.UseVisualStyleBackColor = false;
            this.btnBuscarFornecedor.Click += new System.EventHandler(this.btnBuscarFornecedor_Click);
            // 
            // btnBuscarTodos
            // 
            this.btnBuscarTodos.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarTodos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarTodos.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarTodos.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarTodos.Location = new System.Drawing.Point(519, 96);
            this.btnBuscarTodos.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscarTodos.Name = "btnBuscarTodos";
            this.btnBuscarTodos.Size = new System.Drawing.Size(113, 27);
            this.btnBuscarTodos.TabIndex = 30;
            this.btnBuscarTodos.Text = "BUSCAR";
            this.btnBuscarTodos.UseVisualStyleBackColor = false;
            this.btnBuscarTodos.Click += new System.EventHandler(this.btnBuscarTodos_Click);
            // 
            // txtFornecedor
            // 
            this.txtFornecedor.Location = new System.Drawing.Point(17, 96);
            this.txtFornecedor.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtFornecedor.Name = "txtFornecedor";
            this.txtFornecedor.Size = new System.Drawing.Size(294, 26);
            this.txtFornecedor.TabIndex = 7;
            this.txtFornecedor.TextChanged += new System.EventHandler(this.txtFornecedor_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(12, 127);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 18);
            this.label8.TabIndex = 602;
            this.label8.Text = "Tipo de data";
            // 
            // cbDatas
            // 
            this.cbDatas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDatas.FormattingEnabled = true;
            this.cbDatas.Items.AddRange(new object[] {
            "EMISSAO",
            "VENCIMENTO",
            "BAIXA"});
            this.cbDatas.Location = new System.Drawing.Point(15, 149);
            this.cbDatas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbDatas.Name = "cbDatas";
            this.cbDatas.Size = new System.Drawing.Size(269, 24);
            this.cbDatas.TabIndex = 8;
            // 
            // txtParcela
            // 
            this.txtParcela.BackColor = System.Drawing.Color.White;
            this.txtParcela.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtParcela.Location = new System.Drawing.Point(316, 43);
            this.txtParcela.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtParcela.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.txtParcela.Name = "txtParcela";
            this.txtParcela.Size = new System.Drawing.Size(95, 32);
            this.txtParcela.TabIndex = 4;
            this.txtParcela.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(312, 25);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 18);
            this.label7.TabIndex = 604;
            this.label7.Text = "Nº Parcela";
            // 
            // btnAlterarConta
            // 
            this.btnAlterarConta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAlterarConta.BackColor = System.Drawing.Color.Goldenrod;
            this.btnAlterarConta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterarConta.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterarConta.ForeColor = System.Drawing.Color.Black;
            this.btnAlterarConta.Location = new System.Drawing.Point(417, 693);
            this.btnAlterarConta.Margin = new System.Windows.Forms.Padding(5);
            this.btnAlterarConta.Name = "btnAlterarConta";
            this.btnAlterarConta.Size = new System.Drawing.Size(122, 24);
            this.btnAlterarConta.TabIndex = 605;
            this.btnAlterarConta.Text = "ALTERAR";
            this.btnAlterarConta.UseVisualStyleBackColor = false;
            this.btnAlterarConta.Click += new System.EventHandler(this.btnAlterarConta_Click);
            // 
            // FrmConsultaContasAPagar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(821, 737);
            this.Controls.Add(this.btnAlterarConta);
            this.Controls.Add(this.txtParcela);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbDatas);
            this.Controls.Add(this.txtFornecedor);
            this.Controls.Add(this.btnBuscarTodos);
            this.Controls.Add(this.btnBuscarFornecedor);
            this.Controls.Add(this.txtForn);
            this.Controls.Add(this.txtModelo);
            this.Controls.Add(this.txtSerie);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbM);
            this.Controls.Add(this.btnAdicionar);
            this.Controls.Add(this.dgvContas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.dtData2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtData1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.Name = "FrmConsultaContasAPagar";
            this.Text = "Listar contas a pagar";
            this.Load += new System.EventHandler(this.FrmConsultaContasAPagar_Load);
            this.Resize += new System.EventHandler(this.FrmConsultaContasAPagar_Resize);
            //this.Controls.SetChildIndex(this.btnBuscar, 0);
            //this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.btnExcluir, 0);
            this.Controls.SetChildIndex(this.btnAlterar, 0);
            this.Controls.SetChildIndex(this.btnIncluir, 0);
            this.Controls.SetChildIndex(this.listView1, 0);
            this.Controls.SetChildIndex(this.pnTop, 0);
            this.Controls.SetChildIndex(this.btnAtualizar, 0);
            this.Controls.SetChildIndex(this.dtData1, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.dtData2, 0);
            this.Controls.SetChildIndex(this.cmbStatus, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.dgvContas, 0);
            this.Controls.SetChildIndex(this.btnAdicionar, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.lbM, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txtNumero, 0);
            this.Controls.SetChildIndex(this.txtSerie, 0);
            this.Controls.SetChildIndex(this.txtModelo, 0);
            this.Controls.SetChildIndex(this.txtForn, 0);
            this.Controls.SetChildIndex(this.btnBuscarFornecedor, 0);
            this.Controls.SetChildIndex(this.btnBuscarTodos, 0);
            this.Controls.SetChildIndex(this.txtFornecedor, 0);
            this.Controls.SetChildIndex(this.cbDatas, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.txtParcela, 0);
            this.Controls.SetChildIndex(this.btnAlterarConta, 0);
            this.pnTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtForn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtModelo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSerie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNumero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtParcela)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        protected System.Windows.Forms.DateTimePicker dtData2;
        protected System.Windows.Forms.Label label1;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.DateTimePicker dtData1;
        private System.Windows.Forms.ComboBox cmbStatus;
        protected System.Windows.Forms.Label label2;
        protected System.Windows.Forms.Button btnAdicionar;
        protected System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.DataGridView dgvContas;
        protected System.Windows.Forms.Panel panel3;
        protected System.Windows.Forms.NumericUpDown txtForn;
        protected System.Windows.Forms.NumericUpDown txtModelo;
        protected System.Windows.Forms.NumericUpDown txtSerie;
        protected System.Windows.Forms.NumericUpDown txtNumero;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.Label lbM;
        protected System.Windows.Forms.Button btnBuscarFornecedor;
        protected System.Windows.Forms.Button btnBuscarTodos;
        private System.Windows.Forms.TextBox txtFornecedor;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.ComboBox cbDatas;
        protected System.Windows.Forms.NumericUpDown txtParcela;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.Button btnAlterarConta;
    }
}
