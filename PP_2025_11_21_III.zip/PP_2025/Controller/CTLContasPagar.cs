﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace PP_2025
{
    public class CTLContasPagar
    {
        private DALContasPagar contasPagarDAL = new DALContasPagar();

        public string AdicionarContaPagar(ContasPagar contaPagar)
        {
            return contasPagarDAL.AdicionarContaPagar(contaPagar);
        }

        public string AtualizarContaPagar(ContasPagar contaPagar)
        {
            return contasPagarDAL.AtualizarContaPagar(contaPagar);
        }
        public string Quitar(ContasPagar contaPagar)
        {
            return contasPagarDAL.Quitar(contaPagar);
        }
        public bool CancelarParcela(ContasPagar contaPagar)
        {
            return contasPagarDAL.CancelarParcela(contaPagar);
        }
        public bool ExcluirContaPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor, int numParcela)
        {
            return contasPagarDAL.ExcluirContaPagar(numNFC, modeloNFC, serieNFC, numFornecedor, numParcela);
        }

        public ContasPagar BuscarContaPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor, int numParcela)
        {
            return contasPagarDAL.BuscarContaPagar(numNFC, modeloNFC, serieNFC, numFornecedor, numParcela);
        }
        public List<ContasPagar> BuscarContasPorNomeFornecedor(string nome)
        {
            return contasPagarDAL.BuscarContasPorNomeFornecedor(nome);
        }
        public List<ContasPagar> BuscarContas(int numNFC, int modeloNFC, int serieNFC, int numFornecedor, int ParcelaNFC)
        {
            return contasPagarDAL.BuscarContas(numNFC, modeloNFC, serieNFC, numFornecedor, ParcelaNFC);
        }
        public bool VerificarExistenciaDeCompra(int numNFC, int modeloNFC, int serieNFC, int numFornecedor)
        {
            return contasPagarDAL.VerificarExistenciaDeNota(numNFC, modeloNFC, serieNFC, numFornecedor);
        }

        public string VerificarContasAPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor)
        {
            List<ContasPagar> contasVerificadas = contasPagarDAL.ListarContasAPagarPorNumero(numNFC, modeloNFC, serieNFC, numFornecedor);

            foreach (ContasPagar conta in contasVerificadas)
            {
                if (conta.Situacao != "PAGO")
                {
                    return "NOT";
                }
            }
            return "OK";
        }
        public List<ContasPagar> VerificarListaContasAPagar(int numNFC, int modeloNFC, int serieNFC, int numFornecedor)
        {
            // Chama o método DAL para listar as contas a pagar com base nos parâmetros fornecidos
            List<ContasPagar> contasVerificadas = contasPagarDAL.ListarContasAPagarPorNumero(numNFC, modeloNFC, serieNFC, numFornecedor);

            // Cria uma nova lista para armazenar as contas que não estão pagas
            List<ContasPagar> contasNaoPagas = new List<ContasPagar>();

            // Itera sobre a lista de contas verificadas
            foreach (ContasPagar conta in contasVerificadas)
            {
                // Se a conta não estiver paga, adiciona à lista de contas não pagas
                if (conta.Situacao != "PAGO")
                {
                    contasNaoPagas.Add(conta);
                }
            }

            // Retorna a lista de contas não pagas
            return contasNaoPagas;
        }


        public List<ContasPagar> ListarContasPagar(string status)
        {
            return contasPagarDAL.ListarContasPagar(status);
        }
        public List<ContasPagar> ListarContasPagarComData(string status, DateTime DataInicio, DateTime DataFim, string TipoData)
        {
            return contasPagarDAL.ListarContasPagarComData(status, DataInicio, DataFim, TipoData);
        }
        public List<ContasPagar> ListarTodasContasPagar()
        {
            return contasPagarDAL.ListarTodasContasPagar();
        }


        public void Incluir()
        {
            FrmCadastroContaPagar frmCadastroContasPagar = new FrmCadastroContaPagar();
            frmCadastroContasPagar.Text = "Contas a Pagar";
            frmCadastroContasPagar.ShowDialog();
        }

        public void Alterar(ContasPagar contaPagar)
        {
            if (contaPagar != null)
            {
                FrmCadastroContaPagar frmCadastroContasPagar = new FrmCadastroContaPagar();
                frmCadastroContasPagar.ConhecaObj(contaPagar);
                frmCadastroContasPagar.Text = "Contas a Pagar";
                frmCadastroContasPagar.CarregarCampos();
                frmCadastroContasPagar.ShowDialog();
            }

        }
        public void AlterarDados(ContasPagar contaPagar)
        {
            if (contaPagar != null)
            {
                FrmCadastroContaPagar frmCadastroContasPagar = new FrmCadastroContaPagar();
                frmCadastroContasPagar.ConhecaObj(contaPagar);
                frmCadastroContasPagar.Text = "Alteração de contas a pagar";
                frmCadastroContasPagar.CarregarCampos();
                frmCadastroContasPagar.btnSalvar.Text = "ALTERAR";
                frmCadastroContasPagar.btnSalvar.BackColor = Color.BurlyWood;
                frmCadastroContasPagar.txtTotalPago.Enabled = false;
                frmCadastroContasPagar.dtBaixa.Enabled = false;
                frmCadastroContasPagar.ShowDialog();
            }

        }


        public void Excluir(ContasPagar contaPagar)
        {
            // Implemente a lógica para abrir o formulário de exclusão de contas a pagar
        }

        public void Visualizar(ContasPagar contaPagar)
        {
            if (contaPagar != null)
            {
                FrmCadastroContaPagar frmCadastroContasPagar = new FrmCadastroContaPagar();
                frmCadastroContasPagar.ConhecaObj(contaPagar);
                frmCadastroContasPagar.Text = "Contas a Pagar";
                frmCadastroContasPagar.CarregarCampos();
                frmCadastroContasPagar.BloquearCampos();
                frmCadastroContasPagar.ShowDialog();
            }
        }
    }
}
