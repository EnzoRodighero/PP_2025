﻿using System.Collections.Generic;

namespace PP_2025
{
    public class CTLItemVenda
    {
        private DALItemVenda itensVendaDAL = new DALItemVenda();

        public bool AdicionarItemVenda(ItemVenda itemVenda)
        {
            return itensVendaDAL.AdicionarItemVenda(itemVenda);
        }
        public ItemVenda BuscarItemVendaPorChave(int numNF, int modeloNF, int serieNF, int idCliente, int idProduto, string tipoItem)
        {
            return itensVendaDAL.BuscarItemVendaPorChave(numNF, modeloNF, serieNF, idCliente, idProduto, tipoItem);
        }
        public List<ItemVenda> BuscarItensVendaPorChave2(int numNF, int modeloNF, int serieNF)
        {
            return itensVendaDAL.BuscarItensVendaPorChave2(numNF, modeloNF, serieNF);
        }
        public List<ItemVenda> ListarItensVenda()
        {
            return itensVendaDAL.ListarItensVenda();
        }
    }
}
