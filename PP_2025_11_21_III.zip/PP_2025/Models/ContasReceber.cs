﻿using System;

namespace PP_2025
{
    public class ContasReceber : Pai
    {
        private int _numNFC;
        private int _modeloNFC;
        private int _serieNFC;
        private int _numParcela;
        private Clientes _cliente;
        private CondicaoPagamento _condicao;
        private decimal _valor;
        private string _situacao;
        private DateTime _dataBaixa;
        private DateTime _dataVencimento;
        private DateTime _dataCriacao;
        private DateTime _dataUltAlteracao;
        private decimal _pagamento;
        private FormaPagamento _formaPagamento;
        private decimal _taxa;
        private decimal _multa;
        private decimal _desconto;

        public ContasReceber()
        {
            _numNFC = 0;
            _modeloNFC = 0;
            _serieNFC = 0;
            _numParcela = 0;
            _cliente = new Clientes();
            _condicao = new CondicaoPagamento();
            _valor = 0m;
            _situacao = "";
            _dataBaixa = DateTime.Now;
            _dataVencimento = DateTime.Now;
            _dataCriacao = DateTime.Now;
            _dataUltAlteracao = DateTime.Now;
            _pagamento = 0m;
            _formaPagamento = new FormaPagamento();
        }

        public ContasReceber(FormaPagamento forma, decimal pagamento, int numNFC, int modeloNFC, int serieNFC, int numParcela, Clientes cliente, CondicaoPagamento condicao,
            decimal valor, string situacao, DateTime dataBaixa, DateTime dataVencimento, DateTime dataCriacao, DateTime dataUltAlteracao
            , decimal taxa, decimal multa, decimal desconto)
        {
            _numNFC = numNFC;
            _modeloNFC = modeloNFC;
            _serieNFC = serieNFC;
            _numParcela = numParcela;
            _cliente = cliente;
            _condicao = condicao;
            _valor = valor;
            _situacao = situacao;
            _dataBaixa = dataBaixa;
            _dataVencimento = dataVencimento;
            _dataCriacao = dataCriacao;
            _dataUltAlteracao = dataUltAlteracao;
            _pagamento = pagamento;
            _formaPagamento = forma;
            _taxa = taxa;
            _multa = multa;
            _desconto = desconto;
        }
        public decimal Taxa
        {
            get => _taxa;
            set => _taxa = value;
        }
        public decimal Multa
        {
            get => _multa;
            set => _multa = value;
        }
        public decimal Desconto
        {
            get => _desconto;
            set => _desconto = value;
        }
        public decimal Pagamento
        {
            get => _pagamento;
            set => _pagamento = value;
        }
        public int NumNFC
        {
            get => _numNFC;
            set => _numNFC = value;
        }

        public int ModeloNFC
        {
            get => _modeloNFC;
            set => _modeloNFC = value;
        }

        public int SerieNFC
        {
            get => _serieNFC;
            set => _serieNFC = value;
        }

        public int NumParcela
        {
            get => _numParcela;
            set => _numParcela = value;
        }

        public Clientes Cliente
        {
            get => _cliente;
            set => _cliente = value;
        }

        public FormaPagamento FormaPagamento
        {
            get => _formaPagamento;
            set => _formaPagamento = value;
        }
        public CondicaoPagamento Condicao
        {
            get => _condicao;
            set => _condicao = value;
        }

        public decimal Valor
        {
            get => _valor;
            set => _valor = value;
        }

        public string Situacao
        {
            get => _situacao;
            set => _situacao = value;
        }

        public DateTime DataBaixa
        {
            get => _dataBaixa;
            set => _dataBaixa = value;
        }

        public DateTime DataVencimento
        {
            get => _dataVencimento;
            set => _dataVencimento = value;
        }

        public DateTime DataUltAlteracao
        {
            get => _dataUltAlteracao;
            set => _dataUltAlteracao = value;
        }
    }
}
