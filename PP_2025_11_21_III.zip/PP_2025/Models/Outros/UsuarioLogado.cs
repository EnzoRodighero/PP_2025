﻿using PP_2025;

namespace PP_2025
{
    public static class UsuarioLogado
    {
     
    }
}
