﻿namespace PP_2025
{
    partial class FrmCadastroVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pnCliente = new System.Windows.Forms.Panel();
            this.lblCodCliente = new System.Windows.Forms.Label();
            this.txtCodCliente = new System.Windows.Forms.TextBox();
            this.btnBuscarCliente = new System.Windows.Forms.Button();
            this.clForn = new System.Windows.Forms.Label();
            this.txtCliente = new System.Windows.Forms.TextBox();
            this.txtCPFeCNPJ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pnVendas = new System.Windows.Forms.Panel();
            this.pnProd = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUnitario = new System.Windows.Forms.TextBox();
            this.txtProdTotal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDesconto = new System.Windows.Forms.TextBox();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.txtProduto = new System.Windows.Forms.TextBox();
            this.lblProduto = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnBuscarProduto = new System.Windows.Forms.Button();
            this.txtQtd = new System.Windows.Forms.TextBox();
            this.txtCodProduto = new System.Windows.Forms.TextBox();
            this.lblCod = new System.Windows.Forms.Label();
            this.lbSexo = new System.Windows.Forms.Label();
            this.cmbProdServ = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtTotalNota = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DgItensVenda = new System.Windows.Forms.DataGridView();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnCancelarF5 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lvParcelas = new System.Windows.Forms.ListView();
            this.clParcelas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDias = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clIdForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clForma = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPercentTotal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clPreco = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbCondicao = new System.Windows.Forms.GroupBox();
            this.btnBuscarCondicao = new System.Windows.Forms.Button();
            this.txtFrete = new System.Windows.Forms.TextBox();
            this.txtSeguro = new System.Windows.Forms.TextBox();
            this.txtOutras = new System.Windows.Forms.TextBox();
            this.lbOutras = new System.Windows.Forms.Label();
            this.lbSeguro = new System.Windows.Forms.Label();
            this.lbFrete = new System.Windows.Forms.Label();
            this.lbCondicaoPg = new System.Windows.Forms.Label();
            this.txtCondicao = new System.Windows.Forms.TextBox();
            this.lbCodigoCondicao = new System.Windows.Forms.Label();
            this.txtCodCondicao = new System.Windows.Forms.TextBox();
            this.btnFinalizaCondicao = new System.Windows.Forms.Button();
            this.btnFinaliza = new System.Windows.Forms.Button();
            this.panel5.SuspendLayout();
            this.pnCliente.SuspendLayout();
            this.pnVendas.SuspendLayout();
            this.pnProd.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgItensVenda)).BeginInit();
            this.gbCondicao.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Location = new System.Drawing.Point(1, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1288, 85);
            this.panel2.TabIndex = 553;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel5.BackColor = System.Drawing.Color.Silver;
            this.panel5.Controls.Add(this.pnCliente);
            this.panel5.Controls.Add(this.pnVendas);
            this.panel5.Location = new System.Drawing.Point(1, 97);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(314, 557);
            this.panel5.TabIndex = 555;
            // 
            // pnCliente
            // 
            this.pnCliente.Controls.Add(this.lblCodCliente);
            this.pnCliente.Controls.Add(this.txtCodCliente);
            this.pnCliente.Controls.Add(this.btnBuscarCliente);
            this.pnCliente.Controls.Add(this.clForn);
            this.pnCliente.Controls.Add(this.txtCliente);
            this.pnCliente.Controls.Add(this.txtCPFeCNPJ);
            this.pnCliente.Controls.Add(this.label6);
            this.pnCliente.Location = new System.Drawing.Point(2, 6);
            this.pnCliente.Name = "pnCliente";
            this.pnCliente.Size = new System.Drawing.Size(309, 100);
            this.pnCliente.TabIndex = 611;
            // 
            // lblCodCliente
            // 
            this.lblCodCliente.AutoSize = true;
            this.lblCodCliente.Location = new System.Drawing.Point(10, 52);
            this.lblCodCliente.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCodCliente.Name = "lblCodCliente";
            this.lblCodCliente.Size = new System.Drawing.Size(51, 16);
            this.lblCodCliente.TabIndex = 576;
            this.lblCodCliente.Text = "Código";
            // 
            // txtCodCliente
            // 
            this.txtCodCliente.Enabled = false;
            this.txtCodCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCliente.Location = new System.Drawing.Point(13, 69);
            this.txtCodCliente.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodCliente.MaxLength = 100;
            this.txtCodCliente.Name = "txtCodCliente";
            this.txtCodCliente.ReadOnly = true;
            this.txtCodCliente.Size = new System.Drawing.Size(90, 32);
            this.txtCodCliente.TabIndex = 20;
            this.txtCodCliente.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnBuscarCliente
            // 
            this.btnBuscarCliente.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscarCliente.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCliente.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarCliente.Location = new System.Drawing.Point(202, 18);
            this.btnBuscarCliente.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarCliente.Name = "btnBuscarCliente";
            this.btnBuscarCliente.Size = new System.Drawing.Size(99, 27);
            this.btnBuscarCliente.TabIndex = 15;
            this.btnBuscarCliente.Text = "BUSCAR";
            this.toolTip1.SetToolTip(this.btnBuscarCliente, "Busque um CPF, CNPJ ou RG, se o formulário estiver vazio abrirá uma janela de bus" +
        "ca.");
            this.btnBuscarCliente.UseVisualStyleBackColor = false;
            this.btnBuscarCliente.Click += new System.EventHandler(this.btnBuscarCliente_Click);
            // 
            // clForn
            // 
            this.clForn.AutoSize = true;
            this.clForn.Location = new System.Drawing.Point(106, 52);
            this.clForn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.clForn.Name = "clForn";
            this.clForn.Size = new System.Drawing.Size(48, 16);
            this.clForn.TabIndex = 573;
            this.clForn.Text = "Cliente";
            // 
            // txtCliente
            // 
            this.txtCliente.Enabled = false;
            this.txtCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCliente.Location = new System.Drawing.Point(109, 69);
            this.txtCliente.Margin = new System.Windows.Forms.Padding(4);
            this.txtCliente.MaxLength = 100;
            this.txtCliente.Name = "txtCliente";
            this.txtCliente.ReadOnly = true;
            this.txtCliente.Size = new System.Drawing.Size(192, 32);
            this.txtCliente.TabIndex = 25;
            // 
            // txtCPFeCNPJ
            // 
            this.txtCPFeCNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCPFeCNPJ.Location = new System.Drawing.Point(13, 18);
            this.txtCPFeCNPJ.Margin = new System.Windows.Forms.Padding(4);
            this.txtCPFeCNPJ.MaxLength = 100;
            this.txtCPFeCNPJ.Name = "txtCPFeCNPJ";
            this.txtCPFeCNPJ.Size = new System.Drawing.Size(185, 32);
            this.txtCPFeCNPJ.TabIndex = 10;
            this.txtCPFeCNPJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.txtCPFeCNPJ, "Aperte enter para buscar.");
            this.txtCPFeCNPJ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCPFeCNPJ_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 16);
            this.label6.TabIndex = 574;
            this.label6.Text = "CPF / CNPJ / RG";
            // 
            // pnVendas
            // 
            this.pnVendas.Controls.Add(this.pnProd);
            this.pnVendas.Controls.Add(this.lbSexo);
            this.pnVendas.Controls.Add(this.cmbProdServ);
            this.pnVendas.Enabled = false;
            this.pnVendas.Location = new System.Drawing.Point(4, 109);
            this.pnVendas.Name = "pnVendas";
            this.pnVendas.Size = new System.Drawing.Size(307, 442);
            this.pnVendas.TabIndex = 610;
            // 
            // pnProd
            // 
            this.pnProd.Controls.Add(this.label5);
            this.pnProd.Controls.Add(this.txtUnitario);
            this.pnProd.Controls.Add(this.txtProdTotal);
            this.pnProd.Controls.Add(this.label7);
            this.pnProd.Controls.Add(this.label4);
            this.pnProd.Controls.Add(this.txtDesconto);
            this.pnProd.Controls.Add(this.btnAdicionar);
            this.pnProd.Controls.Add(this.txtProduto);
            this.pnProd.Controls.Add(this.lblProduto);
            this.pnProd.Controls.Add(this.label16);
            this.pnProd.Controls.Add(this.btnBuscarProduto);
            this.pnProd.Controls.Add(this.txtQtd);
            this.pnProd.Controls.Add(this.txtCodProduto);
            this.pnProd.Controls.Add(this.lblCod);
            this.pnProd.Enabled = false;
            this.pnProd.Location = new System.Drawing.Point(3, 56);
            this.pnProd.Name = "pnProd";
            this.pnProd.Size = new System.Drawing.Size(304, 383);
            this.pnProd.TabIndex = 621;
            this.pnProd.Paint += new System.Windows.Forms.PaintEventHandler(this.pnProd_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 98);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 16);
            this.label5.TabIndex = 637;
            this.label5.Text = "R$ Unitário";
            // 
            // txtUnitario
            // 
            this.txtUnitario.Enabled = false;
            this.txtUnitario.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtUnitario.ForeColor = System.Drawing.Color.Black;
            this.txtUnitario.Location = new System.Drawing.Point(11, 115);
            this.txtUnitario.Margin = new System.Windows.Forms.Padding(2);
            this.txtUnitario.Name = "txtUnitario";
            this.txtUnitario.ReadOnly = true;
            this.txtUnitario.Size = new System.Drawing.Size(140, 32);
            this.txtUnitario.TabIndex = 60;
            this.txtUnitario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtProdTotal
            // 
            this.txtProdTotal.Enabled = false;
            this.txtProdTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProdTotal.ForeColor = System.Drawing.Color.Black;
            this.txtProdTotal.Location = new System.Drawing.Point(157, 115);
            this.txtProdTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtProdTotal.MaxLength = 100;
            this.txtProdTotal.Name = "txtProdTotal";
            this.txtProdTotal.ReadOnly = true;
            this.txtProdTotal.Size = new System.Drawing.Size(140, 32);
            this.txtProdTotal.TabIndex = 65;
            this.txtProdTotal.Text = "0";
            this.txtProdTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(154, 98);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 16);
            this.label7.TabIndex = 636;
            this.label7.Text = "R$ Total";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 50);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 632;
            this.label4.Text = "Desconto";
            // 
            // txtDesconto
            // 
            this.txtDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtDesconto.Location = new System.Drawing.Point(11, 67);
            this.txtDesconto.Margin = new System.Windows.Forms.Padding(2);
            this.txtDesconto.Name = "txtDesconto";
            this.txtDesconto.Size = new System.Drawing.Size(57, 32);
            this.txtDesconto.TabIndex = 50;
            this.txtDesconto.Text = "0";
            this.txtDesconto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDesconto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDesconto_KeyPress);
            this.txtDesconto.Leave += new System.EventHandler(this.txtDesconto_Leave);
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAdicionar.BackColor = System.Drawing.Color.Gold;
            this.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.Black;
            this.btnAdicionar.Location = new System.Drawing.Point(11, 151);
            this.btnAdicionar.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(286, 28);
            this.btnAdicionar.TabIndex = 70;
            this.btnAdicionar.Text = "ADICIONAR";
            this.toolTip1.SetToolTip(this.btnAdicionar, "Adicionar novo item a lista de compras.");
            this.btnAdicionar.UseVisualStyleBackColor = false;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // txtProduto
            // 
            this.txtProduto.Enabled = false;
            this.txtProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProduto.Location = new System.Drawing.Point(74, 66);
            this.txtProduto.Margin = new System.Windows.Forms.Padding(4);
            this.txtProduto.MaxLength = 100;
            this.txtProduto.Name = "txtProduto";
            this.txtProduto.Size = new System.Drawing.Size(222, 32);
            this.txtProduto.TabIndex = 55;
            // 
            // lblProduto
            // 
            this.lblProduto.AutoSize = true;
            this.lblProduto.Location = new System.Drawing.Point(71, 49);
            this.lblProduto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblProduto.Name = "lblProduto";
            this.lblProduto.Size = new System.Drawing.Size(54, 16);
            this.lblProduto.TabIndex = 631;
            this.lblProduto.Text = "Produto";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 2);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(28, 16);
            this.label16.TabIndex = 630;
            this.label16.Text = "Qtd";
            // 
            // btnBuscarProduto
            // 
            this.btnBuscarProduto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscarProduto.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarProduto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarProduto.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarProduto.Location = new System.Drawing.Point(172, 19);
            this.btnBuscarProduto.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarProduto.Name = "btnBuscarProduto";
            this.btnBuscarProduto.Size = new System.Drawing.Size(125, 32);
            this.btnBuscarProduto.TabIndex = 45;
            this.btnBuscarProduto.Text = "BUSCAR";
            this.toolTip1.SetToolTip(this.btnBuscarProduto, "Buscar produtos ou serviços.");
            this.btnBuscarProduto.UseVisualStyleBackColor = false;
            this.btnBuscarProduto.Click += new System.EventHandler(this.btnBuscarProduto_Click);
            // 
            // txtQtd
            // 
            this.txtQtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtQtd.Location = new System.Drawing.Point(11, 19);
            this.txtQtd.Margin = new System.Windows.Forms.Padding(2);
            this.txtQtd.Name = "txtQtd";
            this.txtQtd.Size = new System.Drawing.Size(57, 32);
            this.txtQtd.TabIndex = 35;
            this.txtQtd.Text = "1";
            this.txtQtd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtQtd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQtd_KeyPress);
            this.txtQtd.Leave += new System.EventHandler(this.txtQtd_Leave);
            // 
            // txtCodProduto
            // 
            this.txtCodProduto.Enabled = false;
            this.txtCodProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodProduto.Location = new System.Drawing.Point(74, 19);
            this.txtCodProduto.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodProduto.MaxLength = 100;
            this.txtCodProduto.Name = "txtCodProduto";
            this.txtCodProduto.Size = new System.Drawing.Size(89, 32);
            this.txtCodProduto.TabIndex = 40;
            this.txtCodProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodProduto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQtd_KeyPress);
            this.txtCodProduto.Leave += new System.EventHandler(this.txtCodProduto_Leave);
            // 
            // lblCod
            // 
            this.lblCod.AutoSize = true;
            this.lblCod.Location = new System.Drawing.Point(71, 2);
            this.lblCod.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCod.Name = "lblCod";
            this.lblCod.Size = new System.Drawing.Size(82, 16);
            this.lblCod.TabIndex = 629;
            this.lblCod.Text = "Cód Produto";
            // 
            // lbSexo
            // 
            this.lbSexo.AutoSize = true;
            this.lbSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSexo.ForeColor = System.Drawing.Color.Black;
            this.lbSexo.Location = new System.Drawing.Point(10, 5);
            this.lbSexo.Name = "lbSexo";
            this.lbSexo.Size = new System.Drawing.Size(138, 20);
            this.lbSexo.TabIndex = 616;
            this.lbSexo.Text = "Produto / Serviço";
            // 
            // cmbProdServ
            // 
            this.cmbProdServ.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cmbProdServ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProdServ.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProdServ.FormattingEnabled = true;
            this.cmbProdServ.Items.AddRange(new object[] {
            "Produtos",
            "Serviços"});
            this.cmbProdServ.Location = new System.Drawing.Point(13, 26);
            this.cmbProdServ.Name = "cmbProdServ";
            this.cmbProdServ.Size = new System.Drawing.Size(286, 33);
            this.cmbProdServ.TabIndex = 30;
            this.toolTip1.SetToolTip(this.cmbProdServ, "Selecione um produto ou serviço para continuar.");
            this.cmbProdServ.SelectedIndexChanged += new System.EventHandler(this.cmbProdServ_SelectedIndexChanged);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.txtTotalNota);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Location = new System.Drawing.Point(985, 546);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(287, 49);
            this.panel6.TabIndex = 558;
            // 
            // txtTotalNota
            // 
            this.txtTotalNota.AutoSize = true;
            this.txtTotalNota.Font = new System.Drawing.Font("Mongolian Baiti", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalNota.ForeColor = System.Drawing.Color.White;
            this.txtTotalNota.Location = new System.Drawing.Point(166, 10);
            this.txtTotalNota.Name = "txtTotalNota";
            this.txtTotalNota.Size = new System.Drawing.Size(115, 36);
            this.txtTotalNota.TabIndex = 557;
            this.txtTotalNota.Text = "000,00";
            this.toolTip1.SetToolTip(this.txtTotalNota, "Valor total da compra.");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Mongolian Baiti", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(11, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 36);
            this.label3.TabIndex = 556;
            this.label3.Text = "R$";
            // 
            // DgItensVenda
            // 
            this.DgItensVenda.AllowUserToAddRows = false;
            this.DgItensVenda.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DgItensVenda.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.DgItensVenda.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.DgItensVenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgItensVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DgItensVenda.Location = new System.Drawing.Point(330, 121);
            this.DgItensVenda.Margin = new System.Windows.Forms.Padding(2);
            this.DgItensVenda.MultiSelect = false;
            this.DgItensVenda.Name = "DgItensVenda";
            this.DgItensVenda.ReadOnly = true;
            this.DgItensVenda.RowHeadersWidth = 51;
            this.DgItensVenda.RowTemplate.Height = 24;
            this.DgItensVenda.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgItensVenda.Size = new System.Drawing.Size(946, 297);
            this.DgItensVenda.TabIndex = 559;
            this.DgItensVenda.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgItensVenda_CellContentClick);
            this.DgItensVenda.SelectionChanged += new System.EventHandler(this.DgItensVenda_SelectionChanged);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvar.BackColor = System.Drawing.Color.Gold;
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.ForeColor = System.Drawing.Color.Black;
            this.btnSalvar.Location = new System.Drawing.Point(985, 602);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(4);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(118, 47);
            this.btnSalvar.TabIndex = 75;
            this.btnSalvar.Text = "SALVAR";
            this.toolTip1.SetToolTip(this.btnSalvar, "Finalizar compra.");
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnFinalizarF4_Click);
            // 
            // btnCancelarF5
            // 
            this.btnCancelarF5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelarF5.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnCancelarF5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelarF5.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelarF5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelarF5.ForeColor = System.Drawing.Color.Black;
            this.btnCancelarF5.Location = new System.Drawing.Point(1158, 602);
            this.btnCancelarF5.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelarF5.Name = "btnCancelarF5";
            this.btnCancelarF5.Size = new System.Drawing.Size(118, 47);
            this.btnCancelarF5.TabIndex = 80;
            this.btnCancelarF5.Text = "SAIR";
            this.btnCancelarF5.UseVisualStyleBackColor = false;
            this.btnCancelarF5.Click += new System.EventHandler(this.btnCancearF5_Click);
            // 
            // lvParcelas
            // 
            this.lvParcelas.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lvParcelas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clParcelas,
            this.clDias,
            this.clIdForma,
            this.clForma,
            this.clPercentTotal,
            this.clPreco});
            this.lvParcelas.FullRowSelect = true;
            this.lvParcelas.GridLines = true;
            this.lvParcelas.HideSelection = false;
            this.lvParcelas.Location = new System.Drawing.Point(330, 494);
            this.lvParcelas.Margin = new System.Windows.Forms.Padding(4);
            this.lvParcelas.Name = "lvParcelas";
            this.lvParcelas.Size = new System.Drawing.Size(647, 155);
            this.lvParcelas.TabIndex = 569;
            this.lvParcelas.UseCompatibleStateImageBehavior = false;
            this.lvParcelas.View = System.Windows.Forms.View.Details;
            // 
            // clParcelas
            // 
            this.clParcelas.Text = "Nº";
            this.clParcelas.Width = 40;
            // 
            // clDias
            // 
            this.clDias.Text = "Dias";
            this.clDias.Width = 100;
            // 
            // clIdForma
            // 
            this.clIdForma.Text = "ID.F";
            // 
            // clForma
            // 
            this.clForma.Text = "Forma PG";
            this.clForma.Width = 240;
            // 
            // clPercentTotal
            // 
            this.clPercentTotal.Text = "%  sob Total";
            this.clPercentTotal.Width = 120;
            // 
            // clPreco
            // 
            this.clPreco.Text = "Valor da parcela";
            this.clPreco.Width = 150;
            // 
            // gbCondicao
            // 
            this.gbCondicao.Controls.Add(this.btnBuscarCondicao);
            this.gbCondicao.Controls.Add(this.txtFrete);
            this.gbCondicao.Controls.Add(this.txtSeguro);
            this.gbCondicao.Controls.Add(this.txtOutras);
            this.gbCondicao.Controls.Add(this.lbOutras);
            this.gbCondicao.Controls.Add(this.lbSeguro);
            this.gbCondicao.Controls.Add(this.lbFrete);
            this.gbCondicao.Controls.Add(this.lbCondicaoPg);
            this.gbCondicao.Controls.Add(this.txtCondicao);
            this.gbCondicao.Controls.Add(this.lbCodigoCondicao);
            this.gbCondicao.Controls.Add(this.txtCodCondicao);
            this.gbCondicao.Enabled = false;
            this.gbCondicao.Location = new System.Drawing.Point(330, 419);
            this.gbCondicao.Margin = new System.Windows.Forms.Padding(2);
            this.gbCondicao.Name = "gbCondicao";
            this.gbCondicao.Padding = new System.Windows.Forms.Padding(2);
            this.gbCondicao.Size = new System.Drawing.Size(733, 73);
            this.gbCondicao.TabIndex = 570;
            this.gbCondicao.TabStop = false;
            // 
            // btnBuscarCondicao
            // 
            this.btnBuscarCondicao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBuscarCondicao.BackColor = System.Drawing.Color.Gold;
            this.btnBuscarCondicao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscarCondicao.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscarCondicao.ForeColor = System.Drawing.Color.Black;
            this.btnBuscarCondicao.Location = new System.Drawing.Point(323, 41);
            this.btnBuscarCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.btnBuscarCondicao.Name = "btnBuscarCondicao";
            this.btnBuscarCondicao.Size = new System.Drawing.Size(88, 24);
            this.btnBuscarCondicao.TabIndex = 804;
            this.btnBuscarCondicao.Text = "BUSCAR";
            this.btnBuscarCondicao.UseVisualStyleBackColor = false;
            this.btnBuscarCondicao.Click += new System.EventHandler(this.btnBuscarCondicao_Click);
            // 
            // txtFrete
            // 
            this.txtFrete.BackColor = System.Drawing.Color.White;
            this.txtFrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFrete.Location = new System.Drawing.Point(418, 38);
            this.txtFrete.Margin = new System.Windows.Forms.Padding(2);
            this.txtFrete.MaxLength = 10;
            this.txtFrete.Name = "txtFrete";
            this.txtFrete.Size = new System.Drawing.Size(94, 32);
            this.txtFrete.TabIndex = 112;
            this.txtFrete.Text = "0";
            this.txtFrete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtFrete.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress_1);
            this.txtFrete.Leave += new System.EventHandler(this.txtFrete_Leave_1);
            // 
            // txtSeguro
            // 
            this.txtSeguro.BackColor = System.Drawing.Color.White;
            this.txtSeguro.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSeguro.Location = new System.Drawing.Point(516, 38);
            this.txtSeguro.Margin = new System.Windows.Forms.Padding(2);
            this.txtSeguro.MaxLength = 10;
            this.txtSeguro.Name = "txtSeguro";
            this.txtSeguro.Size = new System.Drawing.Size(94, 32);
            this.txtSeguro.TabIndex = 111;
            this.txtSeguro.Text = "0";
            this.txtSeguro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSeguro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress_1);
            this.txtSeguro.Leave += new System.EventHandler(this.txtFrete_Leave_1);
            // 
            // txtOutras
            // 
            this.txtOutras.BackColor = System.Drawing.Color.White;
            this.txtOutras.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutras.Location = new System.Drawing.Point(615, 38);
            this.txtOutras.Margin = new System.Windows.Forms.Padding(2);
            this.txtOutras.MaxLength = 10;
            this.txtOutras.Name = "txtOutras";
            this.txtOutras.Size = new System.Drawing.Size(94, 32);
            this.txtOutras.TabIndex = 110;
            this.txtOutras.Text = "0";
            this.txtOutras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOutras.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFrete_KeyPress_1);
            this.txtOutras.Leave += new System.EventHandler(this.txtFrete_Leave_1);
            // 
            // lbOutras
            // 
            this.lbOutras.AutoSize = true;
            this.lbOutras.Location = new System.Drawing.Point(615, 19);
            this.lbOutras.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbOutras.Name = "lbOutras";
            this.lbOutras.Size = new System.Drawing.Size(112, 16);
            this.lbOutras.TabIndex = 109;
            this.lbOutras.Text = "Outras Despesas";
            // 
            // lbSeguro
            // 
            this.lbSeguro.AutoSize = true;
            this.lbSeguro.Location = new System.Drawing.Point(513, 19);
            this.lbSeguro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbSeguro.Name = "lbSeguro";
            this.lbSeguro.Size = new System.Drawing.Size(88, 16);
            this.lbSeguro.TabIndex = 108;
            this.lbSeguro.Text = "Custo Seguro";
            // 
            // lbFrete
            // 
            this.lbFrete.AutoSize = true;
            this.lbFrete.Location = new System.Drawing.Point(415, 19);
            this.lbFrete.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbFrete.Name = "lbFrete";
            this.lbFrete.Size = new System.Drawing.Size(75, 16);
            this.lbFrete.TabIndex = 107;
            this.lbFrete.Text = "Custo Frete";
            // 
            // lbCondicaoPg
            // 
            this.lbCondicaoPg.AutoSize = true;
            this.lbCondicaoPg.Location = new System.Drawing.Point(66, 19);
            this.lbCondicaoPg.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbCondicaoPg.Name = "lbCondicaoPg";
            this.lbCondicaoPg.Size = new System.Drawing.Size(157, 16);
            this.lbCondicaoPg.TabIndex = 90;
            this.lbCondicaoPg.Text = "Condição de Pagamento";
            // 
            // txtCondicao
            // 
            this.txtCondicao.Enabled = false;
            this.txtCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCondicao.Location = new System.Drawing.Point(68, 38);
            this.txtCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.txtCondicao.MaxLength = 100;
            this.txtCondicao.Name = "txtCondicao";
            this.txtCondicao.ReadOnly = true;
            this.txtCondicao.Size = new System.Drawing.Size(242, 32);
            this.txtCondicao.TabIndex = 46;
            // 
            // lbCodigoCondicao
            // 
            this.lbCodigoCondicao.AutoSize = true;
            this.lbCodigoCondicao.Location = new System.Drawing.Point(-3, 19);
            this.lbCodigoCondicao.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbCodigoCondicao.Name = "lbCodigoCondicao";
            this.lbCodigoCondicao.Size = new System.Drawing.Size(51, 16);
            this.lbCodigoCondicao.TabIndex = 88;
            this.lbCodigoCondicao.Text = "Código";
            // 
            // txtCodCondicao
            // 
            this.txtCodCondicao.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCondicao.Location = new System.Drawing.Point(0, 38);
            this.txtCodCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodCondicao.MaxLength = 100;
            this.txtCodCondicao.Name = "txtCodCondicao";
            this.txtCodCondicao.Size = new System.Drawing.Size(62, 32);
            this.txtCodCondicao.TabIndex = 45;
            this.txtCodCondicao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCodCondicao.Enter += new System.EventHandler(this.txtCodCondicao_Enter);
            this.txtCodCondicao.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodCondicao_KeyPress);
            this.txtCodCondicao.Leave += new System.EventHandler(this.txtCodCondicao_Leave);
            // 
            // btnFinalizaCondicao
            // 
            this.btnFinalizaCondicao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFinalizaCondicao.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnFinalizaCondicao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinalizaCondicao.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizaCondicao.ForeColor = System.Drawing.Color.Black;
            this.btnFinalizaCondicao.Location = new System.Drawing.Point(985, 510);
            this.btnFinalizaCondicao.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinalizaCondicao.Name = "btnFinalizaCondicao";
            this.btnFinalizaCondicao.Size = new System.Drawing.Size(287, 29);
            this.btnFinalizaCondicao.TabIndex = 804;
            this.btnFinalizaCondicao.Text = "FINALIZAR CONDIÇÃO";
            this.btnFinalizaCondicao.UseVisualStyleBackColor = false;
            this.btnFinalizaCondicao.Click += new System.EventHandler(this.btnFinalizaCondicao_Click);
            // 
            // btnFinaliza
            // 
            this.btnFinaliza.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnFinaliza.BackColor = System.Drawing.Color.Gold;
            this.btnFinaliza.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinaliza.Enabled = false;
            this.btnFinaliza.Font = new System.Drawing.Font("Mongolian Baiti", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinaliza.ForeColor = System.Drawing.Color.Black;
            this.btnFinaliza.Location = new System.Drawing.Point(1094, 424);
            this.btnFinaliza.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinaliza.Name = "btnFinaliza";
            this.btnFinaliza.Size = new System.Drawing.Size(182, 28);
            this.btnFinaliza.TabIndex = 805;
            this.btnFinaliza.Text = "FINALIZAR VENDA";
            this.btnFinaliza.UseVisualStyleBackColor = false;
            this.btnFinaliza.Click += new System.EventHandler(this.btnFinaliza_Click);
            // 
            // FrmCadastroVenda
            // 
            this.CancelButton = this.btnCancelarF5;
            this.ClientSize = new System.Drawing.Size(1289, 660);
            this.Controls.Add(this.btnFinaliza);
            this.Controls.Add(this.btnFinalizaCondicao);
            this.Controls.Add(this.gbCondicao);
            this.Controls.Add(this.lvParcelas);
            this.Controls.Add(this.btnCancelarF5);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.DgItensVenda);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "FrmCadastroVenda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CadastroVenda";
            this.panel5.ResumeLayout(false);
            this.pnCliente.ResumeLayout(false);
            this.pnCliente.PerformLayout();
            this.pnVendas.ResumeLayout(false);
            this.pnVendas.PerformLayout();
            this.pnProd.ResumeLayout(false);
            this.pnProd.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgItensVenda)).EndInit();
            this.gbCondicao.ResumeLayout(false);
            this.gbCondicao.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        protected System.Windows.Forms.DataGridView DgItensVenda;
        private System.Windows.Forms.Label txtTotalNota;
        protected System.Windows.Forms.Button btnBuscarCliente;
        protected System.Windows.Forms.Label clForn;
        protected System.Windows.Forms.TextBox txtCliente;
        protected System.Windows.Forms.TextBox txtCPFeCNPJ;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.Label lblCodCliente;
        protected System.Windows.Forms.TextBox txtCodCliente;
        private System.Windows.Forms.ToolTip toolTip1;
        public System.Windows.Forms.Panel pnCliente;
        public System.Windows.Forms.Button btnSalvar;
        public System.Windows.Forms.Button btnCancelarF5;
        private System.Windows.Forms.Panel pnVendas;
        private System.Windows.Forms.Label lbSexo;
        private System.Windows.Forms.ComboBox cmbProdServ;
        private System.Windows.Forms.Panel pnProd;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.TextBox txtDesconto;
        protected System.Windows.Forms.Button btnAdicionar;
        protected System.Windows.Forms.TextBox txtProduto;
        protected System.Windows.Forms.Label lblProduto;
        protected System.Windows.Forms.Label label16;
        protected System.Windows.Forms.Button btnBuscarProduto;
        protected System.Windows.Forms.TextBox txtQtd;
        protected System.Windows.Forms.TextBox txtCodProduto;
        protected System.Windows.Forms.Label lblCod;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.TextBox txtUnitario;
        protected System.Windows.Forms.TextBox txtProdTotal;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.ListView lvParcelas;
        private System.Windows.Forms.ColumnHeader clParcelas;
        private System.Windows.Forms.ColumnHeader clDias;
        private System.Windows.Forms.ColumnHeader clIdForma;
        private System.Windows.Forms.ColumnHeader clForma;
        private System.Windows.Forms.ColumnHeader clPercentTotal;
        private System.Windows.Forms.ColumnHeader clPreco;
        protected System.Windows.Forms.GroupBox gbCondicao;
        protected System.Windows.Forms.Label lbCondicaoPg;
        protected System.Windows.Forms.TextBox txtCondicao;
        protected System.Windows.Forms.Label lbCodigoCondicao;
        protected System.Windows.Forms.TextBox txtCodCondicao;
        protected System.Windows.Forms.Button btnFinaliza;
        private System.Windows.Forms.TextBox txtFrete;
        private System.Windows.Forms.TextBox txtSeguro;
        private System.Windows.Forms.TextBox txtOutras;
        protected System.Windows.Forms.Label lbOutras;
        protected System.Windows.Forms.Label lbSeguro;
        protected System.Windows.Forms.Label lbFrete;
        protected System.Windows.Forms.Button btnBuscarCondicao;
        public System.Windows.Forms.Button btnFinalizaCondicao;
    }
}
