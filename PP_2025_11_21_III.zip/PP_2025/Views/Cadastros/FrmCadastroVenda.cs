﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PP_2025
{
    public partial class FrmCadastroVenda : Form
    {

        FrmConsultaCondicaoPagamento frmConCondicao;

        Clientes oCliente;
        Venda aVenda;
        ItemVenda oItemVenda;
        CTLVenda aCTLVenda;
        CTLProdutos aCTLProdutos;
        CTLClientes aCTLClientes;
        int estoqueItens = 0;
        string tipoProdServ = "P"; // inicia do tipo produto.
        int ID_CONDICAO = 0; // Armazena o ID da condição de pagamento do cliente.
        int IdSelecionado = 0; // produto ou serviço selecionado
        string NomeSelecionado = ""; // produto ou serviço
        decimal valorUnit = 0m;
        int NumNFe;
        int SerieNFe;
        int ModeloNFe;
        bool permiteExclusao = true;
        decimal DescontoAtual = 0m; // desconto a ser utilizado nas parcelas a pagar.
        private bool AutorizadoSalvar = false;
        Dictionary<int, Image> imagensProdutos = new Dictionary<int, Image>();  // Definir um dicionário para armazenar as imagens dos produtos/serviços
        DateTime dtCriacao; // data de criação da nota 
        DateTime dtEmissao; // data de emissao da nota
        DateTime dtCancelamento; // date de cancelamento da nota
        CondicaoPagamento aCondicao;
        CTLCondicaoPagamento aCTLcon;
        CultureInfo cultura = new CultureInfo("pt-BR");


        public FrmCadastroVenda()
        {
            InitializeComponent();
            Operacao.DisableCopyPaste(this);
            InicializarDataGridView();
            aVenda = new Venda();
            oItemVenda = new ItemVenda();
            oCliente = new Clientes();
            aCTLProdutos = new CTLProdutos();
            aCTLVenda = new CTLVenda();
            aCTLClientes = new CTLClientes();
            aCTLcon = new CTLCondicaoPagamento();
            aCondicao = new CondicaoPagamento();
        }

        public void BuscarNFE()
        {
            NumNFe = aCTLVenda.BuscarNFE("NUMERO") + 1;
            SerieNFe = aCTLVenda.BuscarNFE("SERIE"); // vai ser 1
            ModeloNFe = aCTLVenda.BuscarNFE("MODELO"); // vai ser 55
        }
        private decimal BuscarDesconto()
        {
            decimal totalDesconto = 0;

            foreach (DataGridViewRow row in DgItensVenda.Rows)
            {
                if (row.Cells["desconto"].Value != null)
                {
                    decimal desconto = 0;
                    if (decimal.TryParse(row.Cells["desconto"].Value.ToString(), out desconto))
                    {
                        totalDesconto += desconto;
                    }
                }
            }

            return totalDesconto;
        }

        private void InicializarDataGridView()
        {
            // Configurações iniciais do DataGridView
            DgItensVenda.AutoGenerateColumns = false;

            // Adiciona a coluna de exclusão como DataGridViewImageColumn
            DataGridViewImageColumn deleteColumn = new DataGridViewImageColumn();
            deleteColumn.Name = "DeleteColumn";
            deleteColumn.HeaderText = "Excluir";
            deleteColumn.Width = 80; // Largura da coluna
            deleteColumn.ImageLayout = DataGridViewImageCellLayout.Zoom; // Ajusta o layout da imagem
            DgItensVenda.Columns.Add(deleteColumn);

            // Adiciona as outras colunas com os tamanhos especificados
            DataGridViewTextBoxColumn numeroItemColumn = new DataGridViewTextBoxColumn();
            numeroItemColumn.Name = "numero_item";
            numeroItemColumn.HeaderText = "Item";
            numeroItemColumn.Width = 50;
            DgItensVenda.Columns.Add(numeroItemColumn);

            DataGridViewTextBoxColumn codigoColumn = new DataGridViewTextBoxColumn();
            codigoColumn.Name = "codigo";
            codigoColumn.HeaderText = "Código";
            codigoColumn.Width = 60;
            DgItensVenda.Columns.Add(codigoColumn);

            DataGridViewTextBoxColumn descricaoColumn = new DataGridViewTextBoxColumn();
            descricaoColumn.Name = "descricao";
            descricaoColumn.HeaderText = "Descrição";
            descricaoColumn.Width = 250;
            DgItensVenda.Columns.Add(descricaoColumn);

            DataGridViewTextBoxColumn quantidadeColumn = new DataGridViewTextBoxColumn();
            quantidadeColumn.Name = "quantidade";
            quantidadeColumn.HeaderText = "QTD";
            quantidadeColumn.Width = 50;
            DgItensVenda.Columns.Add(quantidadeColumn);

            DataGridViewTextBoxColumn descontoColumn = new DataGridViewTextBoxColumn();
            descontoColumn.Name = "desconto";
            descontoColumn.HeaderText = "Desconto";
            descontoColumn.Width = 100; // Defina o tamanho adequado para a coluna de desconto
            DgItensVenda.Columns.Add(descontoColumn);

            DataGridViewTextBoxColumn valorUnitarioColumn = new DataGridViewTextBoxColumn();
            valorUnitarioColumn.Name = "valor_unitario";
            valorUnitarioColumn.HeaderText = "R$ Unit.";
            valorUnitarioColumn.Width = 130;
            DgItensVenda.Columns.Add(valorUnitarioColumn);

            DataGridViewTextBoxColumn subTotalColumn = new DataGridViewTextBoxColumn();
            subTotalColumn.Name = "sub_total";
            subTotalColumn.HeaderText = "Subtotal";
            subTotalColumn.Width = 130;
            DgItensVenda.Columns.Add(subTotalColumn);

            DataGridViewTextBoxColumn tipoColumn = new DataGridViewTextBoxColumn();
            tipoColumn.Name = "tipo";
            tipoColumn.HeaderText = "Tipo";
            tipoColumn.Width = 30;
            DgItensVenda.Columns.Add(tipoColumn);
        }
        public void LimparCampos()
        {
            txtCodCliente.Clear();
            txtCliente.Clear();
            txtCodProduto.Clear();
            txtCPFeCNPJ.Clear();
            txtProduto.Clear();
            txtQtd.Text = "1";
            txtUnitario.Clear();
            txtProdTotal.Clear();
            txtDesconto.Text = "0";
            cmbProdServ.SelectedIndex = 0;
        }
        public virtual void Popular(Venda aVenda)
        {
            // Formata os valores de preço para exibição correta
            NumNFe = aVenda.NumNfv;
            ModeloNFe = aVenda.ModeloNfv;
            SerieNFe = aVenda.SerieNfv;
            txtCodCliente.Text = aVenda.Cliente.ID.ToString();
            txtCliente.Text = aVenda.Cliente.Nome;
            dtCriacao = aVenda.DataCriacao;
            dtEmissao = aVenda.DataEmissao;
            txtFrete.Text = aVenda.ValorFrete.ToString("0.##", cultura);
            txtSeguro.Text = aVenda.ValorSeguro.ToString("0.##", cultura);
            txtOutras.Text = aVenda.ValorOutrasDespesas.ToString("0.##", cultura);
            txtTotalNota.Text = aVenda.ValorTotal.ToString("0.##", cultura);
            txtCodCondicao.Text = aVenda.CondicaoPagamento.ID.ToString();
            txtCondicao.Text = aVenda.CondicaoPagamento.Condicao;
            string documento = "";
            oCliente = aVenda.Cliente;
            if (oCliente.TipoCliente == "F")
                if (oCliente.CPF != null)
                    documento = oCliente.CPF.ToString();
                else
                    documento = oCliente.RG.ToString();
            else if (oCliente.TipoCliente == "J")
                documento = oCliente.CPF.ToString();


            txtCPFeCNPJ.Text = Operacao.FormatarDocumento(documento);

            int codigo = Convert.ToInt32(NumNFe);
            int modelo = Convert.ToInt32(ModeloNFe);
            int serie = Convert.ToInt32(SerieNFe);
            int cliente = Convert.ToInt32(txtCodCliente.Text);

            CTLItemVenda aCTLItensVenda = new CTLItemVenda();
            List<ItemVenda> ItemVenda = aCTLItensVenda.BuscarItensVendaPorChave2(codigo, modelo, serie);

            PopularItens(ItemVenda);
            CarregaLV();
        }
        public void PopularItens(List<ItemVenda> List)
        {
            if (List == null)
            {
                throw new ArgumentNullException(nameof(List), "A lista de itens não pode ser null.");
            }

            DgItensVenda.Rows.Clear();
            int itemNumber = DgItensVenda.Rows.Count + 1;
            foreach (ItemVenda Item in List)
            {
                DgItensVenda.Rows.Add(Properties.Resources.Lixeira_x32,
                itemNumber,
                Item.IdItem.ToString(),
                Item.Descricao.ToString(),
                Item.QtdItem.ToString(),
                Item.Desconto.ToString(),
                Item.PrecoUnitario.ToString("F2"),
                Item.TotalItem.ToString("F2"),
                Item.TipoItem.ToString());
            }
        }

        private void Salvar()
        {
            if (AutorizadoSalvar)
            {
                if (DgItensVenda.Rows.Count > 0)
                {
                    if (VerificarCamposVazios())
                    {
                        Venda venda = new Venda();
                        venda.Cliente = new Clientes();
                        List<ContasReceber> listaContasReceber = new List<ContasReceber>();
                        venda.CondicaoPagamento = new CondicaoPagamento();
                        venda.Cliente.ID = Convert.ToInt32(txtCodCliente.Text);
                        venda.CondicaoPagamento.ID = Convert.ToInt32(txtCodCondicao.Text);
                        venda.NumNfv = NumNFe;
                        venda.ModeloNfv = ModeloNFe;
                        venda.SerieNfv = SerieNFe;
                        venda.ValorTotal = Convert.ToDecimal(txtTotalNota.Text);
                        venda.ValorFrete = decimal.Parse(txtFrete.Text);
                        venda.ValorSeguro = decimal.Parse(txtSeguro.Text);
                        venda.ValorOutrasDespesas = decimal.Parse(txtOutras.Text);
                        venda.DataCriacao = DateTime.Now;
                        venda.DataEmissao = DateTime.Now;
                        venda.DataSaida = DateTime.Now;
                        venda.ItensVenda = ItensListView(venda.NumNfv, venda.ModeloNfv, venda.SerieNfv, venda.Cliente.ID);


                        // Criar as contas a receber baseadas nas parcelas
                        foreach (ListViewItem item in lvParcelas.Items)
                        {
                            ContasReceber aContareceber = new ContasReceber();
                            aContareceber.NumNFC = venda.NumNfv;
                            aContareceber.ModeloNFC = venda.ModeloNfv;
                            aContareceber.SerieNFC = venda.SerieNfv;
                            aContareceber.NumParcela = Convert.ToInt32(item.SubItems[0].Text);
                            aContareceber.Cliente.ID = venda.Cliente.ID;
                            aContareceber.Condicao.ID = venda.CondicaoPagamento.ID;
                            aContareceber.Valor = Convert.ToDecimal(item.SubItems[5].Text);
                            aContareceber.Situacao = "A RECEBER";
                            aContareceber.DataCriacao = DateTime.Now;
                            aContareceber.DataVencimento = DateTime.Now.AddDays(Convert.ToInt32(item.SubItems[1].Text));
                            aContareceber.DataUltAlteracao = DateTime.Now;
                            aContareceber.FormaPagamento.ID = Convert.ToInt32(item.SubItems[2].Text);
                            aContareceber.Taxa = aCondicao.Taxa;
                            aContareceber.Desconto = aCondicao.Desconto;
                            aContareceber.Multa = aCondicao.Multa;
                            //DataBaixa
                            listaContasReceber.Add(aContareceber);
                        }
                        venda.ContasReceber = listaContasReceber;

                        bool result = aCTLVenda.AdicionarVenda(venda);

                        if (!result)
                        {
                            MessageBox.Show("Erro ao salvar a venda.");
                        }
                        else
                        {
                            MessageBox.Show("venda salva com sucesso!");
                        }
                        this.Close();
                    }

                }
                return;
            }
        }
        public List<ItemVenda> ItensListView(int Num_nfc, int Modelo_nfc, int Serie_nfc, int Id_cliente)
        {
            var vLista = new List<ItemVenda>();
            foreach (DataGridViewRow vLinha in DgItensVenda.Rows)
            {
                ItemVenda ItensVenda = new ItemVenda();
                ItensVenda.NumNfv = Num_nfc;
                ItensVenda.ModeloNfv = Modelo_nfc;
                ItensVenda.SerieNfv = Serie_nfc;
                ItensVenda.Cliente.ID = Id_cliente;
                ItensVenda.TipoItem = Convert.ToString(vLinha.Cells["tipo"].Value);
                ItensVenda.IdItem = Convert.ToInt32(vLinha.Cells["codigo"].Value);
                ItensVenda.QtdItem = Convert.ToInt32(vLinha.Cells["quantidade"].Value);
                ItensVenda.PrecoUnitario = Convert.ToDecimal(vLinha.Cells["valor_unitario"].Value);
                ItensVenda.Desconto = Convert.ToDecimal(vLinha.Cells["desconto"].Value);
                ItensVenda.TotalItem = Convert.ToDecimal(txtTotalNota.Text);
                ItensVenda.DataCriacao = DateTime.Now;
                vLista.Add(ItensVenda);
            }
            return vLista;
        }

        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txtCodCliente.Text))
            {
                camposFaltantes.Add("Código do Cliente");
            }
            if (string.IsNullOrWhiteSpace(txtFrete.Text))
            {
                camposFaltantes.Add("Frete");
            }
            if (string.IsNullOrWhiteSpace(txtOutras.Text))
            {
                camposFaltantes.Add("Outras taxas");
            }
            if (string.IsNullOrWhiteSpace(txtSeguro.Text))
            {
                camposFaltantes.Add("Seguro");
            }
            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }



        private void cmbProdServ_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtCodProduto.Enabled = true;


            if (cmbProdServ.Text == "Produtos") // se for produto
            {
                tipoProdServ = "P"; // recebe produto
                lblCod.Text = "Cód Produto";

            }
            else // se for serviço.
            {
                tipoProdServ = "S"; // recebe serviço
                lblCod.Text = "Cód Serviço";
            }

            pnProd.Enabled = true;
            txtCodProduto.Clear();
            txtQtd.Focus();
            txtQtd.Select();
            limparItens();
        }
        private void limparItens()
        {
            txtDesconto.Text = "0";
            txtCodProduto.Clear();
            txtProduto.Clear();
            txtQtd.Text = "1";
            txtProdTotal.Clear();
            txtUnitario.Clear();
        }


        private void btnBuscarProduto_Click(object sender, EventArgs e)
        {
            txtProdTotal.Clear();
            if (!string.IsNullOrWhiteSpace(cmbProdServ.Text)) // Verifica se algum item foi selecionado no ComboBox
            {
                if (tipoProdServ == "P") // Se for um produto
                {
                    using (FrmConsultaProduto frm = new FrmConsultaProduto())
                    {
                        frm.btnSair.Text = "Selecionar";
                        frm.ShowDialog();

                        // Após o retorno do diálogo, acessa os valores do produto selecionado
                        IdSelecionado = frm.IdSelecionado;
                        NomeSelecionado = frm.NomeSelecionado;
                        estoqueItens = Convert.ToInt32(frm.Und);

                        txtCodProduto.Text = IdSelecionado.ToString();
                        txtProduto.Text = NomeSelecionado; // Atualiza o campo de texto com o nome do produto
                        BuscarProdutoOuServicoPorId(IdSelecionado); // Chama o método de busca para preencher os detalhes
                        CalculoDescontos(); // Atualiza o cálculo após selecionar o produto
                    }
                }
                else if (tipoProdServ == "S") // Se for um serviço
                {
                    using (FrmConsultaServico frm = new FrmConsultaServico())
                    {
                        frm.btnSair.Text = "Selecionar";
                        frm.ShowDialog();

                        // Após o retorno do diálogo, acessa os valores do serviço selecionado
                        IdSelecionado = frm.IdSelecionado;
                        NomeSelecionado = frm.NomeSelecionado;

                        txtCodProduto.Text = IdSelecionado.ToString();
                        txtProduto.Text = NomeSelecionado; // Atualiza o campo de texto com a descrição do serviço
                        BuscarProdutoOuServicoPorId(IdSelecionado); // Chama o método de busca para preencher os detalhes
                        CalculoDescontos(); // Atualiza o cálculo após selecionar o serviço
                    }
                }
            }
        }

        private void txtCodProduto_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodProduto.Text))
            {
                txtCodProduto.Clear();
            }
            else if (int.TryParse(txtCodProduto.Text, out int cod) && cod > 0)
            {
                BuscarProdutoOuServicoPorId(cod);
                CalculoDescontos(); // Atualiza o cálculo quando o código do produto é preenchido corretamente
            }
            else
            {
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                txtCodProduto.Clear();
            }
        }



        private void BuscarProdutoOuServicoPorId(int id)
        {
            if (cmbProdServ.Text == "Produtos")
            {
                Produto produto = aCTLProdutos.BuscarProdutoPorId(id);

                if (produto == null)
                {
                    MessageBox.Show("Produto não encontrado para o código especificado.");
                    limparItens();
                }
                else if (produto.Status == "I")
                {
                    MessageBox.Show("O produto associado a este código está inativo.");
                    limparItens();
                }
                else
                {
                    txtProduto.Text = produto.Nome;
                    estoqueItens = produto.QtdEstoque;
                    valorUnit = produto.PrecoVenda;
                    txtUnitario.Text = produto.PrecoVenda.ToString();
                }
            }
            else if (cmbProdServ.Text == "Serviços")
            {
                CTLServicos aCTLServ = new CTLServicos();
                Servico servico = aCTLServ.BuscarServicoPorId(id);

                if (servico == null)
                {
                    MessageBox.Show("Serviço não encontrado para o código especificado.");
                    txtCodProduto.Clear();
                    txtUnitario.Clear();
                    txtProduto.Clear();
                }
                else if (servico.Status == "I")
                {
                    MessageBox.Show("O serviço associado a este código está inativo.");
                    txtCodProduto.Clear();
                    txtProduto.Clear();
                    txtUnitario.Clear();
                }
                else
                {
                    txtProduto.Text = servico.Descricao;
                    valorUnit = servico.Valor; // Exemplo: preenchendo valorUnit
                    txtUnitario.Text = servico.Valor.ToString();
                }

            }
        }


        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            BuscarClientePorDocumento(txtCPFeCNPJ.Text.Trim());
        }

        private void BuscarClientePorDocumento(string documento)
        {
            if (string.IsNullOrWhiteSpace(documento)) // caso não tenha nada no txt.
            {
                // Abrir formulário de consulta de cliente se o documento estiver vazio
                using (FrmConsultaCliente frm = new FrmConsultaCliente())
                {
                    frm.btnSair.Text = "Selecionar";
                    frm.ShowDialog();

                    // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                    int IdSelecionado = frm.IdSelecionado;
                    txtCodCliente.Text = IdSelecionado.ToString();

                    oCliente = aCTLClientes.BuscarClientePorId(IdSelecionado);
                    if (oCliente != null) // Encontrou o cliente
                    {
                        aCondicao = aCTLcon.BuscarCondicaoPagamentoPorId(oCliente.CondicaoPagamento.ID);
                        FuncoesCliente();
                    }
                    else
                    {
                        MessageBox.Show("Documento não encontrado.");
                    }
                }
            }
            else
            {
                oCliente = aCTLClientes.BuscarClientePorDocumento2(documento);
                if (oCliente != null)
                {
                    FuncoesCliente();
                }
                else
                {
                    MessageBox.Show("Documento não encontrado.");
                }
            }
        }

        private void FuncoesCliente()
        {
            txtCodCliente.Text = oCliente.ID.ToString();
            txtCliente.Text = oCliente.Nome;
            pnVendas.Enabled = true;
            pnCliente.Enabled = false; // Bloquear o painel de cliente
            string documentoCliente = string.IsNullOrWhiteSpace(oCliente.CPF) ? oCliente.RG : oCliente.CPF;
            txtCPFeCNPJ.Text = Operacao.FormatarDocumento(documentoCliente);
            cmbProdServ.Focus();
            cmbProdServ.Select();
        }



        private void txtQtd_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Permite apenas números, um ponto decimal e teclas de controle (como Backspace)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // Permite apenas um ponto decimal
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

            // Bloqueia qualquer modificação com Ctrl
            if (Control.ModifierKeys == Keys.Control)
            {
                e.Handled = true;
            }
        }
        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            // Armazena o valor original de cmbProdServ.Text para garantir que ele não seja alterado
            string tipoItemOriginal = cmbProdServ.Text;

            if (string.IsNullOrWhiteSpace(cmbProdServ.Text))
            {
                MessageBox.Show("Por favor, selecione um tipo de item (Produto ou Serviço).");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCodProduto.Text))
            {
                MessageBox.Show("Por favor, insira o código do produto ou serviço.");
                return;
            }

            if (string.IsNullOrWhiteSpace(txtQtd.Text) || !int.TryParse(txtQtd.Text, out int quantidade) || quantidade <= 0)
            {
                MessageBox.Show("Por favor, insira uma quantidade válida.");
                return;
            }

            int id = int.Parse(txtCodProduto.Text);
            string tipo = cmbProdServ.Text == "Produtos" ? "P" : "S";

            // Verifica se o item já existe no DataGridView
            if (VerificarItemDuplicado(id, tipo))
            {
                MessageBox.Show("Item com o mesmo código e tipo já foi adicionado.");
                limparItens();
                return;
            }

            // Define o desconto como 0 se o campo estiver vazio
            decimal desconto = string.IsNullOrWhiteSpace(txtDesconto.Text) ? 0 : Convert.ToDecimal(txtDesconto.Text);
            decimal valorUnitario = valorUnit; // Valor unitário do item, ajuste conforme necessário

            if (tipo == "P")
            {
                // Verifica o estoque do produto
                if (quantidade > estoqueItens)
                {
                    MessageBox.Show($"Quantidade de Produtos excede o estoque disponível ({estoqueItens}).", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }


            decimal subtotalSemDesconto = valorUnitario * quantidade;
            decimal subtotalComDesconto = subtotalSemDesconto - desconto;
            btnFinaliza.Enabled = true;
            // Adicionar o item ao DataGridView
            int itemNumber = DgItensVenda.Rows.Count + 1;
            DgItensVenda.Rows.Add(
                Properties.Resources.Lixeira_x32, // Imagem de lixeira
                itemNumber,
                id.ToString(),
                txtProduto.Text,
                quantidade,
                desconto,
                valorUnitario.ToString("F2"),
                subtotalComDesconto.ToString("F2"),
                tipo

            );

            // Adicionar a imagem correspondente ao dicionário

            // Atualiza o valor total da nota
            AtualizarTotalNota();

            // Limpar os campos após adicionar o item
            limparItens();
            valorUnit = 0;
            estoqueItens = 0;

            // Garantir que cmbProdServ.Text mantenha o valor original
            cmbProdServ.Text = tipoItemOriginal;
        }

        private void AtualizarTotalNota()
        {
            decimal totalNota = 0;

            foreach (DataGridViewRow row in DgItensVenda.Rows)
            {
                if (row.Cells["sub_total"].Value != null)
                {
                    // Tentar converter o valor da célula para decimal
                    if (decimal.TryParse(row.Cells["sub_total"].Value.ToString(), out decimal subTotal))
                    {
                        totalNota += subTotal;
                    }
                    else
                    {
                        // Lidar com valores inválidos ou formatos inesperados
                        MessageBox.Show("Erro ao converter o valor do subtotal para decimal.", "Erro de Conversão", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            decimal frete = 0;
            decimal seguro = 0;
            decimal outras = 0;

            // Tentar converter os valores dos campos txtFrete, txtSeguro e txtOutras para decimal
            if (decimal.TryParse(txtFrete.Text.ToString(), out decimal freteValue))
            {
                frete = freteValue;
            }
            if (decimal.TryParse(txtSeguro.Text.ToString(), out decimal seguroValue))
            {
                seguro = seguroValue;
            }
            if (decimal.TryParse(txtOutras.Text.ToString(), out decimal outrasValue))
            {
                outras = outrasValue;
            }

            decimal custoTotal = frete + seguro + outras + totalNota;
            txtTotalNota.Text = custoTotal.ToString("F2");
        }


        private bool VerificarItemDuplicado(int id, string tipo)
        {
            foreach (DataGridViewRow row in DgItensVenda.Rows)
            {
                if (row.Cells["codigo"].Value != null && row.Cells["Tipo"].Value != null)
                {
                    if (Convert.ToInt32(row.Cells["codigo"].Value) == id && row.Cells["Tipo"].Value.ToString() == tipo)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private void DgItensVenda_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (this.Text != "Consultar uma Venda")// desabilita o botão caso seja no form de consulta. não precisa excluir se vc está apenas consultando.
            {
                if (e.ColumnIndex == DgItensVenda.Columns["DeleteColumn"].Index && e.RowIndex >= 0 && permiteExclusao)
                {
                    // Exibe um MessageBox para confirmar a exclusão
                    DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este item?", "Confirmar Exclusão",
                                                           MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    // Verifica se o usuário confirmou a exclusão
                    if (result == DialogResult.Yes)
                    {
                        // Remove o item da DataGridView
                        DgItensVenda.Rows.RemoveAt(e.RowIndex);

                        // Atualiza o número do item após exclusão
                        AtualizarNumerosItens();

                        // Atualiza o total da nota após exclusão
                        AtualizarTotalNota();
                        if (DgItensVenda.Rows.Count == 0)
                        {
                            btnFinaliza.Enabled = false;
                        }
                    }
                }
            }

        }


        // Método para atualizar os números dos itens após exclusão
        private void AtualizarNumerosItens()
        {
            for (int i = 0; i < DgItensVenda.Rows.Count; i++)
            {
                DgItensVenda.Rows[i].Cells["numero_item"].Value = i + 1;
            }
        }


        private void Sair()
        {
            if (DgItensVenda.Rows.Count > 0)
            {
                // Exibir mensagem de confirmação
                DialogResult result = MessageBox.Show("Tem certeza que deseja cancelar esta venda e sair?", "Cancelar Venda ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    Close(); // Fecha o formulário se o usuário confirmar
                }
            }
            else
            {
                if (txtCodCliente.Text.Length > 0)
                {
                    DialogResult result = MessageBox.Show("Tem certeza que deseja cancelar esta venda e sair?", "Cancelar Venda", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        Close(); // Fecha o formulário se o usuário confirmar
                    }
                }
                else
                    Close();
            }

        }

        private void btnExcluirItem_Click(object sender, EventArgs e)
        {
            // Verifica se algum item está selecionado no DataGridView
            if (DgItensVenda.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecione um item para excluir.");
                return;
            }

            // Pergunta ao usuário se ele tem certeza que deseja excluir o item selecionado
            DialogResult result = MessageBox.Show("Tem certeza que deseja excluir o item selecionado?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            // Se o usuário confirmar a exclusão
            if (result == DialogResult.Yes)
            {
                // Remove o item selecionado do DataGridView
                foreach (DataGridViewRow row in DgItensVenda.SelectedRows)
                {
                    DgItensVenda.Rows.Remove(row);
                }

                // Atualiza o valor total da nota após a exclusão do item
                AtualizarTotalNota();
            }
        }

        private void txtCPFeCNPJ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Prevenir o som de "ding" do sistema ao pressionar Enter
                e.SuppressKeyPress = true;
                // Chamar o método de busca
                BuscarClientePorDocumento(txtCPFeCNPJ.Text.Trim());
            }
        }

        private void DgItensVenda_SelectionChanged(object sender, EventArgs e)
        {
            if (DgItensVenda.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = DgItensVenda.SelectedRows[0];
                int idSelecionado = Convert.ToInt32(selectedRow.Cells["codigo"].Value); // Supondo que "codigo" é o nome da coluna que contém o ID
            }
        }

        private void Verificar()
        {
            if (btnSalvar.Text == "SALVAR")
            {
                // Exibir mensagem de confirmação
                DialogResult result = MessageBox.Show("Tem certeza que deseja Finalizar esta venda?", "Finalizar Venda ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    Salvar(); // Fecha o formulário se obtiver sucesso
                }
            }
            else if (btnSalvar.Text == "CANCELAR VENDA")
            {
                CancelarVenda();
            }

        }
        private void btnFinalizarF4_Click(object sender, EventArgs e)
        {
            if (txtCodCondicao.Text == "0" || txtCodCondicao.Text == string.Empty)
            {
                MessageBox.Show("Condição inválida !");
            }
            else
                Verificar();
        }
        protected virtual void CancelarVenda()
        {
            string mensagem = "Tem certeza que deseja cancelar está venda?";

            DialogResult resultado = MessageBox.Show(mensagem, $"Confirmação de Cancelamento", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resultado == DialogResult.Yes)
            {
                try
                {
                    aVenda.NumNfv = Convert.ToInt32(NumNFe);
                    aVenda.SerieNfv = Convert.ToInt32(SerieNFe);
                    aVenda.ModeloNfv = Convert.ToInt32(ModeloNFe);
                    aVenda.Cliente.ID = Convert.ToInt32(oCliente.ID);
                    aVenda.DataCancelamento = DateTime.Now;

                    aCTLVenda.CancelarVenda(aVenda);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ocorreu um erro ao Cancelar compra: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
        private void btnCancearF5_Click(object sender, EventArgs e)
        {
            if (btnCancelarF5.Text == "SAIR")
                Close();
            else
                Sair();
        }

        public void DesabilitarBotoes()
        {
            txtFrete.Enabled = false;
            txtSeguro.Enabled = false;
            txtOutras.Enabled = false;
            btnSalvar.Enabled = false;
            //btnCancelarF5.Enabled = false;
        }

        private void txtQtd_Leave(object sender, EventArgs e)
        {
            CalculoDescontos();
        }

        private void CalculoDescontos()
        {
            if (!string.IsNullOrWhiteSpace(txtQtd.Text) && !string.IsNullOrWhiteSpace(txtUnitario.Text))
            {
                // Remover o símbolo de moeda 'R$' e converter o valor para decimal
                decimal valorUnitario;
                if (decimal.TryParse(txtUnitario.Text.Replace("R$", "").Trim(), out valorUnitario))
                {
                    // Converter a quantidade para inteiro
                    int quantidade;
                    if (int.TryParse(txtQtd.Text, out quantidade))
                    {
                        // Calcular o valor total do produto
                        decimal valorTotal = quantidade * valorUnitario;

                        // Aplicar desconto, se houver
                        decimal desconto = 0;
                        if (!string.IsNullOrWhiteSpace(txtDesconto.Text))
                        {
                            if (decimal.TryParse(txtDesconto.Text.Replace("R$", "").Trim(), out desconto))
                            {
                                // Verificar se o desconto não deixa o valor total negativo
                                if (valorTotal - desconto >= 0)
                                {
                                    valorTotal -= desconto;
                                }
                                else
                                {
                                    MessageBox.Show("O desconto não pode resultar em um valor total negativo.", "Erro de Desconto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    txtDesconto.Text = "0";
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Valor de desconto inválido.", "Erro de Desconto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txtDesconto.Text = "0";
                                return;
                            }
                        }

                        // Exibir o valor unitário sem o símbolo de moeda
                        txtUnitario.Text = valorUnitario.ToString("0.00");

                        // Exibir o valor total
                        txtProdTotal.Text = valorTotal.ToString("0.00");
                    }
                    else
                    {
                        MessageBox.Show("Quantidade inválida.", "Erro de Quantidade", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtQtd.Text = "1";
                        txtProdTotal.Text = "0.00";
                    }
                }
                else
                {
                    MessageBox.Show("Valor unitário inválido.", "Erro de Valor Unitário", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtUnitario.Text = "";
                    txtProdTotal.Text = "0.00";
                }
            }
            else
            {
                txtProdTotal.Text = "0.00";
            }
        }

        private void txtDesconto_Leave(object sender, EventArgs e)
        {
            CalculoDescontos();
        }

        private void btnFinaliza_Click(object sender, EventArgs e)
        {
            if (btnFinaliza.Text == "FINALIZAR VENDA")
            {
                gbCondicao.Enabled = true;
                permiteExclusao = false;
                pnVendas.Enabled = false;
                btnFinaliza.Text = "LIBERAR PRODUTOS";
                //btnFinaliza.BackColor = Color.DarkGreen;
                txtCodCondicao.Text = aCondicao.ID.ToString();
                txtCondicao.Text = aCondicao.Condicao;
                DescontoAtual = BuscarDesconto();
            }
            else
            {
                gbCondicao.Enabled = false;
                DgItensVenda.ReadOnly = false;
                pnVendas.Enabled = true;
                permiteExclusao = true;
                lvParcelas.Items.Clear();
                txtFrete.Clear();
                txtOutras.Clear();
                txtSeguro.Clear();
                btnFinaliza.Text = "FINALIZAR VENDA";
                //btnFinaliza.BackColor = Color.DarkRed;
                DescontoAtual = 0m;

            }
            AtualizarTotalNota();
        }

        private void btnFinalizaCondicao_Click(object sender, EventArgs e)
        {
            if (txtCodCondicao.Text == "0" || txtCodCondicao.Text == string.Empty)
            {
                MessageBox.Show("Condição inválida !");
            }
            else
            {
                if (btnFinalizaCondicao.Text == "FINALIZAR CONDIÇÃO")
                {
                    LiberarFrete(false);
                    btnFinalizaCondicao.Text = "LIBERAR CONDIÇÃO"; // muda o texto do botão
                    //btnFinalizaCondicao.BackColor = Color.DarkGreen; // muda a cor do botão
                    btnFinalizaCondicao.Enabled = true; //mantem o botão aberto
                    txtTotalNota.Enabled = true; // mantem a nota aberta.
                    AtualizarTotalNota();// chama para recalcular as parcelas 
                    LiberarCondicaoPagamento();
                    AutorizadoSalvar = true;
                    btnBuscarCondicao.Enabled = false;
                    txtCodCondicao.Enabled = false;
                    btnFinaliza.Enabled = false;

                }
                else if (btnFinalizaCondicao.Text == "LIBERAR CONDIÇÃO")
                {
                    LiberarFrete(true);
                    btnFinalizaCondicao.Text = "FINALIZAR CONDIÇÃO";
                    //btnFinalizaCondicao.BackColor = Color.DarkRed;
                    btnFinalizaCondicao.Enabled = true;
                    AtualizarTotalNota();// chama para recalcular as parcelas 
                    LiberarCondicaoPagamento();
                    AutorizadoSalvar = false;
                    btnBuscarCondicao.Enabled = true;
                    txtCodCondicao.Enabled = true;
                    btnFinaliza.Enabled = true;
                }
            }
         
        }
        private void LiberarCondicaoPagamento()
        {
            if (DgItensVenda.Rows.Count > 0)
            {

                if (aCondicao != null)
                {
                    txtCodCondicao.Text = aCondicao.ID.ToString();
                    txtCondicao.Text = aCondicao.Condicao;
                    CarregaLV();
                }
            }
            else
            {
                gbCondicao.Enabled = false;
                txtCodCondicao.Text = "";
                txtCondicao.Text = "";
            }
        }
        private void CarregaLV()
        {
            int cod = Convert.ToInt32(txtCodCondicao.Text);
            CTLParcelas aCTLParcela = new CTLParcelas();
            List<Parcela> dados = aCTLParcela.BuscarParcelasPorIDCondicao(cod); ;
            PreencherListView(dados);
        }
        private void PreencherListView(IEnumerable<Parcela> dados)
        {
            lvParcelas.Items.Clear();

            // Calcula o custo total com os adicionais uma vez para uso em todas as parcelas
            decimal custoTotalComAdicionais = CalcularCustoTotalComAdicionais();
            DescontoAtual = BuscarDesconto();

            // Obtém o número total de parcelas
            int totalParcelas = dados.Count();

            decimal somaParcelas = 0; // Para armazenar a soma das parcelas

            foreach (var parcela in dados.Select((p, index) => new { Parcela = p, Index = index }))
            {
                ListViewItem item = new ListViewItem(parcela.Parcela.NumParcela.ToString());
                item.SubItems.Add(parcela.Parcela.DiasTotais.ToString());
                item.SubItems.Add(parcela.Parcela.Forma.ID.ToString());
                item.SubItems.Add(parcela.Parcela.Forma.Forma);
                item.SubItems.Add(parcela.Parcela.Porcentagem.ToString());

                // Calcula o valor da parcela com base na porcentagem e no custo total com adicionais
                decimal valorParcela = (parcela.Parcela.Porcentagem / 100) * custoTotalComAdicionais;

                // Aplica o desconto proporcional ao número de parcelas
                decimal descontoProporcional = DescontoAtual / totalParcelas;
                valorParcela -= descontoProporcional;

                // Arredonda o valor da parcela
                valorParcela = Math.Round(valorParcela, 2);

                // Adiciona o valor ao somatório
                somaParcelas += valorParcela;

                // Se for a última parcela, ajusta o valor para corrigir a diferença
                if (parcela.Index == totalParcelas - 1)
                {
                    // Calcula a diferença entre o total desejado e a soma atual das parcelas
                    decimal diferenca = (custoTotalComAdicionais - DescontoAtual )- somaParcelas;
                    valorParcela += diferenca; // Ajusta a última parcela com a diferença
                }

                // Adiciona o valor da parcela na posição correta (já ajustado, se for o caso)
                item.SubItems.Add(valorParcela.ToString("F2"));

                item.Tag = parcela.Parcela;
                lvParcelas.Items.Add(item);
            }
        }


        private void LiberarFrete(bool valor)
        {
            txtFrete.Enabled = valor;
            txtOutras.Enabled = valor;
            txtSeguro.Enabled = valor;
        }
        private decimal CalcularCustoTotalComAdicionais()
        {
            decimal total = CustoTotal(); // Chama o método existente para obter o custo total atual

            // Somar os custos de frete, seguro e outros se não forem nulos ou vazios
            decimal frete = 0;
            decimal seguro = 0;
            decimal outrosCustos = 0;

            if (!string.IsNullOrEmpty(txtFrete.Text)) frete = Convert.ToDecimal(txtFrete.Text);
            if (!string.IsNullOrEmpty(txtSeguro.Text)) seguro = Convert.ToDecimal(txtSeguro.Text);
            if (!string.IsNullOrEmpty(txtOutras.Text)) outrosCustos = Convert.ToDecimal(txtOutras.Text);

            // Somar os custos extras ao total
            total += frete + seguro + outrosCustos;

            return total;
        }
        private decimal CustoTotal()
        {
            decimal total = 0;
            foreach (DataGridViewRow vLinha in DgItensVenda.Rows)
            {
                total += Convert.ToDecimal(vLinha.Cells["quantidade"].Value) * Convert.ToDecimal(vLinha.Cells["valor_unitario"].Value);
            }
            return total;
        }

        private void txtFrete_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPressComVirgula((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtFrete_Leave_1(object sender, EventArgs e)
        {
            AtualizarTotalNota();
        }

        private void txtCodCondicao_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null; // Remove o botão "SALVAR" como botão padrão   
        }

        private void txtCodCondicao_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtCodCondicao_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodCondicao.Text))
                LimparCondicao();
            else if (int.TryParse(txtCodCondicao.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente

                aCondicao = aCTLcon.BuscarCondicaoPagamentoPorId(cod);

                if (aCondicao == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparCondicao();
                }
                else
                {
                    txtCondicao.Text = aCondicao.Condicao;
                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparCondicao();
            }
            lvParcelas.Items.Clear();
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }
        private void LimparCondicao()
        {
            txtCondicao.Clear();
            txtCodCondicao.Clear();
        }

        private void btnBuscarCondicao_Click(object sender, EventArgs e)
        {
            using (FrmConsultaCondicaoPagamento frm = new FrmConsultaCondicaoPagamento())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txtCodCondicao.Text = IdSelecionado.ToString();
                txtCondicao.Text = NomeSelecionado;
                aCondicao = aCTLcon.BuscarCondicaoPagamentoPorId(IdSelecionado);
                lvParcelas.Items.Clear();
            }
        }

        private void txtDesconto_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPressComVirgula((System.Windows.Forms.TextBox)sender, e);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnProd_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}