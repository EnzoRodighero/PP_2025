﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PP_2025
{
    public partial class FrmCadastroClienteII : FrmCadastroPessoa
    {
        private FrmConsultaCidade frmConCidades;
        private CTLClientes aCTLClientes;
        private Clientes oCliente;
        private string TipoCliente;
        Clientes ClienteAntigo;

        public FrmCadastroClienteII()
        {
            InitializeComponent();
            Operacao.DisableCopyPaste(this);
            Instanciar();

            //txtDtCriacao.Text = "TESTE";
            //txtDtUltMod.Text = "TESTE";

            VerCampos (false); // Inicialmente, os campos não são visíveis
        }

        private void Instanciar()
        {
            oCliente = new Clientes();
            aCTLClientes = new CTLClientes();
            ClienteAntigo = new Clientes();

        }

        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Clientes cliente)
            {
                oCliente = cliente;
                CarregarCampos();
            }
        }
        public void SetConsultaCidades(object obj)
        {
            frmConCidades = (FrmConsultaCidade)obj;
        }

        protected override void LimparCampos()
        {
            txtCodigo.Clear();
            txtNome.Clear();
            txtRG.Clear();
            txtCPFouCNPJ.Clear();
            cmbSexo.SelectedIndex = 0;
            txtApelido.Clear();
            dtNascimento.Value = DateTime.Now;
            txtEmail.Clear();
            txtTelefone.Clear();
            txtCelular.Clear();
            txtCEP.Clear();
            txtCodCidade.Clear();
            txtCidade.Clear();
            txtBairro.Clear();
            txtLogradouro.Clear();
            txtComplemento.Clear();
            txtNum.Clear();
            txtCodCondPag.Clear();
            txtCondPag.Clear();
            cmbStatus.SelectedIndex = 0;
        }

        protected override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                if (TipoCliente == "F")
                {
                    oCliente.Sexo = cmbSexo.Text[0].ToString();
                }
                oCliente.Nome = txtNome.Text;
                oCliente.CPF = txtCPFouCNPJ.Text;
                oCliente.RG = txtRG.Text;
                oCliente.Apelido = txtApelido.Text;
                oCliente.DataNasc = dtNascimento.Value;
                oCliente.Email = txtEmail.Text;
                oCliente.Telefone = txtTelefone.Text;
                oCliente.Celular = txtCelular.Text;
                oCliente.CEP = txtCEP.Text;
                oCliente.Cidade.ID = Convert.ToInt32(txtCodCidade.Text);
                oCliente.Bairro = txtBairro.Text;
                oCliente.Endereco = txtLogradouro.Text;
                oCliente.Complemento = txtComplemento.Text;
                if (txtNum.Text.Length > 0)
                {
                    oCliente.Numero = Convert.ToInt32(txtNum.Text);
                }
                oCliente.StatusCliente = cmbStatus.Text[0].ToString();
                oCliente.CondicaoPagamento.ID = Convert.ToInt32(txtCodCondPag.Text);
                oCliente.TipoCliente = TipoCliente;


                if (oCliente.ID == 0)
                {
                    oCliente.DataCriacao = DateTime.Now;
                    var result = aCTLClientes.AdicionarCliente(oCliente);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    oCliente.DataUltimaAlteracao = DateTime.Now;
                    var result = aCTLClientes.AtualizarCliente(oCliente);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
            }
        }

        public override void BloquearCampos()
        {
            base.BloquearCampos();
            txtNome.Enabled = false;
            txtRG.Enabled = false;
            txtCPFouCNPJ.Enabled = false;
            cmbSexo.Enabled = false;
            txtApelido.Enabled = false;
            dtNascimento.Enabled = false;
            txtEmail.Enabled = false;
            txtTelefone.Enabled = false;
            txtCelular.Enabled = false;
            txtCEP.Enabled = false;
            txtCodCidade.Enabled = false;
            txtCidade.Enabled = false;
            txtBairro.Enabled = false;
            txtLogradouro.Enabled = false;
            txtComplemento.Enabled = false;
            txtNum.Enabled = false;
            txtCodigo.Enabled = false;
            btnBuscaCid.Enabled = false;
            cmbStatus.Enabled = false;
            btnBuscaCep.Enabled = false;
            btnCondPag.Enabled = false;
            txtCodCondPag.Enabled = false;
            txtCondPag.Enabled = false;
            txtDtCriacao.Enabled = false;
            txtDtUltMod.Enabled = false;
        }

        public override void DesbloquearCampos()
        {
            base.BloquearCampos();
            txtCodigo.Enabled = true;
            txtNome.Enabled = true;
            txtRG.Enabled = true;
            txtCPFouCNPJ.Enabled = true;
            cmbSexo.Enabled = true;
            txtApelido.Enabled = true;
            dtNascimento.Enabled = true;
            txtEmail.Enabled = true;
            txtTelefone.Enabled = true;
            txtCelular.Enabled = true;
            txtCEP.Enabled = true;
            txtCodCidade.Enabled = true;
            txtCidade.Enabled = true;
            txtBairro.Enabled = true;
            txtLogradouro.Enabled = true;
            txtComplemento.Enabled = true;
            txtNum.Enabled = true;
            txtCodigo.Enabled = true;
            btnBuscaCid.Enabled = true;
            //  cmbStatus.Enabled = true;
            btnBuscaCep.Enabled = true;
            btnCondPag.Enabled = true;
            txtCodCondPag.Enabled = true;
            txtCondPag.Enabled = true;
            txtDtCriacao.Enabled = false;
            txtDtUltMod.Enabled = false;
        }

        public override void CarregarCampos()
        {
            txtDtCriacao.Text = oCliente.DataCriacao.ToString("dd/MM/yyyy");
            txtDtUltMod.Text = oCliente.DataUltimaAlteracao.ToString("dd/MM/yyyy");

            base.CarregarCampos();
            txtCodigo.Text = oCliente.ID.ToString();
            txtNome.Text = oCliente.Nome;

            txtApelido.Text = oCliente.Apelido;
            dtNascimento.Value = oCliente.DataNasc;
            txtEmail.Text = oCliente.Email;
            txtTelefone.Text = oCliente.Telefone;
            txtCelular.Text = oCliente.Celular;
            txtCEP.Text = oCliente.CEP;
            txtCodCidade.Text = oCliente.Cidade.ID.ToString();
            txtCidade.Text = oCliente.Cidade.Cidade;
            txtBairro.Text = oCliente.Bairro;
            txtLogradouro.Text = oCliente.Endereco;
            txtComplemento.Text = oCliente.Complemento;
            txtNum.Text = oCliente.Numero.ToString();
            cmbStatus.Text = oCliente.StatusCliente == "I" ? "Inativo" : oCliente.StatusCliente == "A" ? "Ativo" : oCliente.StatusCliente;
            txtRG.Text = oCliente.RG;
            txtCPFouCNPJ.Text = oCliente.CPF;
            txtCodCondPag.Text = oCliente.CondicaoPagamento.ID.ToString();
            txtCondPag.Text = oCliente.CondicaoPagamento.Condicao.ToString();
            cmbFisJur.Text = oCliente.TipoCliente == "F" ? "PESSOA FÍSICA" : oCliente.TipoCliente == "J" ? "PESSOA JURÍDICA" : "OUTRO";
            TipoCliente = oCliente.TipoCliente;
            VerificarCamposJuridicosFisicos();
            ClienteAntigo = oCliente;
            if (TipoCliente == "F")
            {
                PessoaFisica(false);
                cmbSexo.Text = oCliente.Sexo == "M" ? "Masculino" : oCliente.Sexo == "F" ? "Feminino" : oCliente.Sexo;
            }
            else if (TipoCliente == "J")
            {
                PessoaJuridica(false);
                cmbFisJur.Text = "PESSOA JÚRIDICA";
            }

        }

        public override void Verificar()
        {
            if (btnSalvar.Text == "SALVAR" || btnSalvar.Text == "ALTERAR")
                Salvar();
            else if (btnSalvar.Text == "EXCLUIR")
            {
                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este cliente?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    ExcluirCliente();
                }
            }
        }

        private void ExcluirCliente()
        {
            if (oCliente != null)
            {
                try
                {
                    var result = aCTLClientes.ExcluirCliente(oCliente.ID);
                    if (result)
                        Close();
                    else
                    {
                        // Trate outras exceções SQL, se necessário
                        MessageBox.Show("Ocorreu um erro ao excluir o cliente. Detalhes: " + result);
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547) // Verifica o número de erro 547, que corresponde a violação de chave estrangeira
                    {
                        MessageBox.Show("Não é possível excluir o cliente devido a outros registros estarem vinculados a este cliente.");
                    }
                    else
                    {
                        // Trate outras exceções SQL, se necessário
                        MessageBox.Show("Ocorreu um erro ao excluir o cliente. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    // Trate outras exceções gerais, se necessário
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }

        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txtCodCidade.Text))
            {
                camposFaltantes.Add("Código da cidade");
            }
            else
            {
                if (!int.TryParse(txtCodCidade.Text, out int codCidade) || codCidade <= 0)
                {
                    camposFaltantes.Add("Código da cidade (deve ser um número maior que zero)");
                }
            }

            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                camposFaltantes.Add("Nome");
            }

            if (TipoCliente == "F")
            {
                if (string.IsNullOrWhiteSpace(txtRG.Text))
                {
                    camposFaltantes.Add("RG");
                }
                if (string.IsNullOrWhiteSpace(txtCPFouCNPJ.Text) && txtCPFouCNPJ.Enabled)
                {
                    camposFaltantes.Add("CPF");
                }
            }
            else if (TipoCliente == "J")
            {
                var result = VerificarPais();
                if (result && string.IsNullOrWhiteSpace(txtCPFouCNPJ.Text))
                {
                    camposFaltantes.Add("CNPJ");
                }
            }

            if (string.IsNullOrWhiteSpace(txtCodCondPag.Text))
            {
                camposFaltantes.Add("Código da condição de pagamento");
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                camposFaltantes.Add("E-mail");
            }
            if (string.IsNullOrWhiteSpace(txtBairro.Text))
            {
                camposFaltantes.Add("Bairro");
            }
            if (string.IsNullOrWhiteSpace(txtLogradouro.Text))
            {
                camposFaltantes.Add("Logradouro");
            }
            if (string.IsNullOrWhiteSpace(cmbStatus.Text))
            {
                camposFaltantes.Add("Status");
            }

            // Verificação da data de nascimento
            if (dtNascimento.Value > DateTime.Now)
            {
                camposFaltantes.Add("Data (não pode ser uma data futura)");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos corretamente: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        protected virtual bool VerificarPais()
        {
            if (txtCodCidade.Text != string.Empty)
            {
                CTLCidades aCTLCidade = new CTLCidades();
                Cidades cidade = aCTLCidade.BuscarCidadePorId(Convert.ToInt32(txtCodCidade.Text));
                bool obrigatorioRGouCPF = cidade.OEstado.OPais.Pais.Equals("Brasil", StringComparison.OrdinalIgnoreCase);
                return obrigatorioRGouCPF;
            }
            else { return false; }

        }

        private void txtNumero_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }
        private void txtCodCidade_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null; // Remove o botão "SALVAR" como botão padrão
        }

        protected virtual void txtCodCidade_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodCidade.Text))
            {
                txtCodCidade.Clear();
                txtCidade.Clear();
            }
            else if (int.TryParse(txtCodCidade.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique a cidade correspondente
                CTLCidades aCTLCidade = new CTLCidades();
                Cidades cidade = aCTLCidade.BuscarCidadePorId(cod);

                if (cidade == null)
                {
                    MessageBox.Show("Código inexistente.");
                    Limpar();
                }
                else
                {
                    var result = VerificarPais();
                    if (result)
                        lblCPFouCNPJ.Visible = true;
                    else
                        lblCPFouCNPJ.Visible = false;
                    VerificarAtivo(cidade);
                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                Limpar();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void VerificarAtivo(Cidades cidade)
        {
            if (cidade.StatusCidade == "I")
            {
                var result = MessageBox.Show("A cidade associada a este código está inativa. Deseja continuar?",
                                             "Cidade Inativa",
                                             MessageBoxButtons.YesNo,
                                             MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    txtCidade.Text = cidade.Cidade;
                    VerificarCamposJuridicosFisicos();
                }
                else
                {
                    Limpar();
                }
            }
            else
            {
                txtCidade.Text = cidade.Cidade;
                VerificarCamposJuridicosFisicos();
            }
        }

        protected virtual void LimparEndereco()
        { // if valor = false nao vai limpar o txtCep
            txtCEP.Clear();
            txtCodCidade.Enabled = false;
            txtNum.Clear();
            txtLogradouro.Clear();
            txtBairro.Clear();
            txtComplemento.Clear();
            txtCPFouCNPJ.Clear();
        }

        protected virtual void VerificarCamposJuridicosFisicos()
        {
            var result = VerificarPais();
            if (result)
            {
                DesbloquearCampos();
                // Caso seja brasileiro
                if (TipoCliente == "F") // pessoa fisica 
                {
                    lblCPFouCNPJ.Visible = true;
                    lblCPFouCNPJ.Text = "CPF";
                    lblRG.Text = "RG";
                    lblCPFouCNPJ.Visible = true;
                }
                else // Pessoa jurídica brasileira
                {
                    lblCPFouCNPJ.Text = "CNPJ";
                    lblRG.Text = "RG";
                    lblCPFouCNPJ.Visible = true;
                }
            }
            else
            {
                // Caso não seja brasileiro

                if (TipoCliente == "F")
                {
                    txtCPFouCNPJ.Enabled = false;
                    txtCPFouCNPJ.Text = "";
                    lblCPFouCNPJ.Visible = false;
                    lblRG.Text = "RG";
                    lblCPFouCNPJ.Visible = true;
                }
                else// juridico extrangeiro
                {
                    lblCPFouCNPJ.Visible = false;
                }
            }
        }

        private void Limpar()
        {
            txtCodCidade.Clear();
            txtCidade.Clear();
            txtCodCidade.Focus();
        }

        private void rbCPF_CheckedChanged(object sender, EventArgs e)
        {
            txtRG.Text = "";
        }
        
        private async void btnBuscaCep_Click(object sender, EventArgs e)
        {
            string cep = txtCEP.Text.Trim(); // Obtém o CEP digitado no campo

            if (!string.IsNullOrEmpty(cep))
            {
                // Realiza a consulta do CEP
                string resultado = await Operacao.ConsultarCepAsync(cep);

                if (resultado != null)
                {
                    // Divida a string de resultado em campos individuais
                    string[] campos = resultado.Split(',');

                    // Encontre os valores específicos para cada campo
                    string logradouro = campos.FirstOrDefault(c => c.Contains("Logradouro:"))?.Replace("Logradouro:", "").Trim();
                    string bairro = campos.FirstOrDefault(c => c.Contains("Bairro:"))?.Replace("Bairro:", "").Trim();
                    string uf = campos.FirstOrDefault(c => c.Contains("UF:"))?.Replace("UF:", "").Trim();
                    string cidadeNome = campos.FirstOrDefault(c => c.Contains("Cidade:"))?.Replace("Cidade:", "").Trim();

                    // Preenche os campos do formulário
                    txtLogradouro.Text = logradouro ?? string.Empty;
                    txtBairro.Text = bairro ?? string.Empty;

                    // Verifica se a cidade já está cadastrada usando o novo método
                    CTLCidades ctlCidades = new CTLCidades();
                    Cidades cidade = ctlCidades.BuscarCidadePorNomeEUF(cidadeNome, uf);

                    if (cidade != null)
                    {
                        txtCodCidade.Text = cidade.ID.ToString();
                        txtCidade.Text = cidade.Cidade;
                        txtCodCidade.Enabled = false;
                        txtCPFouCNPJ.Clear();
                        var result = VerificarPais();
                        if (result)
                            lblCPFouCNPJ.Visible = true;
                        else
                            lblCPFouCNPJ.Visible = false;

                    }
                    else
                    {
                        // Caso a cidade não esteja cadastrada, pergunta se deseja adicionar
                        DialogResult dialogResult = MessageBox.Show($"A cidade {cidadeNome} - {uf} não está cadastrada. Deseja adicionar?", "Cidade não encontrada", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            // Chama o método para buscar e adicionar a cidade
                            btnBuscaCid_Click(sender, e);

                        }
                        else
                        {
                            txtCodCidade.Text = string.Empty;
                            txtCidade.Text = cidadeNome ?? string.Empty;
                        }
                    }

                }
                else
                {
                    // Lida com erros ou CEP inválido
                    Console.WriteLine("Erro na consulta de CEP ou CEP inválido.");
                }
            }
        }

        private void txtTelefone_Leave(object sender, EventArgs e)
        {
            string fone = txtTelefone.Text.Trim();

            if (!string.IsNullOrEmpty(fone) && !Operacao.IsTelefone(fone))
            {
                MessageBox.Show("Número de telefone inválido. Por favor, insira um Número válido.");
                txtTelefone.Focus();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtCelular_Leave(object sender, EventArgs e)
        {
            string fone = txtCelular.Text.Trim();

            if (!string.IsNullOrEmpty(fone) && !Operacao.IsTelefone(fone))
            {
                MessageBox.Show("Número de celular inválido. Por favor, insira um Número válido.");
                txtCelular.Focus();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtCodCondicao_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtCodCondicao_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodCondPag.Text))
                LimparCondPg();
            else if (int.TryParse(txtCodCondPag.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente
                CTLCondicaoPagamento aCTLcon = new CTLCondicaoPagamento();
                CondicaoPagamento condicao = aCTLcon.BuscarCondicaoPagamentoPorId(cod);

                if (condicao == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparCondPg();
                }

                else
                {
                    txtCondPag.Text = condicao.Condicao;
                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparCondPg();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void LimparCondPg()
        {
            txtCondPag.Clear();
            txtCodCondPag.Clear();
        }

        protected virtual void txtCodCondicao_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = null; // Remove o botão "SALVAR" como botão padrão
        }
        private void btnCondPag_Click(object sender, EventArgs e)
        {
            using (FrmConsultaCondicaoPagamento frm = new FrmConsultaCondicaoPagamento())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txtCodCondPag.Text = IdSelecionado.ToString();
                txtCondPag.Text = NomeSelecionado;
                txtCodCondicao_Leave(txtCodCondPag, EventArgs.Empty);

            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);
        }

        private void FrmCadastroClienteII_Load(object sender, EventArgs e)
        {

        }

        //Os outros métodos similares não estão atribuídos aos seus respectivos eventos ainda!
        private void cmbFisJur_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(cmbFisJur.Text))
            {
                if (cmbFisJur.Text.Contains("F"))
                    PessoaFisica(true);
                else if (cmbFisJur.Text.Contains("J"))
                    PessoaJuridica(true);
            }
        }

        public void VerCampos(bool valor) //Alterado
        {
            base.BloquearCampos();

            //Labels
            lblNome.Visible = valor;
            lblApelido.Visible = valor;
            lblSexo.Visible = valor;
            lblNasc.Visible = valor;
            lblEmail.Visible = valor;
            lblTelefone.Visible = valor;
            lblCelular.Visible = valor;
            lblCEP.Visible = valor;
            lblCodCidade.Visible = valor;
            lblCidade.Visible = valor;
            lblBairro.Visible = valor;
            lblLogradouro.Visible = valor;
            lblComplemento.Visible = valor;
            lblNum.Visible = valor;
            lblRG.Visible = valor;
            lblCPFouCNPJ.Visible = valor;
            lblCodCondPag.Visible = valor;
            lblCondPag.Visible = valor;
            lblDtCriacao.Visible = valor;
            lblDtUltMod.Visible = valor;
            lblCodCondPag.Visible = valor;
            lblCondPag.Visible = valor;

            //TextBox
            txtNome.Visible = valor;
            txtApelido.Visible = valor;
            dtNascimento.Visible = valor;
            txtEmail.Visible = valor;
            txtTelefone.Visible = valor;
            txtCelular.Visible = valor;
            txtCEP.Visible = valor;
            txtCodCidade.Visible = valor;
            txtCidade.Visible = valor;
            txtBairro.Visible = valor;
            txtLogradouro.Visible = valor;
            txtComplemento.Visible = valor;
            txtNum.Visible = valor;
            txtRG.Visible = valor;
            txtCPFouCNPJ.Visible = valor;
            txtCodCondPag.Visible = valor;
            txtCondPag.Visible = valor;
            txtDtCriacao.Visible = valor;
            txtDtUltMod.Visible = valor;

            //Combobox
            cmbSexo.Visible = valor;

            //Button
            btnBuscaCid.Visible = valor;
            btnBuscaCep.Visible = valor;
            btnCondPag.Visible = valor;
        }

        protected virtual void PessoaFisica(bool limparCampos)
        {
            VerCampos (true);
            cmbSexo.Visible = true;
            lblSexo.Visible = true;
            txtApelido.Size = new System.Drawing.Size(158, 27);
            lblRG.Visible = true;
            txtRG.Visible = true;
            txtCPFouCNPJ.Size = new System.Drawing.Size(115, 27);
            txtCPFouCNPJ.Location = new Point(135, 271); //
            lblCPFouCNPJ.Text = "CPF";
            lblCPFouCNPJ.Location = new Point(135, 255); //Coords aqui
            TipoCliente = "F";
            lblNome.Text = "Cliente";
            lblApelido.Text = "Apelido";
            lblNasc.Text = "Data de nascimento";
            lblRG.Visible = true;
            lblCPFouCNPJ.Visible = true;

            if (limparCampos)
                LimparCampos();

        }
        protected virtual void PessoaJuridica(bool limparCampos)
        {
            VerCampos (true);
            txtCPFouCNPJ.Enabled = true;
            cmbSexo.Visible = false;
            lblSexo.Visible = false;
            lblCPFouCNPJ.Text = "CNPJ";
            lblCPFouCNPJ.Location = new Point(8, 255); //
            txtApelido.Size = new System.Drawing.Size(345, 27);
            txtCPFouCNPJ.Size = new System.Drawing.Size(226, 27); //Coords aqui
            txtCPFouCNPJ.Location = new Point(11, 270); //
            lblRG.Visible = false;
            lblNome.Text = "Razão Social";
            lblApelido.Text = "Nome Fantasia";
            lblNasc.Text = "Data Fundação";

            lblRG.Visible = false;
            txtRG.Visible = false;

            TipoCliente = "J";
            var pais = VerificarPais();
            /*if (pais)
                lblCPFouCNPJ.Visible = true;
            else
                //lblCPFouCNPJ.Visible = false; //Aqui vai dar merda, certeza*/
            if (limparCampos)
                LimparCampos();
        }

        private void txtNome_KeyDown(object sender, KeyEventArgs e)
        {
            Operacao.BloquearKeyDowControlC(sender, e);
        }

        private void btnBuscaCid_Click(object sender, EventArgs e)
        {
            using (FrmConsultaCidade frm = new FrmConsultaCidade())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                // Agora, defina os valores nos campos do seu formulário de cadastro
                txtCodCidade.Text = IdSelecionado.ToString();
                txtCidade.Text = NomeSelecionado;
                if (IdSelecionado > 0)
                {
                    // Busque a cidade correspondente
                    CTLCidades aCTLCidade = new CTLCidades();
                    Cidades cidade = aCTLCidade.BuscarCidadePorId(IdSelecionado);

                    if (cidade != null)
                    {
                        VerificarAtivo(cidade);
                        LimparEndereco();
                    }
                    else
                    {
                        MessageBox.Show("Código inexistente.");
                        Limpar();
                    }
                }
            }
        }

        private void txtCPFouCNPJ_Leave_1(object sender, EventArgs e)
        {
            string documento = txtCPFouCNPJ.Text.Trim();

            // Se o campo estiver vazio, sai do método
            if (string.IsNullOrEmpty(documento))
            {
                return;
            }

            // Verifica o país
            bool verificapais = VerificarPais();

            // Validação inicial para tipo de documento
            if ((TipoCliente == "F" && lblCPFouCNPJ.Text == "CPF" && !Operacao.IsCpf(documento)) ||
                (TipoCliente == "J" && lblCPFouCNPJ.Text == "CNPJ" && verificapais && !Operacao.IsCnpj(documento)))
            {
                MessageBox.Show("Documento inválido. Por favor, insira um documento válido.");
                txtCPFouCNPJ.Focus();
                return;
            }

            // Verifica se o documento já existe no banco de dados
            var result = aCTLClientes.BuscarClientePorDocumento(documento);
            if (result != "OK" && documento != ClienteAntigo.CPF)
            {
                MessageBox.Show("Erro, " + result);
                txtCPFouCNPJ.Focus();
                txtCPFouCNPJ.Text = "";
                return;
            }

            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtEmail_Leave_1(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();

            if (!string.IsNullOrEmpty(email) && !Operacao.IsEmail(email))
            {
                MessageBox.Show("Endereço de e-mail inválido. Por favor, insira um e-mail válido.");
                txtEmail.Focus();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtRG_Leave_1(object sender, EventArgs e)
        {
            string documento = txtRG.Text.Trim();

            // Se o campo estiver vazio, sai do método
            if (string.IsNullOrEmpty(documento))
            {
                return;
            }

            // Verifica se o documento já existe no banco de dados
            var result = aCTLClientes.BuscarClientePorRG(documento);
            if (result != "OK" && documento != ClienteAntigo.RG)
            {
                MessageBox.Show("Erro, " + result);
                txtRG.Text = "";
                txtRG.Focus();
                return;
            }
        }

        private void txtRG_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtCPFouCNPJ_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);

        }
        private void txtCodCidade_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtCodCidade_TextChanged(object sender, EventArgs e)
        {

        }
        private void txtTelefone_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtCelular_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtNome_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);
        }

        private void txtApelido_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);
        }

        private void txtLogradouro_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);
        }

        private void txtComplemento_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);

        }

        private void txtBairro_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);

        }

        private void txtCidade_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarNomes(sender, e);

        }

        private void txtCEP_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void txtCodCondPag_KeyPress(object sender, KeyPressEventArgs e)
        {
            Operacao.ValidarValorKeyPress((System.Windows.Forms.TextBox)sender, e);
        }

        private void txtCondPag_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtApelido_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTelefone_Leave_1(object sender, EventArgs e)
        {
            string fone = txtTelefone.Text.Trim();

            if (!string.IsNullOrEmpty(fone) && !Operacao.IsTelefone(fone))
            {
                MessageBox.Show("Número de telefone inválido. Por favor, insira um Número válido.");
                txtTelefone.Focus();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtCelular_Leave_1(object sender, EventArgs e)
        {
            string fone = txtCelular.Text.Trim();

            if (!string.IsNullOrEmpty(fone) && !Operacao.IsTelefone(fone))
            {
                MessageBox.Show("Número de celular inválido. Por favor, insira um Número válido.");
                txtCelular.Focus();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtNome_KeyDown_1(object sender, KeyEventArgs e)
        {
            Operacao.BloquearKeyDowControlC(sender, e);
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
