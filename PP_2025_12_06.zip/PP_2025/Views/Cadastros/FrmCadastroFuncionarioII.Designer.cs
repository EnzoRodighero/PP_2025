﻿namespace PP_2025
{
    partial class FrmCadastroFuncionarioII
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.lblSenha = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbSexo
            // 
            this.cmbSexo.Location = new System.Drawing.Point(651, 88);
            // 
            // btnBuscaCep
            // 
            this.btnBuscaCep.Click += new System.EventHandler(this.btnBuscaCep_Click);
            // 
            // btnBuscaCid
            // 
            this.btnBuscaCid.Click += new System.EventHandler(this.btnBuscaCid_Click);
            // 
            // btnBuscarCargo
            // 
            this.btnBuscarCargo.Click += new System.EventHandler(this.btnBuscarCargo_Click);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(11, 89);
            this.txtNome.Size = new System.Drawing.Size(424, 32);
            // 
            // lblTipo
            // 
            this.lblTipo.Location = new System.Drawing.Point(12, 431);
            this.lblTipo.Visible = false;
            // 
            // lblNome
            // 
            this.lblNome.Location = new System.Drawing.Point(12, 67);
            // 
            // txtApelido
            // 
            this.txtApelido.Location = new System.Drawing.Point(441, 89);
            // 
            // lblApelido
            // 
            this.lblApelido.Location = new System.Drawing.Point(438, 67);
            // 
            // lblSexo
            // 
            this.lblSexo.Location = new System.Drawing.Point(648, 67);
            // 
            // lblCPFouCNPJ
            // 
            this.lblCPFouCNPJ.Size = new System.Drawing.Size(37, 18);
            this.lblCPFouCNPJ.Text = "CPF";
            // 
            // txtSalario
            // 
            this.txtSalario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalario_KeyPress);
            // 
            // cmbFisJur
            // 
            this.cmbFisJur.Location = new System.Drawing.Point(11, 452);
            this.cmbFisJur.Visible = false;
            // 
            // txtUltAltFunc
            // 
            this.txtUltAltFunc.Visible = false;
            // 
            // lblUltAltFunc
            // 
            this.lblUltAltFunc.Visible = false;
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(12, 13);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(15, 33);
            // 
            // txtSenha
            // 
            this.txtSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSenha.Location = new System.Drawing.Point(893, 89);
            this.txtSenha.MaxLength = 10;
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '#';
            this.txtSenha.Size = new System.Drawing.Size(273, 32);
            this.txtSenha.TabIndex = 602;
            this.txtSenha.UseSystemPasswordChar = true;
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Location = new System.Drawing.Point(890, 68);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(51, 18);
            this.lblSenha.TabIndex = 603;
            this.lblSenha.Text = "Senha";
            // 
            // FrmCadastroFuncionarioII
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(1201, 554);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.txtSenha);
            this.Name = "FrmCadastroFuncionarioII";
            this.Text = "Frm Cadastro Funcionários";
            this.Load += new System.EventHandler(this.FrmCadastroFuncionarioII_Load);
            this.Controls.SetChildIndex(this.cmbFisJur, 0);
            this.Controls.SetChildIndex(this.txtNome, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.lblTipo, 0);
            this.Controls.SetChildIndex(this.lblNome, 0);
            this.Controls.SetChildIndex(this.txtApelido, 0);
            this.Controls.SetChildIndex(this.lblApelido, 0);
            this.Controls.SetChildIndex(this.cmbSexo, 0);
            this.Controls.SetChildIndex(this.lblSexo, 0);
            this.Controls.SetChildIndex(this.txtLogradouro, 0);
            this.Controls.SetChildIndex(this.lblLogradouro, 0);
            this.Controls.SetChildIndex(this.txtNum, 0);
            this.Controls.SetChildIndex(this.lblNum, 0);
            this.Controls.SetChildIndex(this.txtComplemento, 0);
            this.Controls.SetChildIndex(this.lblComplemento, 0);
            this.Controls.SetChildIndex(this.txtBairro, 0);
            this.Controls.SetChildIndex(this.lblBairro, 0);
            this.Controls.SetChildIndex(this.txtCidade, 0);
            this.Controls.SetChildIndex(this.lblCidade, 0);
            this.Controls.SetChildIndex(this.txtCEP, 0);
            this.Controls.SetChildIndex(this.lblCEP, 0);
            this.Controls.SetChildIndex(this.btnBuscaCep, 0);
            this.Controls.SetChildIndex(this.txtEmail, 0);
            this.Controls.SetChildIndex(this.lblEmail, 0);
            this.Controls.SetChildIndex(this.txtTelefone, 0);
            this.Controls.SetChildIndex(this.lblTelefone, 0);
            this.Controls.SetChildIndex(this.txtCelular, 0);
            this.Controls.SetChildIndex(this.lblCelular, 0);
            this.Controls.SetChildIndex(this.txtRG, 0);
            this.Controls.SetChildIndex(this.lblRG, 0);
            this.Controls.SetChildIndex(this.txtCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.lblCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.dtNascimento, 0);
            this.Controls.SetChildIndex(this.lblNasc, 0);
            this.Controls.SetChildIndex(this.txtCodCargo, 0);
            this.Controls.SetChildIndex(this.lblCodCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscaCid, 0);
            this.Controls.SetChildIndex(this.txtCargo, 0);
            this.Controls.SetChildIndex(this.lblCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscarCargo, 0);
            this.Controls.SetChildIndex(this.txtSalario, 0);
            this.Controls.SetChildIndex(this.lblSalario, 0);
            this.Controls.SetChildIndex(this.txtDtCriacao, 0);
            this.Controls.SetChildIndex(this.lblDtCriacao, 0);
            this.Controls.SetChildIndex(this.txtDtUltMod, 0);
            this.Controls.SetChildIndex(this.lblDtUltMod, 0);
            this.Controls.SetChildIndex(this.txtUltAltFunc, 0);
            this.Controls.SetChildIndex(this.lblUltAltFunc, 0);
            this.Controls.SetChildIndex(this.cmbStatus, 0);
            this.Controls.SetChildIndex(this.txtCodCidade, 0);
            this.Controls.SetChildIndex(this.lblCodCidade, 0);
            this.Controls.SetChildIndex(this.txtSenha, 0);
            this.Controls.SetChildIndex(this.lblSenha, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label lblSenha;
    }
}
