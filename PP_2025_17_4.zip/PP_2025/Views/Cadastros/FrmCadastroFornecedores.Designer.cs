﻿namespace PP_2025
{
    partial class FrmCadastroFornecedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInscMunicipal = new System.Windows.Forms.TextBox();
            this.txtInscEstadual = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.pn1.SuspendLayout();
            this.pn2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBuscarCondicaoPG
            // 
            this.btnBuscarCondicaoPG.Location = new System.Drawing.Point(777, 261);
            this.btnBuscarCondicaoPG.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // btnCEP
            // 
            this.btnCEP.Location = new System.Drawing.Point(338, 142);
            this.btnCEP.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // btnBuscarCidades
            // 
            this.btnBuscarCidades.Location = new System.Drawing.Point(897, 142);
            this.btnBuscarCidades.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbOBTipoC
            // 
            this.lbOBTipoC.Location = new System.Drawing.Point(148, 93);
            this.lbOBTipoC.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbTipoCLiente
            // 
            this.lbTipoCLiente.Location = new System.Drawing.Point(162, 93);
            this.lbTipoCLiente.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbTipoCLiente.Size = new System.Drawing.Size(122, 20);
            this.lbTipoCLiente.Text = "Nome Fantasia";
            // 
            // pn1
            // 
            this.pn1.Controls.Add(this.txtInscMunicipal);
            this.pn1.Controls.Add(this.txtInscEstadual);
            this.pn1.Controls.Add(this.label16);
            this.pn1.Controls.Add(this.label14);
            this.pn1.Location = new System.Drawing.Point(31, 152);
            this.pn1.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.pn1.Size = new System.Drawing.Size(1077, 303);
            this.pn1.Visible = false;
            this.pn1.Controls.SetChildIndex(this.label2, 0);
            this.pn1.Controls.SetChildIndex(this.lblCpf, 0);
            this.pn1.Controls.SetChildIndex(this.lblrg, 0);
            this.pn1.Controls.SetChildIndex(this.lbOBBairro, 0);
            this.pn1.Controls.SetChildIndex(this.label1, 0);
            this.pn1.Controls.SetChildIndex(this.label14, 0);
            this.pn1.Controls.SetChildIndex(this.label16, 0);
            this.pn1.Controls.SetChildIndex(this.txtInscEstadual, 0);
            this.pn1.Controls.SetChildIndex(this.txtInscMunicipal, 0);
            this.pn1.Controls.SetChildIndex(this.lbCidade, 0);
            this.pn1.Controls.SetChildIndex(this.txtCidade, 0);
            this.pn1.Controls.SetChildIndex(this.lblCodCidade, 0);
            this.pn1.Controls.SetChildIndex(this.txtCodCidade, 0);
            this.pn1.Controls.SetChildIndex(this.btnBuscarCidades, 0);
            this.pn1.Controls.SetChildIndex(this.lbOBCodCidade, 0);
            this.pn1.Controls.SetChildIndex(this.txtRG, 0);
            this.pn1.Controls.SetChildIndex(this.lbEmail, 0);
            this.pn1.Controls.SetChildIndex(this.txtTelefone, 0);
            this.pn1.Controls.SetChildIndex(this.lbTelefone, 0);
            this.pn1.Controls.SetChildIndex(this.lbCelular, 0);
            this.pn1.Controls.SetChildIndex(this.txtCelular, 0);
            this.pn1.Controls.SetChildIndex(this.lbCep, 0);
            this.pn1.Controls.SetChildIndex(this.txtCep, 0);
            this.pn1.Controls.SetChildIndex(this.lbBairro, 0);
            this.pn1.Controls.SetChildIndex(this.txtBairro, 0);
            this.pn1.Controls.SetChildIndex(this.txtEmail, 0);
            this.pn1.Controls.SetChildIndex(this.lbOBEmail, 0);
            this.pn1.Controls.SetChildIndex(this.lbLogradouro, 0);
            this.pn1.Controls.SetChildIndex(this.txtLogradouro, 0);
            this.pn1.Controls.SetChildIndex(this.lbOBLogradouro, 0);
            this.pn1.Controls.SetChildIndex(this.lbComplemento, 0);
            this.pn1.Controls.SetChildIndex(this.txtComplemento, 0);
            this.pn1.Controls.SetChildIndex(this.lbNumero, 0);
            this.pn1.Controls.SetChildIndex(this.txtNumero, 0);
            this.pn1.Controls.SetChildIndex(this.dtNascimento, 0);
            this.pn1.Controls.SetChildIndex(this.lbNascimento, 0);
            this.pn1.Controls.SetChildIndex(this.btnCEP, 0);
            this.pn1.Controls.SetChildIndex(this.cmbStatus, 0);
            this.pn1.Controls.SetChildIndex(this.lblStatus, 0);
            this.pn1.Controls.SetChildIndex(this.lbOBStatus, 0);
            this.pn1.Controls.SetChildIndex(this.txtCPFouCNPJ, 0);
            this.pn1.Controls.SetChildIndex(this.txtCodCondicao, 0);
            this.pn1.Controls.SetChildIndex(this.lbCodigoCondicao, 0);
            this.pn1.Controls.SetChildIndex(this.txtCondicao, 0);
            this.pn1.Controls.SetChildIndex(this.lbCondicaoPg, 0);
            this.pn1.Controls.SetChildIndex(this.btnBuscarCondicaoPG, 0);
            this.pn1.Controls.SetChildIndex(this.lbCpfOuCnpj, 0);
            this.pn1.Controls.SetChildIndex(this.lbRG, 0);
            // 
            // pn2
            // 
            this.pn2.Location = new System.Drawing.Point(368, 90);
            this.pn2.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.pn2.Visible = false;
            // 
            // cmbTipoCliente
            // 
            this.cmbTipoCliente.Location = new System.Drawing.Point(166, 114);
            this.cmbTipoCliente.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            // 
            // lbOBSexo
            // 
            this.lbOBSexo.Visible = false;
            // 
            // lbApelido
            // 
            this.lbApelido.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbApelido.Size = new System.Drawing.Size(122, 20);
            this.lbApelido.Text = "Nome Fantasia";
            // 
            // txtApelido
            // 
            this.txtApelido.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtApelido.Size = new System.Drawing.Size(341, 32);
            // 
            // lbSexo
            // 
            this.lbSexo.Visible = false;
            // 
            // cmbSexo
            // 
            this.cmbSexo.Visible = false;
            // 
            // lbCliente
            // 
            this.lbCliente.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbCliente.Size = new System.Drawing.Size(108, 20);
            this.lbCliente.Text = "Razão Social";
            // 
            // txtNome
            // 
            this.txtNome.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbRG
            // 
            this.lbRG.Location = new System.Drawing.Point(177, 235);
            this.lbRG.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbCpfOuCnpj
            // 
            this.lbCpfOuCnpj.Location = new System.Drawing.Point(28, 235);
            this.lbCpfOuCnpj.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbCondicaoPg
            // 
            this.lbCondicaoPg.Location = new System.Drawing.Point(460, 237);
            this.lbCondicaoPg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            // 
            // txtCondicao
            // 
            this.txtCondicao.Location = new System.Drawing.Point(463, 259);
            this.txtCondicao.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbCodigoCondicao
            // 
            this.lbCodigoCondicao.Location = new System.Drawing.Point(329, 237);
            this.lbCodigoCondicao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            // 
            // txtCodCondicao
            // 
            this.txtCodCondicao.Location = new System.Drawing.Point(332, 259);
            this.txtCodCondicao.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // txtCPFouCNPJ
            // 
            this.txtCPFouCNPJ.Location = new System.Drawing.Point(31, 259);
            this.txtCPFouCNPJ.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtCPFouCNPJ.Leave += new System.EventHandler(this.txtCPFouCNPJ_Leave);
            // 
            // lbOBStatus
            // 
            this.lbOBStatus.Location = new System.Drawing.Point(881, 235);
            this.lbOBStatus.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lblStatus
            // 
            this.lblStatus.Location = new System.Drawing.Point(900, 235);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbNascimento
            // 
            this.lbNascimento.Location = new System.Drawing.Point(27, 65);
            this.lbNascimento.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbNascimento.Size = new System.Drawing.Size(146, 20);
            this.lbNascimento.Text = "Data de Fundação";
            // 
            // dtNascimento
            // 
            this.dtNascimento.Location = new System.Drawing.Point(31, 87);
            this.dtNascimento.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(903, 199);
            this.txtNumero.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbNumero
            // 
            this.lbNumero.Location = new System.Drawing.Point(900, 176);
            this.lbNumero.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtComplemento
            // 
            this.txtComplemento.Location = new System.Drawing.Point(670, 199);
            this.txtComplemento.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbComplemento
            // 
            this.lbComplemento.Location = new System.Drawing.Point(667, 176);
            this.lbComplemento.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbOBLogradouro
            // 
            this.lbOBLogradouro.Location = new System.Drawing.Point(294, 176);
            this.lbOBLogradouro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtLogradouro
            // 
            this.txtLogradouro.Location = new System.Drawing.Point(312, 199);
            this.txtLogradouro.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbLogradouro
            // 
            this.lbLogradouro.Location = new System.Drawing.Point(316, 176);
            this.lbLogradouro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbOBEmail
            // 
            this.lbOBEmail.Location = new System.Drawing.Point(375, 65);
            this.lbOBEmail.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbOBBairro
            // 
            this.lbOBBairro.Location = new System.Drawing.Point(10, 176);
            this.lbOBBairro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(392, 87);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // txtBairro
            // 
            this.txtBairro.Location = new System.Drawing.Point(31, 199);
            this.txtBairro.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbBairro
            // 
            this.lbBairro.Location = new System.Drawing.Point(30, 176);
            this.lbBairro.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtCep
            // 
            this.txtCep.Location = new System.Drawing.Point(207, 141);
            this.txtCep.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbCep
            // 
            this.lbCep.Location = new System.Drawing.Point(203, 122);
            this.lbCep.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(31, 141);
            this.txtCelular.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbCelular
            // 
            this.lbCelular.Location = new System.Drawing.Point(28, 122);
            this.lbCelular.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lbTelefone
            // 
            this.lbTelefone.Location = new System.Drawing.Point(784, 65);
            this.lbTelefone.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(786, 87);
            this.txtTelefone.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbEmail
            // 
            this.lbEmail.Location = new System.Drawing.Point(390, 65);
            this.lbEmail.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtRG
            // 
            this.txtRG.Location = new System.Drawing.Point(181, 259);
            this.txtRG.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbOBCodCidade
            // 
            this.lbOBCodCidade.Location = new System.Drawing.Point(440, 122);
            this.lbOBCodCidade.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // txtCodCidade
            // 
            this.txtCodCidade.Location = new System.Drawing.Point(463, 141);
            this.txtCodCidade.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lblCodCidade
            // 
            this.lblCodCidade.Location = new System.Drawing.Point(459, 121);
            this.lblCodCidade.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(615, 141);
            this.txtCidade.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // lbCidade
            // 
            this.lbCidade.Location = new System.Drawing.Point(609, 121);
            this.lbCidade.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(9, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // cmbStatus
            // 
            this.cmbStatus.Location = new System.Drawing.Point(903, 258);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            // 
            // lblrg
            // 
            this.lblrg.Location = new System.Drawing.Point(154, 235);
            this.lblrg.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // lblCpf
            // 
            this.lblCpf.Location = new System.Drawing.Point(10, 237);
            this.lblCpf.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(316, 237);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(828, 467);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            // 
            // panel3
            // 
            this.panel3.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.panel3.Size = new System.Drawing.Size(1139, 10);
            // 
            // lblCodigo
            // 
            this.lblCodigo.Location = new System.Drawing.Point(58, 96);
            this.lblCodigo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(59, 115);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(953, 467);
            this.btnSair.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            // 
            // txtInscMunicipal
            // 
            this.txtInscMunicipal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtInscMunicipal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInscMunicipal.Location = new System.Drawing.Point(31, 30);
            this.txtInscMunicipal.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtInscMunicipal.MaxLength = 50;
            this.txtInscMunicipal.Name = "txtInscMunicipal";
            this.txtInscMunicipal.Size = new System.Drawing.Size(499, 32);
            this.txtInscMunicipal.TabIndex = 601;
            // 
            // txtInscEstadual
            // 
            this.txtInscEstadual.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtInscEstadual.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInscEstadual.Location = new System.Drawing.Point(540, 30);
            this.txtInscEstadual.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtInscEstadual.MaxLength = 50;
            this.txtInscEstadual.Name = "txtInscEstadual";
            this.txtInscEstadual.Size = new System.Drawing.Size(468, 32);
            this.txtInscEstadual.TabIndex = 602;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(539, 6);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(147, 20);
            this.label16.TabIndex = 604;
            this.label16.Text = "Inscrição Estadual";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(27, 7);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(153, 20);
            this.label14.TabIndex = 603;
            this.label14.Text = "Inscrição Municipal";
            // 
            // FrmCadastroFornecedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(1139, 501);
            this.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.Name = "FrmCadastroFornecedores";
            this.Text = "Fornecedores";
            this.pn1.ResumeLayout(false);
            this.pn1.PerformLayout();
            this.pn2.ResumeLayout(false);
            this.pn2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInscMunicipal;
        private System.Windows.Forms.TextBox txtInscEstadual;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
    }
}
