﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP_2025
{
    internal class Interfaces
    {
        // CLASSES 
        private FormaPagamento aFormaPagamento;
        private CondicaoPagamento aCondicaoPagamento;

        private Paises oPais;
        private Estados oEstado;
        private Cidades aCidade;

        private Clientes oCliente;
        private Fornecedores oFornecedor;

        private Cargos oCargo;
        private Funcionarios oFuncionario;

        //Cadastros
        FrmCadastroFormaPagamento ofrmCadFormaPagamento;
        FrmCadastroCondicaoPagamento ofrmCadCondPG;

        FrmCadastroPais ofrmCadPaises;
        FrmCadastroEstado ofrmCadEstados;
        FrmCadastroCidade ofrmCadCidades;

        FrmCadastroClienteII ofrmCadClientes;
        FrmCadastroFornecedoresII ofrmCadFornecedores;

        FrmCadastroCargo ofrmCadCargo;
        FrmCadastroFuncionarioII ofrmCadFuncionario;

        //Consultas
        FrmConsultaFormaPagamento ofrmConFormaPagamento;
        FrmConsultaCondicaoPagamento ofrmConCondPG; 

        FrmConsultaPais ofrmConPaises;
        FrmConsultaEstado ofrmConEstados;
        FrmConsultaCidade ofrmConCidades;

        FrmConsultaCliente ofrmConClientes;
        FrmConsultaFornecedor ofrmConFornecedores;

        FrmConsultaCargo ofrmConCargo;
        FrmConsultaFuncionario ofrmConFuncionario;

        public Interfaces()
        {
            //Classes 
            aFormaPagamento = new FormaPagamento();
            aCondicaoPagamento = new CondicaoPagamento();

            oPais = new Paises();
            oEstado = new Estados();
            aCidade = new Cidades();

            oCliente = new Clientes();
            oFornecedor = new Fornecedores();

            oCargo = new Cargos();
            oFuncionario = new Funcionarios();

            //Cadastros
            ofrmCadFormaPagamento = new FrmCadastroFormaPagamento();
            ofrmCadCondPG = new FrmCadastroCondicaoPagamento();

            ofrmCadPaises = new FrmCadastroPais();
            ofrmCadEstados = new FrmCadastroEstado();
            ofrmCadCidades = new FrmCadastroCidade();

            ofrmCadClientes = new FrmCadastroClienteII();
            ofrmCadFornecedores = new FrmCadastroFornecedoresII();

            ofrmCadCargo = new FrmCadastroCargo();
            ofrmCadFuncionario = new FrmCadastroFuncionarioII();

            //Consultas          
            ofrmConFormaPagamento = new FrmConsultaFormaPagamento();
            ofrmConCondPG = new FrmConsultaCondicaoPagamento();

            ofrmConPaises = new FrmConsultaPais();
            ofrmConEstados = new FrmConsultaEstado();
            ofrmConCidades = new FrmConsultaCidade();

            ofrmConClientes = new FrmConsultaCliente();
            ofrmConFornecedores = new FrmConsultaFornecedor();

            ofrmConCargo = new FrmConsultaCargo();
            ofrmConFuncionario = new FrmConsultaFuncionario();

            //Setar os metodos.
            ofrmConFormaPagamento.SetFrmCadastro(ofrmCadFormaPagamento);
            ofrmConCondPG.SetFrmCadastro(ofrmCadCondPG); 

            ofrmConPaises.SetFrmCadastro(ofrmCadPaises);
            ofrmConEstados.SetFrmCadastro(ofrmCadEstados); 
            ofrmConCidades.SetFrmCadastro(ofrmCadCidades); 
            ofrmCadEstados.SetConsultaPaises(ofrmConPaises);  
            ofrmCadCidades.SetConsultaEstados(ofrmConEstados);

            ofrmConClientes.SetFrmCadastro(ofrmCadClientes); // Incluir Clientes 
            ofrmConFornecedores.SetFrmCadastro(ofrmCadFornecedores); // Incluir Fornecedores
            ofrmConCargo.SetFrmCadastro(ofrmCadCargo); // Incluir Cargo
            ofrmConFuncionario.SetFrmCadastro(ofrmCadFuncionario); // Incluir Funcionario
        }

        public void pecaForm(string tag)
        {
            void PecaFormulario(Form mostra, object consultado)
            {
                if (mostra is FrmConsulta consulta)
                {
                    consulta.ConhecaObj(consultado);
                    consulta.ShowDialog();
                }
            }

            switch (tag) // colocar todos os forms todos.
            {
                //FINANCEIRO
                case "FORMA DE PAGAMENTO": PecaFormulario(ofrmConFormaPagamento, aFormaPagamento); break;
                case "CONDIÇÃO DE PAGAMENTO": PecaFormulario(ofrmConCondPG, aCondicaoPagamento); break;

                //LOCAIS
                case "PAÍSES": PecaFormulario(ofrmConPaises, oPais); break;
                case "ESTADOS": PecaFormulario(ofrmConEstados, oEstado); break;
                case "CIDADES": PecaFormulario(ofrmConCidades, aCidade); break;

                //PESSOAS
                case "CLIENTES": PecaFormulario(ofrmConClientes, oCliente); break;
                case "FORNECEDORES": PecaFormulario(ofrmConFornecedores, oFornecedor); break;
                case "FUNCIONÁRIOS": PecaFormulario(ofrmConFuncionario, oFuncionario); break;

                //FUNÇÕES
                case "CARGOS": PecaFormulario(ofrmConCargo, oCargo); break;
            }
        }

      
        private void Sair()
        {
            DialogResult result = MessageBox.Show("Deseja encerrar a aplicação ?", "confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else 
            {
            
            };
        }
    }
}
