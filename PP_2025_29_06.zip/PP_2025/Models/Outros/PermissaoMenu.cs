﻿using PP_2025;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP_2025
{
    public class PermissaoMenu : Pai
    {

    }
}