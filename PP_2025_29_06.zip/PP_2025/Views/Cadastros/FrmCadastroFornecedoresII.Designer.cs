﻿namespace PP_2025
{
    partial class FrmCadastroFornecedoresII
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInscricaoEstadual = new System.Windows.Forms.TextBox();
            this.lblInscricaoEstadual = new System.Windows.Forms.Label();
            this.txtCodCond = new System.Windows.Forms.TextBox();
            this.lblCodCond = new System.Windows.Forms.Label();
            this.txtCond = new System.Windows.Forms.TextBox();
            this.lblCond = new System.Windows.Forms.Label();
            this.btnBuscaCond = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbSexo
            // 
            this.cmbSexo.Location = new System.Drawing.Point(757, 450);
            this.cmbSexo.Size = new System.Drawing.Size(40, 33);
            this.cmbSexo.Visible = false;
            // 
            // btnBuscaCep
            // 
            this.btnBuscaCep.Click += new System.EventHandler(this.btnBuscaCep_Click);
            // 
            // dtNascimento
            // 
            this.dtNascimento.Location = new System.Drawing.Point(264, 308);
            this.dtNascimento.Size = new System.Drawing.Size(368, 32);
            // 
            // btnBuscaCid
            // 
            this.btnBuscaCid.Click += new System.EventHandler(this.btnBuscaCid_Click);
            // 
            // btnBuscarCargo
            // 
            this.btnBuscarCargo.Location = new System.Drawing.Point(519, 457);
            this.btnBuscarCargo.Visible = false;
            // 
            // txtNome
            // 
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // lblTipo
            // 
            this.lblTipo.Size = new System.Drawing.Size(126, 18);
            this.lblTipo.Text = "Tipo Fornecedor";
            // 
            // lblNome
            // 
            this.lblNome.Size = new System.Drawing.Size(100, 18);
            this.lblNome.Text = "Razão Social";
            // 
            // txtApelido
            // 
            this.txtApelido.Size = new System.Drawing.Size(445, 32);
            // 
            // lblApelido
            // 
            this.lblApelido.Size = new System.Drawing.Size(113, 18);
            this.lblApelido.Text = "Nome Fantasia";
            // 
            // lblSexo
            // 
            this.lblSexo.Location = new System.Drawing.Point(754, 428);
            this.lblSexo.Visible = false;
            this.lblSexo.Click += new System.EventHandler(this.lblSexo_Click);
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(135, 196);
            // 
            // txtEmail
            // 
            this.txtEmail.Size = new System.Drawing.Size(506, 32);
            // 
            // txtTelefone
            // 
            this.txtTelefone.Location = new System.Drawing.Point(523, 254);
            this.txtTelefone.Size = new System.Drawing.Size(206, 32);
            // 
            // lblTelefone
            // 
            this.lblTelefone.Location = new System.Drawing.Point(520, 234);
            // 
            // txtCelular
            // 
            this.txtCelular.Location = new System.Drawing.Point(735, 254);
            this.txtCelular.Size = new System.Drawing.Size(210, 32);
            this.txtCelular.TextChanged += new System.EventHandler(this.txtCelular_TextChanged);
            // 
            // lblCelular
            // 
            this.lblCelular.Location = new System.Drawing.Point(754, 233);
            // 
            // txtRG
            // 
            this.txtRG.Location = new System.Drawing.Point(701, 451);
            this.txtRG.Size = new System.Drawing.Size(49, 32);
            this.txtRG.Visible = false;
            this.txtRG.TextChanged += new System.EventHandler(this.txtRG_TextChanged);
            // 
            // lblRG
            // 
            this.lblRG.Location = new System.Drawing.Point(698, 428);
            this.lblRG.Visible = false;
            // 
            // txtCPFouCNPJ
            // 
            this.txtCPFouCNPJ.Location = new System.Drawing.Point(951, 254);
            this.txtCPFouCNPJ.Size = new System.Drawing.Size(215, 32);
            this.txtCPFouCNPJ.Leave += new System.EventHandler(this.txtCPFouCNPJ_Leave);
            // 
            // lblCPFouCNPJ
            // 
            this.lblCPFouCNPJ.Location = new System.Drawing.Point(948, 233);
            // 
            // lblNasc
            // 
            this.lblNasc.Location = new System.Drawing.Point(261, 287);
            this.lblNasc.Click += new System.EventHandler(this.lblNasc_Click);
            // 
            // txtCodCargo
            // 
            this.txtCodCargo.Location = new System.Drawing.Point(11, 451);
            this.txtCodCargo.Visible = false;
            // 
            // lblCodCargo
            // 
            this.lblCodCargo.Location = new System.Drawing.Point(8, 428);
            this.lblCodCargo.Visible = false;
            // 
            // txtCargo
            // 
            this.txtCargo.Location = new System.Drawing.Point(157, 451);
            this.txtCargo.Visible = false;
            // 
            // lblCargo
            // 
            this.lblCargo.Location = new System.Drawing.Point(158, 428);
            this.lblCargo.Visible = false;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(640, 451);
            this.txtSalario.Size = new System.Drawing.Size(55, 32);
            this.txtSalario.Visible = false;
            // 
            // lblSalario
            // 
            this.lblSalario.Location = new System.Drawing.Point(637, 428);
            this.lblSalario.Visible = false;
            // 
            // cmbFisJur
            // 
            this.cmbFisJur.SelectedIndexChanged += new System.EventHandler(this.cmbFisJur_SelectedIndexChanged);
            // 
            // txtUltAltFunc
            // 
            this.txtUltAltFunc.Visible = false;
            // 
            // lblUltAltFunc
            // 
            this.lblUltAltFunc.Visible = false;
            // 
            // txtDtCriacao
            // 
            this.txtDtCriacao.ReadOnly = true;
            // 
            // txtDtUltMod
            // 
            this.txtDtUltMod.ReadOnly = true;
            // 
            // txtInscricaoEstadual
            // 
            this.txtInscricaoEstadual.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInscricaoEstadual.Location = new System.Drawing.Point(9, 308);
            this.txtInscricaoEstadual.MaxLength = 15;
            this.txtInscricaoEstadual.Name = "txtInscricaoEstadual";
            this.txtInscricaoEstadual.Size = new System.Drawing.Size(246, 32);
            this.txtInscricaoEstadual.TabIndex = 602;
            // 
            // lblInscricaoEstadual
            // 
            this.lblInscricaoEstadual.AutoSize = true;
            this.lblInscricaoEstadual.Location = new System.Drawing.Point(6, 289);
            this.lblInscricaoEstadual.Name = "lblInscricaoEstadual";
            this.lblInscricaoEstadual.Size = new System.Drawing.Size(139, 18);
            this.lblInscricaoEstadual.TabIndex = 603;
            this.lblInscricaoEstadual.Text = "Inscrição Estadual";
            this.lblInscricaoEstadual.Click += new System.EventHandler(this.lblInscricaoEstadual_Click);
            // 
            // txtCodCond
            // 
            this.txtCodCond.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodCond.Location = new System.Drawing.Point(639, 308);
            this.txtCodCond.Name = "txtCodCond";
            this.txtCodCond.Size = new System.Drawing.Size(97, 32);
            this.txtCodCond.TabIndex = 604;
            this.txtCodCond.Leave += new System.EventHandler(this.txtCodCond_Leave);
            // 
            // lblCodCond
            // 
            this.lblCodCond.AutoSize = true;
            this.lblCodCond.Location = new System.Drawing.Point(636, 287);
            this.lblCodCond.Name = "lblCodCond";
            this.lblCodCond.Size = new System.Drawing.Size(79, 18);
            this.lblCodCond.TabIndex = 605;
            this.lblCodCond.Text = "Cod Cond";
            // 
            // txtCond
            // 
            this.txtCond.Enabled = false;
            this.txtCond.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCond.Location = new System.Drawing.Point(742, 308);
            this.txtCond.Name = "txtCond";
            this.txtCond.Size = new System.Drawing.Size(303, 32);
            this.txtCond.TabIndex = 606;
            this.txtCond.Leave += new System.EventHandler(this.txtCond_Leave);
            // 
            // lblCond
            // 
            this.lblCond.AutoSize = true;
            this.lblCond.Location = new System.Drawing.Point(739, 287);
            this.lblCond.Name = "lblCond";
            this.lblCond.Size = new System.Drawing.Size(179, 18);
            this.lblCond.TabIndex = 607;
            this.lblCond.Text = "Condição de Pagamento";
            // 
            // btnBuscaCond
            // 
            this.btnBuscaCond.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscaCond.BackColor = System.Drawing.Color.Gold;
            this.btnBuscaCond.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBuscaCond.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscaCond.ForeColor = System.Drawing.Color.Black;
            this.btnBuscaCond.Location = new System.Drawing.Point(1053, 310);
            this.btnBuscaCond.Margin = new System.Windows.Forms.Padding(5);
            this.btnBuscaCond.Name = "btnBuscaCond";
            this.btnBuscaCond.Size = new System.Drawing.Size(113, 27);
            this.btnBuscaCond.TabIndex = 608;
            this.btnBuscaCond.Text = "BUSCAR";
            this.btnBuscaCond.UseVisualStyleBackColor = false;
            this.btnBuscaCond.Click += new System.EventHandler(this.btnBuscaCond_Click);
            // 
            // FrmCadastroFornecedoresII
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.ClientSize = new System.Drawing.Size(1201, 554);
            this.Controls.Add(this.btnBuscaCond);
            this.Controls.Add(this.lblCond);
            this.Controls.Add(this.txtCond);
            this.Controls.Add(this.lblCodCond);
            this.Controls.Add(this.txtCodCond);
            this.Controls.Add(this.lblInscricaoEstadual);
            this.Controls.Add(this.txtInscricaoEstadual);
            this.Name = "FrmCadastroFornecedoresII";
            this.Text = "Frm Cadastro Fornecedores";
            this.Controls.SetChildIndex(this.txtInscricaoEstadual, 0);
            this.Controls.SetChildIndex(this.lblInscricaoEstadual, 0);
            this.Controls.SetChildIndex(this.txtCodCond, 0);
            this.Controls.SetChildIndex(this.lblCodCond, 0);
            this.Controls.SetChildIndex(this.txtCond, 0);
            this.Controls.SetChildIndex(this.lblCond, 0);
            this.Controls.SetChildIndex(this.cmbFisJur, 0);
            this.Controls.SetChildIndex(this.txtNome, 0);
            this.Controls.SetChildIndex(this.btnSair, 0);
            this.Controls.SetChildIndex(this.lblCodigo, 0);
            this.Controls.SetChildIndex(this.txtCodigo, 0);
            this.Controls.SetChildIndex(this.btnSalvar, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.lblTipo, 0);
            this.Controls.SetChildIndex(this.lblNome, 0);
            this.Controls.SetChildIndex(this.txtApelido, 0);
            this.Controls.SetChildIndex(this.lblApelido, 0);
            this.Controls.SetChildIndex(this.cmbSexo, 0);
            this.Controls.SetChildIndex(this.lblSexo, 0);
            this.Controls.SetChildIndex(this.txtLogradouro, 0);
            this.Controls.SetChildIndex(this.lblLogradouro, 0);
            this.Controls.SetChildIndex(this.txtNum, 0);
            this.Controls.SetChildIndex(this.lblNum, 0);
            this.Controls.SetChildIndex(this.txtComplemento, 0);
            this.Controls.SetChildIndex(this.lblComplemento, 0);
            this.Controls.SetChildIndex(this.txtBairro, 0);
            this.Controls.SetChildIndex(this.lblBairro, 0);
            this.Controls.SetChildIndex(this.txtCidade, 0);
            this.Controls.SetChildIndex(this.lblCidade, 0);
            this.Controls.SetChildIndex(this.txtCEP, 0);
            this.Controls.SetChildIndex(this.lblCEP, 0);
            this.Controls.SetChildIndex(this.btnBuscaCep, 0);
            this.Controls.SetChildIndex(this.txtEmail, 0);
            this.Controls.SetChildIndex(this.lblEmail, 0);
            this.Controls.SetChildIndex(this.txtTelefone, 0);
            this.Controls.SetChildIndex(this.lblTelefone, 0);
            this.Controls.SetChildIndex(this.txtCelular, 0);
            this.Controls.SetChildIndex(this.lblCelular, 0);
            this.Controls.SetChildIndex(this.txtRG, 0);
            this.Controls.SetChildIndex(this.lblRG, 0);
            this.Controls.SetChildIndex(this.txtCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.lblCPFouCNPJ, 0);
            this.Controls.SetChildIndex(this.dtNascimento, 0);
            this.Controls.SetChildIndex(this.lblNasc, 0);
            this.Controls.SetChildIndex(this.txtCodCargo, 0);
            this.Controls.SetChildIndex(this.lblCodCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscaCid, 0);
            this.Controls.SetChildIndex(this.txtCargo, 0);
            this.Controls.SetChildIndex(this.lblCargo, 0);
            this.Controls.SetChildIndex(this.btnBuscarCargo, 0);
            this.Controls.SetChildIndex(this.txtSalario, 0);
            this.Controls.SetChildIndex(this.lblSalario, 0);
            this.Controls.SetChildIndex(this.txtDtCriacao, 0);
            this.Controls.SetChildIndex(this.lblDtCriacao, 0);
            this.Controls.SetChildIndex(this.txtDtUltMod, 0);
            this.Controls.SetChildIndex(this.lblDtUltMod, 0);
            this.Controls.SetChildIndex(this.txtUltAltFunc, 0);
            this.Controls.SetChildIndex(this.lblUltAltFunc, 0);
            this.Controls.SetChildIndex(this.cmbStatus, 0);
            this.Controls.SetChildIndex(this.txtCodCidade, 0);
            this.Controls.SetChildIndex(this.lblCodCidade, 0);
            this.Controls.SetChildIndex(this.btnBuscaCond, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInscricaoEstadual;
        private System.Windows.Forms.Label lblInscricaoEstadual;
        private System.Windows.Forms.TextBox txtCodCond;
        private System.Windows.Forms.Label lblCodCond;
        private System.Windows.Forms.TextBox txtCond;
        private System.Windows.Forms.Label lblCond;
        protected System.Windows.Forms.Button btnBuscaCond;
    }
}
