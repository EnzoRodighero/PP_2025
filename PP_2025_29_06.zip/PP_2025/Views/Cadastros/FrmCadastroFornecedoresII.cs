﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PP_2025;

namespace PP_2025
{
    public partial class FrmCadastroFornecedoresII : FrmCadastroPessoa
    {
        private CTLFornecedores aCTLFornecedores;
        private Fornecedores oFornecedor;
        private string TipoFornecedor;
        Fornecedores FornecedorAntigo;

        public FrmCadastroFornecedoresII()
        {
            InitializeComponent();
            FornecedorAntigo = new Fornecedores();
            oFornecedor = new Fornecedores();
            aCTLFornecedores = new CTLFornecedores();
            Operacao.DisableCopyPaste(this);

            VerCampos(false);
        }

        internal void VerCampos(bool valor)
        {
            //Labels
            lblNome.Visible = valor;
            lblApelido.Visible = valor;
            //lblSexo.Visible = valor;
            lblNasc.Visible = valor;
            lblEmail.Visible = valor;
            lblTelefone.Visible = valor;
            lblCelular.Visible = valor;
            lblCEP.Visible = valor;
            lblCodCidade.Visible = valor;
            lblCidade.Visible = valor;
            lblBairro.Visible = valor;
            lblLogradouro.Visible = valor;
            lblComplemento.Visible = valor;
            lblNum.Visible = valor;
            //lblRG.Visible = valor;
            lblCPFouCNPJ.Visible = valor;
            lblCodCond.Visible = valor;
            lblCond.Visible = valor;
            lblDtCriacao.Visible = valor;
            lblDtUltMod.Visible = valor;
            lblCodCond.Visible = valor;
            lblCond.Visible = valor;
            lblInscricaoEstadual.Visible = valor;

            //TextBox
            txtNome.Visible = valor;
            txtApelido.Visible = valor;
            dtNascimento.Visible = valor;
            txtEmail.Visible = valor;
            txtTelefone.Visible = valor;
            txtCelular.Visible = valor;
            txtCEP.Visible = valor;
            txtCodCidade.Visible = valor;
            txtCidade.Visible = valor;
            txtBairro.Visible = valor;
            txtLogradouro.Visible = valor;
            txtComplemento.Visible = valor;
            txtNum.Visible = valor;
            //txtRG.Visible = valor;
            txtCPFouCNPJ.Visible = valor;
            txtCodCond.Visible = valor;
            txtCond.Visible = valor;
            txtDtCriacao.Visible = valor;
            txtDtUltMod.Visible = valor;
            txtInscricaoEstadual.Visible = valor;

            //Combobox
            //cmbSexo.Visible = valor;

            //Button
            btnBuscaCid.Visible = valor;
            btnBuscaCep.Visible = valor;
            btnBuscaCond.Visible = valor;
        }

        private void lblSexo_Click(object sender, EventArgs e)
        {

        }

        private void txtRG_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblNasc_Click(object sender, EventArgs e)
        {

        }

        protected void PessoaFisica(bool limparCampos)
        {
            txtCPFouCNPJ.MaxLength = 11; // Define o tamanho máximo do campo CPF para 11 caracteres

            VerCampos(true);
            txtInscricaoEstadual.Enabled = false;
            lblCPFouCNPJ.Visible = true;
            txtCPFouCNPJ.Enabled = true;
            //txtCPFouCNPJ.Size = new System.Drawing.Size(109, 27);
            lblCPFouCNPJ.Text = "CPF";
            lblNome.Text = "Nome";
            lblApelido.Text = "Apelido";
            lblNasc.Text = "Data de nascimento";
            TipoFornecedor = "F";
          
            if (limparCampos)
                LimparCampos();

        }
        protected void PessoaJuridica(bool limparCampos)
        {
            txtCPFouCNPJ.MaxLength = 14; // Define o tamanho máximo do campo CNPJ para 14 caracteres

            VerCampos(true);
            txtInscricaoEstadual.Enabled = true;
            txtCPFouCNPJ.Enabled = true;
            lblCPFouCNPJ.Text = "CNPJ";
            lblNome.Text = "Fornecedor";
            lblApelido.Text = "Nome Fantasia";
            lblNasc.Text = "Data Fundação";
            TipoFornecedor = "J";
            //txtCPFouCNPJ.Size = new System.Drawing.Size(226, 27);
            /*/var pais = VerificarPais();
            if (pais)
                lblCPFouCNPJ.Visible = true;
            else
                lblCPFouCNPJ.Visible = false;*/
            if (limparCampos)
                LimparCampos();
        }
        public override void ConhecaObj(object obj)
        {
            base.ConhecaObj(obj);
            if (obj is Fornecedores fornecedor)
            {
                oFornecedor = fornecedor;
                CarregarCampos();
            }
        }
        protected override void LimparCampos()
        {
            base.LimparCampos();
            txtInscricaoEstadual.Clear();
        }
        public override void BloquearCampos()
        {
            base.BloquearCampos();
            txtInscricaoEstadual.Enabled = false;
        }

        public override void DesbloquearCampos()
        {
            base.DesbloquearCampos();
            txtInscricaoEstadual.Enabled = true;
        }
        public override void CarregarCampos()
        {
            txtCodigo.Text = oFornecedor.ID.ToString();
            txtNome.Text = oFornecedor.NomeFantasia;
            txtApelido.Text = oFornecedor.RazaoSocial;
            txtInscricaoEstadual.Text = oFornecedor.InscricaoEstadual;
            txtCPFouCNPJ.Text = oFornecedor.CNPJ;
            dtNascimento.Value = oFornecedor.DataFundacao;
            txtEmail.Text = oFornecedor.Email;
            txtTelefone.Text = oFornecedor.Telefone;
            txtCelular.Text = oFornecedor.Celular;
            txtCEP.Text = oFornecedor.CEP;
            txtCodCidade.Text = oFornecedor.Cidade.ID.ToString();
            txtCidade.Text = oFornecedor.Cidade.Cidade;
            txtBairro.Text = oFornecedor.Bairro;
            txtLogradouro.Text = oFornecedor.Endereco;
            txtComplemento.Text = oFornecedor.Complemento;
            txtNum.Text = oFornecedor.Numero.ToString();
            cmbStatus.Text = oFornecedor.StatusFornecedor == "I" ? "Inativo" : oFornecedor.StatusFornecedor == "A" ? "Ativo" : oFornecedor.StatusFornecedor;
            txtCodCond.Text = oFornecedor.CondicaoPagamento.ID.ToString();
            txtCond.Text = oFornecedor.CondicaoPagamento.Condicao;
            TipoFornecedor = oFornecedor.TipoFornecedor;
            txtRG.Text = oFornecedor.RG;
            VerificarCamposJuridicosFisicos();
            FornecedorAntigo = oFornecedor;
            if (TipoFornecedor == "F")
            {
                PessoaFisica(false);
                cmbFisJur.Text = "PESSOA FÍSICA";
            }

            else
            {
                PessoaJuridica(false);
                cmbFisJur.Text = "PESSOA JÚRIDICA";
            }
        }
        protected void VerificarCamposJuridicosFisicos()
        {
            var result = VerificarPais();
            if (result)
            {
                DesbloquearCampos();
                // Caso seja brasileiro
                if (TipoFornecedor == "F")
                {
                    BlockInsc();
                    lblCPFouCNPJ.Text = "CPF";
                }
                else // Pessoa jurídica brasileira
                {
                    lblCPFouCNPJ.Text = "CNPJ";
                }
            }
            else
            {
                // Caso não seja brasileiro

                if (TipoFornecedor == "F")
                {
                    BlockInsc();
                    txtCPFouCNPJ.Enabled = false;
                    txtCPFouCNPJ.Text = "";
                }
            }
        }
        private void BlockInsc()
        {
            txtInscricaoEstadual.Enabled = false;
        }
        public override void Verificar()
        {
            if (btnSalvar.Text == "SALVAR" || btnSalvar.Text == "ALTERAR")
                Salvar();
            else if (btnSalvar.Text == "EXCLUIR")
            {
                DialogResult result = MessageBox.Show("Tem certeza que deseja excluir este cliente?", "Confirmação de Exclusão", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    ExcluirFornecedor();
                }
            }
        }
        private void ExcluirFornecedor()
        {
            if (oFornecedor != null)
            {
                try
                {
                    var result = aCTLFornecedores.ExcluirFornecedor(oFornecedor.ID);
                    if (result)
                        Close();
                    else
                    {
                        // Trate outras exceções SQL, se necessário
                        MessageBox.Show("Ocorreu um erro ao excluir o fornecedor. Detalhes: " + result);
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Number == 547) // Verifica o número de erro 547, que corresponde a violação de chave estrangeira
                    {
                        MessageBox.Show("Não é possível excluir o fornecedor devido a outros registros estarem vinculados a este fornecedor.");
                    }
                    else
                    {
                        // Trate outras exceções SQL, se necessário
                        MessageBox.Show("Ocorreu um erro ao excluir o fornecedor. Detalhes: " + ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    // Trate outras exceções gerais, se necessário
                    MessageBox.Show("Ocorreu um erro inesperado. Detalhes: " + ex.Message);
                }
            }
        }
        private bool VerificarCamposVazios()
        {
            List<string> camposFaltantes = new List<string>();

            if (string.IsNullOrWhiteSpace(txtCodCidade.Text))
            {
                camposFaltantes.Add("Código da cidade");
            }
            else
            {
                if (!int.TryParse(txtCodCidade.Text, out int codCidade) || codCidade <= 0)
                {
                    camposFaltantes.Add("Código da cidade (deve ser um número maior que zero)");
                }
            }

            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                camposFaltantes.Add("Nome");
            }

            if (string.IsNullOrWhiteSpace(txtCelular.Text))
            {
                camposFaltantes.Add("Celular");
            }

            if (TipoFornecedor == "F")
            {
                /*if (string.IsNullOrWhiteSpace(txtRG.Text))
                {
                    camposFaltantes.Add("RG");
                }*/
                if (string.IsNullOrWhiteSpace(txtCPFouCNPJ.Text) && txtCPFouCNPJ.Enabled)
                {
                    camposFaltantes.Add("CPF");
                }
            }
            else if (TipoFornecedor == "J")
            {
                var result = VerificarPais();
                if (result && string.IsNullOrWhiteSpace(txtCPFouCNPJ.Text))
                {
                    camposFaltantes.Add("CNPJ");
                }
            }

            if (string.IsNullOrWhiteSpace(txtCodCond.Text))
            {
                camposFaltantes.Add("Código da condição de pagamento");
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                camposFaltantes.Add("E-mail");
            }
            if (string.IsNullOrWhiteSpace(txtBairro.Text))
            {
                camposFaltantes.Add("Bairro");
            }
            if (string.IsNullOrWhiteSpace(txtLogradouro.Text))
            {
                camposFaltantes.Add("Logradouro");
            }
            if (string.IsNullOrWhiteSpace(cmbStatus.Text))
            {
                camposFaltantes.Add("Status");
            }

            // Verificação da data de nascimento
            if (dtNascimento.Value > DateTime.Now)
            {
                camposFaltantes.Add("Data (não pode ser uma data futura)");
            }

            if (camposFaltantes.Count > 0)
            {
                string camposFaltantesStr = string.Join(", ", camposFaltantes);
                MessageBox.Show("Os seguintes campos são obrigatórios e não foram preenchidos corretamente: " + camposFaltantesStr, "Campos em Falta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        protected virtual bool VerificarPais()
        {
            if (txtCodCidade.Text != string.Empty)
            {
                CTLCidades aCTLCidade = new CTLCidades();
                Cidades cidade = aCTLCidade.BuscarCidadePorId(Convert.ToInt32(txtCodCidade.Text));
                bool obrigatorioRGouCPF = cidade.OEstado.OPais.Pais.Equals("Brasil", StringComparison.OrdinalIgnoreCase);
                return obrigatorioRGouCPF;
            }
            else { return false; }

        }

        protected override void Salvar()
        {
            if (VerificarCamposVazios())
            {
                oFornecedor.NomeFantasia = txtNome.Text;
                oFornecedor.RazaoSocial = txtApelido.Text;
                oFornecedor.InscricaoEstadual = txtInscricaoEstadual.Text;
                oFornecedor.CNPJ = txtCPFouCNPJ.Text;
                oFornecedor.RG = txtRG.Text;
                oFornecedor.DataFundacao = dtNascimento.Value;
                oFornecedor.Email = txtEmail.Text;
                oFornecedor.Telefone = txtTelefone.Text;
                oFornecedor.Celular = txtCelular.Text;
                oFornecedor.CEP = txtCEP.Text;
                oFornecedor.Cidade.ID = Convert.ToInt32(txtCodCidade.Text);
                oFornecedor.Bairro = txtBairro.Text;
                oFornecedor.Endereco = txtLogradouro.Text;
                oFornecedor.Complemento = txtComplemento.Text;
                if (txtNum.Text.Length > 0)
                {
                    oFornecedor.Numero = Convert.ToInt32(txtNum.Text);
                }
                oFornecedor.StatusFornecedor = cmbStatus.Text[0].ToString();
                oFornecedor.CondicaoPagamento.ID = Convert.ToInt32(txtCodCond.Text);
                oFornecedor.TipoFornecedor = TipoFornecedor;

                if (oFornecedor.ID == 0)
                {
                    oFornecedor.DataCriacao = DateTime.Now;
                    var result = aCTLFornecedores.AdicionarFornecedor(oFornecedor);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
                else
                {
                    oFornecedor.DataUltimaAlteracao = DateTime.Now;
                    var result = aCTLFornecedores.AtualizarFornecedor(oFornecedor);
                    if (result == "OK")
                        Close();
                    else
                        MessageBox.Show("Erro inesperado.");
                }
            }
        }

        private void lblInscricaoEstadual_Click(object sender, EventArgs e)
        {

        }

        private void txtCelular_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbFisJur_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtCPFouCNPJ.Clear();

            if (!string.IsNullOrWhiteSpace(cmbFisJur.Text))
            {
                if (cmbFisJur.Text.Contains("F"))
                    PessoaFisica(true);
                else if (cmbFisJur.Text.Contains("J"))
                    PessoaJuridica(true);
            }
        }
        private void Limpar()
        {
            txtCodCidade.Clear();
            txtCidade.Clear();
            txtCodCidade.Focus();
        }

        protected virtual void LimparEndereco()
        { // if valor = false nao vai limpar o txtCep
            txtCEP.Clear();
            txtCodCidade.Enabled = false;
            txtNum.Clear();
            txtLogradouro.Clear();
            txtBairro.Clear();
            txtComplemento.Clear();
            txtCPFouCNPJ.Clear();
        }

        private void VerificarAtivo(Cidades cidade)
        {
            if (cidade.StatusCidade == "I")
            {
                var result = MessageBox.Show("A cidade associada a este código está inativa. Deseja continuar?",
                                             "Cidade Inativa",
                                             MessageBoxButtons.YesNo,
                                             MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    txtCidade.Text = cidade.Cidade;
                    VerificarCamposJuridicosFisicos(); 
                }
                else
                {
                    Limpar();
                }
            }
            else
            {
                txtCidade.Text = cidade.Cidade;
                VerificarCamposJuridicosFisicos();
            }
        }

        private void btnBuscaCid_Click(object sender, EventArgs e)
        {
            using (FrmConsultaCidade frm = new FrmConsultaCidade())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                // Agora, defina os valores nos campos do seu formulário de cadastro
                txtCodCidade.Text = IdSelecionado.ToString();
                txtCidade.Text = NomeSelecionado;
                if (IdSelecionado > 0)
                {
                    // Busque a cidade correspondente
                    CTLCidades aCTLCidade = new CTLCidades();
                    Cidades cidade = aCTLCidade.BuscarCidadePorId(IdSelecionado);

                    if (cidade != null)
                    {
                        VerificarAtivo(cidade);
                        LimparEndereco();
                    }
                    else
                    {
                        MessageBox.Show("Código inexistente.");
                        Limpar();
                    }
                }
            }
        }

        private async void btnBuscaCep_Click(object sender, EventArgs e)
        {
            string cep = txtCEP.Text.Trim(); // Obtém o CEP digitado no campo

            if (!string.IsNullOrEmpty(cep))
            {
                // Realiza a consulta do CEP
                string resultado = await Operacao.ConsultarCepAsync(cep);

                if (resultado != null)
                {
                    // Divida a string de resultado em campos individuais
                    string[] campos = resultado.Split(',');

                    // Encontre os valores específicos para cada campo
                    string logradouro = campos.FirstOrDefault(c => c.Contains("Logradouro:"))?.Replace("Logradouro:", "").Trim();
                    string bairro = campos.FirstOrDefault(c => c.Contains("Bairro:"))?.Replace("Bairro:", "").Trim();
                    string uf = campos.FirstOrDefault(c => c.Contains("UF:"))?.Replace("UF:", "").Trim();
                    string cidadeNome = campos.FirstOrDefault(c => c.Contains("Cidade:"))?.Replace("Cidade:", "").Trim();

                    // Preenche os campos do formulário
                    txtLogradouro.Text = logradouro ?? string.Empty;
                    txtBairro.Text = bairro ?? string.Empty;

                    // Verifica se a cidade já está cadastrada usando o novo método
                    CTLCidades ctlCidades = new CTLCidades();
                    Cidades cidade = ctlCidades.BuscarCidadePorNomeEUF(cidadeNome, uf);

                    if (cidade != null)
                    {
                        txtCodCidade.Text = cidade.ID.ToString();
                        txtCidade.Text = cidade.Cidade;
                        txtCodCidade.Enabled = false;
                        txtCPFouCNPJ.Clear();
                        var result = VerificarPais();
                        if (result)
                            lblCPFouCNPJ.Visible = true;
                        else
                            lblCPFouCNPJ.Visible = false;

                    }
                    else
                    {
                        // Caso a cidade não esteja cadastrada, pergunta se deseja adicionar
                        DialogResult dialogResult = MessageBox.Show($"A cidade {cidadeNome} - {uf} não está cadastrada. Deseja adicionar?", "Cidade não encontrada", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            // Chama o método para buscar e adicionar a cidade
                            btnBuscaCid_Click(sender, e);

                        }
                        else
                        {
                            txtCodCidade.Text = string.Empty;
                            txtCidade.Text = cidadeNome ?? string.Empty;
                        }
                    }

                }
                else
                {
                    // Lida com erros ou CEP inválido
                    Console.WriteLine("Erro na consulta de CEP ou CEP inválido.");
                }
            }
        }

        private void btnBuscaCond_Click(object sender, EventArgs e)
        {
            using (FrmConsultaCondicaoPagamento frm = new FrmConsultaCondicaoPagamento())
            {
                frm.btnSair.Text = "Selecionar";
                frm.ShowDialog();

                // Após o retorno do diálogo, você pode acessar os valores do cliente selecionado
                int IdSelecionado = frm.IdSelecionado;
                string NomeSelecionado = frm.NomeSelecionado;

                txtCodCond.Text = IdSelecionado.ToString();
                txtCond.Text = NomeSelecionado;
                txtCodCond_Leave(txtCodCond, EventArgs.Empty);

            }
        }

        private void txtCond_Leave(object sender, EventArgs e)
        {

        }

        private void LimparCondPg()
        {
            txtCond.Clear();
            txtCodCond.Clear();
        }

        private void txtCodCond_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodCond.Text))
                LimparCondPg();
            else if (int.TryParse(txtCodCond.Text, out int cod) && cod > 0)
            {
                // Se o código for um número inteiro válido e maior que zero, verifique o estado correspondente
                CTLCondicaoPagamento aCTLcon = new CTLCondicaoPagamento();
                CondicaoPagamento condicao = aCTLcon.BuscarCondicaoPagamentoPorId(cod);

                if (condicao == null)
                {
                    MessageBox.Show("Código inexistente.");
                    LimparCondPg();
                }

                else
                {
                    txtCond.Text = condicao.Condicao;
                }
            }
            else
            {
                // Se o código não for um número inteiro válido ou não for maior que zero, limpe ambos os campos
                MessageBox.Show("Código inválido. Certifique-se de inserir um número inteiro válido maior que zero.");
                LimparCondPg();
            }
            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }

        private void txtCPFouCNPJ_Leave(object sender, EventArgs e)
        {
            string documento = txtCPFouCNPJ.Text.Trim();

            // Se o campo estiver vazio, sai do método
            if (string.IsNullOrEmpty(documento))
            {
                return;
            }

            bool verificapais = VerificarPais();

            if (TipoFornecedor == "F")
            {
                // Se for pessoa física e o país for Brasil, o CPF é obrigatório
                if (lblCPFouCNPJ.Text == "CPF" && verificapais && !Operacao.IsCpf(documento))
                {
                    MessageBox.Show("Documento inválido. Por favor, insira um documento válido.");
                    txtCPFouCNPJ.Clear();
                    txtCPFouCNPJ.Focus();
                    return;
                }
            }
            else if (TipoFornecedor == "J")
            {
                // Se for pessoa jurídica, CNPJ é obrigatório apenas se for brasileiro
                if (lblCPFouCNPJ.Text == "CNPJ" && verificapais && !Operacao.IsCnpj(documento))
                {
                    MessageBox.Show("Documento inválido. Por favor, insira um documento válido.");
                    txtCPFouCNPJ.Clear();
                    txtCPFouCNPJ.Focus();
                    return;
                }
            }

            // Verifica se o documento já está cadastrado
            string result = aCTLFornecedores.BuscarFornecedorPorDocumento(documento);
            if (result != "OK" && documento != FornecedorAntigo.CNPJ)
            {
                MessageBox.Show("Erro, " + result);
                txtCPFouCNPJ.Focus();
                txtCPFouCNPJ.Text = "";
                return;
            }

            this.AcceptButton = btnSalvar; // Restaura o botão "SALVAR" como botão padrão
        }
    }
}
