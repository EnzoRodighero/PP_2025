﻿namespace PP_2025
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.panelLateral = new System.Windows.Forms.FlowLayoutPanel();
            this.pnTopMenu = new System.Windows.Forms.Panel();
            this.lblDesc = new System.Windows.Forms.Label();
            this.btnLocalizacoes = new System.Windows.Forms.Button();
            this.btnPessoas = new System.Windows.Forms.Button();
            this.btnFuncao = new System.Windows.Forms.Button();
            this.btnProdutos = new System.Windows.Forms.Button();
            this.btnServicos = new System.Windows.Forms.Button();
            this.btnSistema = new System.Windows.Forms.Button();
            this.btnFinanceiro = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblDescricaoItem = new System.Windows.Forms.Label();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.panelLateral.SuspendLayout();
            this.pnTopMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLateral
            // 
            this.panelLateral.BackColor = System.Drawing.Color.DimGray;
            this.panelLateral.Controls.Add(this.pnTopMenu);
            this.panelLateral.Controls.Add(this.btnLocalizacoes);
            this.panelLateral.Controls.Add(this.btnPessoas);
            this.panelLateral.Controls.Add(this.btnFuncao);
            this.panelLateral.Controls.Add(this.btnProdutos);
            this.panelLateral.Controls.Add(this.btnServicos);
            this.panelLateral.Controls.Add(this.btnSistema);
            this.panelLateral.Controls.Add(this.btnFinanceiro);
            this.panelLateral.Location = new System.Drawing.Point(0, 0);
            this.panelLateral.Name = "panelLateral";
            this.panelLateral.Size = new System.Drawing.Size(238, 416);
            this.panelLateral.TabIndex = 1;
            // 
            // pnTopMenu
            // 
            this.pnTopMenu.BackColor = System.Drawing.Color.DimGray;
            this.pnTopMenu.Controls.Add(this.lblDesc);
            this.pnTopMenu.Location = new System.Drawing.Point(3, 3);
            this.pnTopMenu.Name = "pnTopMenu";
            this.pnTopMenu.Size = new System.Drawing.Size(285, 50);
            this.pnTopMenu.TabIndex = 13;
            // 
            // lblDesc
            // 
            this.lblDesc.AutoSize = true;
            this.lblDesc.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Bold);
            this.lblDesc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(240)))));
            this.lblDesc.Location = new System.Drawing.Point(11, 14);
            this.lblDesc.Name = "lblDesc";
            this.lblDesc.Size = new System.Drawing.Size(0, 26);
            this.lblDesc.TabIndex = 0;
            // 
            // btnLocalizacoes
            // 
            this.btnLocalizacoes.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnLocalizacoes.BackColor = System.Drawing.Color.Gold;
            this.btnLocalizacoes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLocalizacoes.FlatAppearance.BorderSize = 0;
            this.btnLocalizacoes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLocalizacoes.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnLocalizacoes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLocalizacoes.Location = new System.Drawing.Point(3, 59);
            this.btnLocalizacoes.Name = "btnLocalizacoes";
            this.btnLocalizacoes.Size = new System.Drawing.Size(235, 45);
            this.btnLocalizacoes.TabIndex = 0;
            this.btnLocalizacoes.Text = "LOCAIS";
            this.btnLocalizacoes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLocalizacoes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLocalizacoes.UseVisualStyleBackColor = false;
            this.btnLocalizacoes.Click += new System.EventHandler(this.btnLocalizacoes_Click);
            // 
            // btnPessoas
            // 
            this.btnPessoas.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnPessoas.BackColor = System.Drawing.Color.Gold;
            this.btnPessoas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPessoas.FlatAppearance.BorderSize = 0;
            this.btnPessoas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPessoas.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnPessoas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPessoas.Location = new System.Drawing.Point(3, 110);
            this.btnPessoas.Name = "btnPessoas";
            this.btnPessoas.Size = new System.Drawing.Size(235, 45);
            this.btnPessoas.TabIndex = 11;
            this.btnPessoas.Text = "PESSOAS";
            this.btnPessoas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPessoas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPessoas.UseVisualStyleBackColor = false;
            this.btnPessoas.Click += new System.EventHandler(this.btnPessoas_Click);
            // 
            // btnFuncao
            // 
            this.btnFuncao.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnFuncao.BackColor = System.Drawing.Color.Gold;
            this.btnFuncao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFuncao.FlatAppearance.BorderSize = 0;
            this.btnFuncao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFuncao.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnFuncao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFuncao.Location = new System.Drawing.Point(3, 161);
            this.btnFuncao.Name = "btnFuncao";
            this.btnFuncao.Size = new System.Drawing.Size(235, 45);
            this.btnFuncao.TabIndex = 3;
            this.btnFuncao.Text = "FUNÇÕES";
            this.btnFuncao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFuncao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnFuncao.UseVisualStyleBackColor = false;
            this.btnFuncao.Click += new System.EventHandler(this.btnFuncao_Click);
            // 
            // btnProdutos
            // 
            this.btnProdutos.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnProdutos.BackColor = System.Drawing.Color.Gold;
            this.btnProdutos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProdutos.FlatAppearance.BorderSize = 0;
            this.btnProdutos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProdutos.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnProdutos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProdutos.Location = new System.Drawing.Point(3, 212);
            this.btnProdutos.Name = "btnProdutos";
            this.btnProdutos.Size = new System.Drawing.Size(235, 45);
            this.btnProdutos.TabIndex = 4;
            this.btnProdutos.Text = "PRODUTOS";
            this.btnProdutos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProdutos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnProdutos.UseVisualStyleBackColor = false;
            this.btnProdutos.Click += new System.EventHandler(this.btnProdutos_Click);
            // 
            // btnServicos
            // 
            this.btnServicos.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnServicos.BackColor = System.Drawing.Color.Gold;
            this.btnServicos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServicos.FlatAppearance.BorderSize = 0;
            this.btnServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServicos.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServicos.Location = new System.Drawing.Point(3, 263);
            this.btnServicos.Name = "btnServicos";
            this.btnServicos.Size = new System.Drawing.Size(235, 45);
            this.btnServicos.TabIndex = 5;
            this.btnServicos.Text = "SERVIÇOS";
            this.btnServicos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnServicos.UseVisualStyleBackColor = false;
            this.btnServicos.Visible = false;
            // 
            // btnSistema
            // 
            this.btnSistema.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnSistema.BackColor = System.Drawing.Color.Gold;
            this.btnSistema.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSistema.FlatAppearance.BorderSize = 0;
            this.btnSistema.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSistema.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnSistema.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSistema.Location = new System.Drawing.Point(3, 314);
            this.btnSistema.Name = "btnSistema";
            this.btnSistema.Size = new System.Drawing.Size(235, 45);
            this.btnSistema.TabIndex = 14;
            this.btnSistema.Text = "SISTEMA";
            this.btnSistema.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSistema.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSistema.UseVisualStyleBackColor = false;
            this.btnSistema.Visible = false;
            // 
            // btnFinanceiro
            // 
            this.btnFinanceiro.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnFinanceiro.BackColor = System.Drawing.Color.Gold;
            this.btnFinanceiro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFinanceiro.FlatAppearance.BorderSize = 0;
            this.btnFinanceiro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFinanceiro.Font = new System.Drawing.Font("Mongolian Baiti", 13F, System.Drawing.FontStyle.Bold);
            this.btnFinanceiro.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFinanceiro.Location = new System.Drawing.Point(3, 365);
            this.btnFinanceiro.Name = "btnFinanceiro";
            this.btnFinanceiro.Size = new System.Drawing.Size(235, 45);
            this.btnFinanceiro.TabIndex = 7;
            this.btnFinanceiro.Text = "FINANÇAS";
            this.btnFinanceiro.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFinanceiro.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnFinanceiro.UseVisualStyleBackColor = false;
            this.btnFinanceiro.Click += new System.EventHandler(this.btnFinanceiro_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gray;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 416);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1171, 22);
            this.panel3.TabIndex = 16;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.lblDescricaoItem);
            this.panel2.Location = new System.Drawing.Point(265, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(894, 50);
            this.panel2.TabIndex = 17;
            // 
            // lblDescricaoItem
            // 
            this.lblDescricaoItem.AutoSize = true;
            this.lblDescricaoItem.Font = new System.Drawing.Font("Mongolian Baiti", 15F, System.Drawing.FontStyle.Bold);
            this.lblDescricaoItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(245)))), ((int)(((byte)(240)))));
            this.lblDescricaoItem.Location = new System.Drawing.Point(9, 14);
            this.lblDescricaoItem.Name = "lblDescricaoItem";
            this.lblDescricaoItem.Size = new System.Drawing.Size(0, 26);
            this.lblDescricaoItem.TabIndex = 0;
            // 
            // panelButtons
            // 
            this.panelButtons.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelButtons.Location = new System.Drawing.Point(265, 58);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(895, 358);
            this.panelButtons.TabIndex = 3;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1171, 438);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelButtons);
            this.Controls.Add(this.panelLateral);
            this.Font = new System.Drawing.Font("Mongolian Baiti", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmTestes_FormClosing);
            this.panelLateral.ResumeLayout(false);
            this.pnTopMenu.ResumeLayout(false);
            this.pnTopMenu.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLocalizacoes;
        private System.Windows.Forms.FlowLayoutPanel panelLateral;
        private System.Windows.Forms.Button btnFuncao;
        private System.Windows.Forms.Button btnProdutos;
        private System.Windows.Forms.Button btnServicos;
        private System.Windows.Forms.Button btnFinanceiro;
        private System.Windows.Forms.Button btnPessoas;
        private System.Windows.Forms.Panel pnTopMenu;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblDescricaoItem;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button btnSistema;
    }
}